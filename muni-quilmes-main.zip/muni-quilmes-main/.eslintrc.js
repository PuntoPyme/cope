module.exports = {
	parser: "@typescript-eslint/parser",
	plugins: ["@typescript-eslint"],
	extends: ["eslint:recommended", "plugin:@typescript-eslint/recommended"],
	parserOptions: {
		sourceType: "module",
		ecmaVersion: 2021,
	},
	env: {
		node: true,
		es2021: true,
	},
};

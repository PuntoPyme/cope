import React from "react";
import GenericLayout from "@/components/templates/GenericLayout";
import NewInvoiceComponent from "@/components/organism/Invoice/InvoiceComponent";
import { useSelector } from "react-redux";
import { RootState } from "@/Redux/store";

const Inicio = () => {
	const { proveedoresVer } = useSelector(
		(state: RootState) => state.proveedoresArray
	);
	return (
		<>
			<GenericLayout
				children={
					<NewInvoiceComponent
						urlPOST="/accountant/purchase-invoice/create"
						page="purchase"
						arrayPersons={proveedoresVer}
					/>
				}
			></GenericLayout>
		</>
	);
};

export default Inicio;

import React from "react";
import GenericLayout from "@/components/templates/GenericLayout";
import ComprobanteVer from "@/components/organism/CompraVer/CompraVer";
const Inicio = () => {
	return (
		<>
			<GenericLayout children={<ComprobanteVer/>}></GenericLayout>
		</>
	);
};

export default Inicio;
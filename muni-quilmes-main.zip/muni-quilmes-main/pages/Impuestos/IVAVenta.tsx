import React, { useEffect, useState } from "react";
import GenericLayout from "@/components/templates/GenericLayout";
import LibrosTemplate from "@/components/moleculas/CardInicio/Libros/LibrosTemplete";
import TablaVentasVer from "@/components/atoms/TABLAS/VentasVerTabla/VentaVerTabla";
import { useSelector } from "react-redux";
import { RootState } from "@/Redux/store";
import { ivaLibro, ventaVer } from "@/types";
import { fetchGetRequest } from "@/utils/ApiRequest";
import { isIvaLibro } from "@/utils/Functions/ValidationInputs";
import { Box, Grid, Typography } from "@mui/material";
import TotalComponente from "@/components/atoms/TABLAS/Libros/TotalComponente";
import BookVat from "@/components/atoms/TABLAS/Libros/LibroIVA";
const Inicio = () => {
	const { codejwt } = useSelector((state: RootState) => state.storeJwt);
	const [rowsState, setRowsState] = useState<ventaVer[]>([]);
	const [totalesState, setTotalState] = useState<ivaLibro>();
	useEffect(() => {
		fetchGetRequest("/accountant/vatSaleBook/byCompany", codejwt)
			.then((data: unknown) => {
				// Verifica si el dato recibido cumple con la estructura de ivaLibro
				if (isIvaLibro(data)) {
					if (data.salesInvoices) {
						setRowsState(data.salesInvoices);
					}
					setTotalState(data);
				}
			})
			.catch((error) => {
				console.error("Error fetching invoices:", error);
			});
	}, []);

	return (
		<>
			<GenericLayout
				children={
					<LibrosTemplate
						title="ventas"
						dataForPrint={{ salesInvoice: rowsState, totals: totalesState }}
						libro={<BookVat itemsForRows={rowsState} type="sales" />}
						totalComponente={<TotalComponente data={totalesState} />}
					/>
				}
			></GenericLayout>
		</>
	);
};

export default Inicio;

import React, { useEffect, useState } from "react";
import GenericLayout from "@/components/templates/GenericLayout";
import LibrosTemplate from "@/components/moleculas/CardInicio/Libros/LibrosTemplete";
import { Typography } from "@mui/material";
import { fetchGetRequest } from "@/utils/ApiRequest";
import { isIvaLibroCompra } from "@/utils/Functions/ValidationInputs";
import { useSelector } from "react-redux";
import { compraVer, ivaLibro, ventaVer } from "@/types";
import { RootState } from "@/Redux/store";
import BookVatCompra from "@/components/atoms/TABLAS/Libros/LibroIVACompra";
import TotalComponenteCompra from "@/components/atoms/TABLAS/Libros/TotalComponenteCompra";
const Inicio = () => {
	const { codejwt } = useSelector((state: RootState) => state.storeJwt);
	const [rowsState, setRowsState] = useState<compraVer[]>([]);
	const [totalesState, setTotalState] = useState<ivaLibro>();
	useEffect(() => {
		fetchGetRequest("/accountant/vatPurchaseBook/byCompany", codejwt)
			.then((data: unknown) => {
				// Verifica si el dato recibido cumple con la estructura de ivaLibro
				if (isIvaLibroCompra(data)) {
					if (data.purchaseInvoices) {
						setRowsState(data.purchaseInvoices);
					}
					setTotalState(data);
				}
			})
			.catch((error) => {
				console.error("Error fetching invoices:", error);
			});
	}, []);
	return (
		<>
			<GenericLayout
				children={
					<LibrosTemplate
						title={"compras"}
						dataForPrint={{ totals: totalesState, salesInvoice: rowsState }}
						libro={<BookVatCompra itemsForRows={rowsState} type="purchase" />}
						totalComponente={<TotalComponenteCompra data={totalesState} />}
					></LibrosTemplate>
				}
			></GenericLayout>
		</>
	);
};

export default Inicio;

import CardGrid from "@/components/organism/cardsGrid/CardGrid";
import GenericLayout from "@/components/templates/GenericLayout";
import { Box } from "@mui/material";
import React from "react";
const Inicio = () => {
	return (
		<>
			<GenericLayout
				children={
					<Box marginTop={"10vh"}>
						<CardGrid></CardGrid>
					</Box>
				}
			></GenericLayout>
		</>
	);
};

export default Inicio;

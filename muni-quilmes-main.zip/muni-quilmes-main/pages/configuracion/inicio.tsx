import InicioFormulario from "@/components/atoms/InicioFormulario/InicioFormulario";
import React from "react";

const Inicio = () => {
	return (
		<>
			<InicioFormulario></InicioFormulario>
		</>
	);
};

export default Inicio;

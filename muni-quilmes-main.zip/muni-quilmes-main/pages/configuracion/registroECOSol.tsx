import { Box } from "@mui/system";
import React, { useEffect, useState } from "react";
import BackgroundPage from "../../components/atoms/BackgroundApp/BackgroundApp";
import image from "../../assets/back.jpg";
import { Alert, IconButton } from "@mui/material";
import imageLogo from "../../assets/logofooter.png";
import Image from "next/image";
import { useRouter } from "next/router";
import HomeIcon from "@mui/icons-material/Home";
import DataFormulario from "@/components/atoms/DataFormulario/DataFormulario";
export interface RegistroProps {}
import { CSSProperties } from "@mui/styles";
import { fetchPostRegister, PostLogin } from "@/utils/ApiRequest";
import { registerCompany, registerUser } from "@/types";
import { useDispatch } from "react-redux";
import { setCodeJwtState } from "@/Redux/features/Codejwt";
import { gradients } from "@/utils/styles/gradients";
import { ButtonHome } from "@/components/atoms/Button/Button-home/ButtonHome";

// cooperative-user-controller=>ADMIN/USER/REGISTER(POST) => CREAR USUARIO ACCOUNTAT
// LUEGO DE REGISTRAR EL USUARIO EJECUTO EL POST =>ADMIN/USER/RELATEUSERCOMPANY LO ASOCIO A UNA COOPERATIVA
// (AMBOS POST ANTERIORES DEBEN TENER EL MISMO EMAIL???)
// LOGIN RETURN JWT
// register-new-company-controller => CREA LA COOPERATIVA

const Inicio = () => {
	const router = useRouter();
	const [loading, setLoading] = useState(false);
	const dispatch = useDispatch();
	const [formUsuario, setFormUsuario] = useState<registerUser>({
		email: "",
		password: "",
		firstName: "",
		lastName: "",
	});
	const [formCompany, setFormCompany] = useState<registerCompany>({
		companyName: "",
		cuit: "",
	});
	const [alert, setAlert] = useState<boolean>(false);
	const [alertType, setAlertType] = useState<
		"error" | "info" | "success" | "warning"
	>("info");
	const [alertText, setAlertText] = useState<string>("");

	const handleUpdateUser = (updatedUser: registerUser) => {
		setFormUsuario(updatedUser);
	};

	const handleUpdateCompany = (updatedCompany: registerCompany) => {
		setFormCompany(updatedCompany);
	};

	const showAlert = (
		text: string,
		type: "error" | "info" | "success" | "warning"
	) => {
		setAlertText(text);
		setAlertType(type);
		setAlert(true);
		return new Promise<void>((resolve) =>
			setTimeout(() => {
				setAlert(false);
				resolve();
			}, 3000)
		);
	};

	async function clickPost(
		usuario: registerUser,
		company: registerCompany
	): Promise<boolean> {
		try {
			setLoading(true);

			let userRegistered = false;
			let companyRegistered = false;
			try {
				const responseUsuario = await fetchPostRegister(
					"/admin/users/register",
					usuario
				);
				if (responseUsuario.status === 200) {
					await showAlert("Usuario creado con éxito", "success");
					userRegistered = true;
				}
			} catch (error) {
				if (
					error instanceof Error &&
					error.message.includes("ya está registrado")
				) {
					await showAlert("El usuario ya está registrado", "info");
					userRegistered = true;
				} else {
					throw new Error("Falló el registro de usuario");
				}
			}

			// Intenta registrar la cooperativa
			try {
				const responseCompany = await fetchPostRegister(
					"/admin/company/register",
					company
				);
				if (responseCompany.status === 200) {
					await showAlert("Cooperativa creada con éxito", "success");
					companyRegistered = true;
				}
			} catch (error) {
				if (
					error instanceof Error &&
					error.message.includes("ya está registrada")
				) {
					await showAlert("La cooperativa ya está registrada", "info");
					companyRegistered = true;
				} else {
					throw new Error("Falló el registro de la cooperativa");
				}
			}

			// Si ambos están registrados (ya sea porque se registraron ahora o porque ya existían),
			// intentamos relacionarlos
			if (userRegistered && companyRegistered) {
				try {
					const relationResponse = await fetchPostRegister(
						"/admin/users/relateUserCompany",
						{
							email: usuario.email,
							cuit: company.cuit,
						}
					);
					if (relationResponse.status === 200) {
						await showAlert(
							"Usuario y cooperativa relacionados con éxito",
							"success"
						);
						return true;
					} else {
						throw new Error("Falló la relación entre usuario y cooperativa");
					}
				} catch (error) {
					if (
						error instanceof Error &&
						error.message.includes("ya están relacionados")
					) {
						await showAlert(
							"El usuario y la cooperativa ya están relacionados",
							"info"
						);
						return true;
					} else {
						throw error;
					}
				}
			} else {
				throw new Error("No se pudo completar el registro");
			}
		} catch (error) {
			if (error instanceof Error) {
				await showAlert(error.message, "error");
			} else {
				await showAlert("Ocurrió un error inesperado", "error");
			}
			return false;
		} finally {
			setLoading(false);
		}
	}

	const handleSave = async (
		usuario: registerUser,
		company: registerCompany
	) => {
		const registrationSuccess = await clickPost(usuario, company);
		if (registrationSuccess) {
			await showAlert("Registro completado. Iniciando sesión...", "info");
			try {
				const token = await PostLogin(usuario.email, usuario.password);
				if (token) {
					dispatch(setCodeJwtState(token));
					router.push("/Inicio");
				} else {
					throw new Error("No se pudo iniciar sesión");
				}
			} catch (error) {
				await showAlert(
					"Error al iniciar sesión. Por favor, intente más tarde.",
					"error"
				);
			}
		}
	};
	return (
		<>
			<Box sx={style.containerPage}>
				<BackgroundPage backgroundImage={image} />
				<Box sx={style.boxInicio}>
					<IconButton
						onClick={() => {
							router.push("/");
						}}
					>
						<HomeIcon />
					</IconButton>
					<Box sx={style.boxImage}>
						<Image src={imageLogo} alt="Imagen" priority={true} height={50} />
					</Box>
				</Box>
				<Box
					width={"fit-content"}
					height={"fit-content"}
					marginTop={"2vh"}
					sx={{
						borderRadius: "40px",
					}}
				>
					<DataFormulario
						loading={loading}
						onSave={() => {
							handleSave(formUsuario, formCompany);
						}}
						onUpdateUser={handleUpdateUser}
						onUpdateCompany={handleUpdateCompany}
					/>
				</Box>
			</Box>
			{alert && (
				<Box
					sx={{
						width: "40%",
						right: "30%",
						position: "absolute",
						top: "40%",
					}}
				>
					<Alert variant="filled" severity={alertType}>
						{alertText}
					</Alert>
				</Box>
			)}
		</>
	);
};
const style: Record<string, CSSProperties> = {
	boxImage: {
		borderRadius: "10px",
		padding: "2%",
		background: "#ffffff80",
	},
	boxInicio: {
		position: "absolute",
		left: "2vw",
		top: "2vh",
		display: "flex",
		alignItems: "center",
		gap: "1vh",
		".MuiSvgIcon-root": {
			color: "white",
			width: "3vw !important",
			height: "unset",
			borderRadius: "5px !important",
		},
	},
	containerPage: {
		width: "100vw !important",
		margin: "0 !important",
		display: "flex",
		height: "100vh",
		alignItems: "center",
		justifyContent: "center",
		flexDirection: "column",
	},
};
export default Inicio;

import DataFormulario from "@/components/atoms/DataFormulario/DataFormulario";
import { registerUser, registerCompany } from "@/types";
import React from "react";

const Inicio = () => {
	return (
		<>
			<DataFormulario
				onUpdateUser={function (user: registerUser): void {
					throw new Error("Function not implemented.");
				}}
				onUpdateCompany={function (company: registerCompany): void {
					throw new Error("Function not implemented.");
				}}
				onSave={function (): void {
					throw new Error("Function not implemented.");
				}}
				loading={false}
			></DataFormulario>
		</>
	);
};

export default Inicio;

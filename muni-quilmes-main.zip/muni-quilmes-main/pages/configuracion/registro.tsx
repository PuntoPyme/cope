import React from "react";
import { InstructivoRegistro } from "@/components/atoms/InstructivoRegistro/Instructivo";
const Inicio = () => {
	return <InstructivoRegistro></InstructivoRegistro>;
};

export default Inicio;

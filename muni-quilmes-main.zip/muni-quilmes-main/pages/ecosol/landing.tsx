import React from "react";
import {
	ThemeProvider,
	createTheme,
	Box,
	Typography,
	Grid,
	Card,
} from "@mui/material";
import Image from "next/image";
import { TestimoniosGrid } from "@/components/atoms/TestimoniosGrid/TestimoniosGrid";
import Contacto from "@/components/atoms/Contacto/Contacto";
import ecosol from "../../assets/ecosollogo.png";
import Imagebackground1 from "../../assets/back.jpg";
import quibot from "../../assets/quibot.png";
import biblioteca from "../../assets/biblioteca.png";
import paseo from "../../assets/paseo.png";
import contable from "../../assets/contable.png";
import logo from "../../assets/logoquilmes.png";
import Link from "next/link";

// Create custom theme
const theme = createTheme({
	palette: {
		primary: {
			main: "#7B62A3", // Deep purple
		},
	},
});

export default function LandingPage() {
	return (
		<ThemeProvider theme={theme}>
			<Box
				sx={{
					minHeight: "100vh",
					display: "flex",
					flexDirection: "column",
					bgcolor: "primary.main",
					backgroundImage: `url(${Imagebackground1.src})`,
					backgroundSize: "cover",
					backgroundPosition: "center",
					backgroundAttachment: "fixed",
				}}
			>
				<Box component="main" sx={{ flexGrow: 1, pt: "2%", pb: "5%" }}>
					{/* Logo and title */}
					<Box
						sx={{
							width: { xs: "90%", sm: "80%"},
							height: { xs: "30vh", sm: "40vh", md: "50vh" },
							backgroundColor: "white",
							borderRadius: "40px",
							margin: "0 auto",
							display: "flex",
							justifyContent: "center",
							alignItems: "center",
							mb: "5%",
						}}
					>
						<Image
							src={ecosol}
							alt="Logo Municipalidad de Quilmes"
							width={900}
							height={900}
							style={{
								maxWidth: "100%",
								height: "auto",
								objectFit: "contain",
							}}
						/>
					</Box>

					{/* Feature icons */}
					<Grid
						container
						spacing={5}
						sx={{ mb: 3, maxWidth: "lg", mx: "auto", px: 2 }}
					>
						{[
							{
								image: contable,
								title: "Sistema Cooperativo Contable",
								link: "/",
							},
							{
								image: paseo,
								title: "Paseo Virtual de la Economía Social",
								link: "/Paseo",
							},
							{
								image: biblioteca,
								title: "Biblioteca de la Economía Social",
								link: "#",
							},
							{ image: quibot, title: "Chatbot", link: "#" },
						].map((feature, index) => (
							<Grid item xs={6} sm={3} key={index}>
								<Link href={feature.link} style={{ textDecoration: "none" }}>
									<Card
										sx={{
											height: "100%",
											display: "flex",
											flexDirection: "column",
											alignItems: "center",
											p: 1,
											borderRadius: "40px",
										}}
									>
										<Image
											src={feature.image}
											alt={`Feature Image ${index + 1}`}
											width={120}
											height={120}
											style={{
												objectFit: "contain",
												marginBottom: "16px",
												padding: "7%",
											}}
										/>
										<hr style={{ width: "100%" }} />
										<Typography
											variant="h6"
											align="center"
											color="primary.main"
											sx={{
												fontFamily: "Poppins, sans-serif",
												fontWeight: "bold",
												fontSize: "18px",
											}}
										>
											{feature.title}
										</Typography>
									</Card>
								</Link>
							</Grid>
						))}
					</Grid>

					{/* Testimonials and contact section */}
					<Box
						id="testimonios"
						sx={{
							width: "100%",
							display: "flex",
							alignItems: "center",
							justifyContent: "center",
							flexDirection: "column",
							gap: "5vw",
							mb: "5%",
							mt: "7%",
						}}
					>
						<TestimoniosGrid />
						<Contacto />
					</Box>
				</Box>

				{/* Footer */}
				<Box
					component="footer"
					sx={{
						display: "flex",
						flexDirection: { xs: "column", sm: "row" },
						alignItems: "center",
						justifyContent: "center",
						bgcolor: "primary.main",
						p: 2,
						mt: "auto",
					}}
				>
					<Typography
						variant="body2"
						sx={{
							color: "white",
							fontFamily: "Poppins, sans-serif",
							fontSize: { xs: "20px", sm: "28px" },
							mb: { xs: 2, sm: 0 },
						}}
					>
						Creado por la Municipalidad de Quilmes
					</Typography>
					<Image
						src={logo}
						alt="Logo Municipalidad de Quilmes"
						width={180}
						height={100}
						style={{
							objectFit: "contain",
							marginLeft: "12%",
						}}
					/>
				</Box>
			</Box>
		</ThemeProvider>
	);
}

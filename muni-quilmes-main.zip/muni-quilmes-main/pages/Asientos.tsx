import React, { useState } from "react";
import GenericLayout from "@/components/templates/GenericLayout";
import JournalEntryForm from "@/components/atoms/TABLAS/AsientosForm/AsientosForm";
import { Box } from "@mui/material";
import { ButtonClasic } from "@/components/atoms/Button/Button-clasic/ButtonClasic";
import { ModalComponent } from "@/components/atoms/Modal/ModalAtom";
import { CreateAccount } from "@/components/moleculas/CardInicio/CrearCuenta/CrearCuenta";
const Inicio = () => {
	const [openModal, setOpenModal] = useState<boolean>(false);
	return (
		<>
			<GenericLayout
				children={
					<>
						<Box
							sx={{
								width: "100vw",
								display: "flex",
								alignItems: "center",
								flexDirection: "column",
								justifyContent: "center",
								minHeight: "fit-content",
								pb:'5%'
							}}
						>
							<Box
								display={"flex"}
								justifyContent={"center"}
								width="80%"
								my="2vw"
							>
								<ButtonClasic
									primary={false}
									onClick={() => {
										setOpenModal(true);
									}}
								>
									Crear cuentas
								</ButtonClasic>
							</Box>
							<Box
								sx={{
									background: "white",
									width: "80vw",
									height: "fit-content",
									p: "5%",
								}}
							>
								<JournalEntryForm />
							</Box>
							<ModalComponent openProp={openModal}>
								<CreateAccount
									onClickCancelar={() => {
										setOpenModal(false);
									}}
								/>
							</ModalComponent>
						</Box>
					</>
				}
			></GenericLayout>
		</>
	);
};

export default Inicio;

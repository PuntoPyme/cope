import React from "react";
import GenericLayout from "@/components/templates/GenericLayout";
import NewInvoiceComponent from "@/components/organism/Invoice/InvoiceComponent";
import { useSelector } from "react-redux";
import { RootState } from "@/Redux/store";
const Inicio = () => {
	const { clienteNuevo } = useSelector(
		(state: RootState) => state.clienteArray
	);
	return (
		<>
			<GenericLayout
				children={
					<NewInvoiceComponent
						urlPOST="/accountant/sales-invoice/create"
						page="sales"
						arrayPersons={clienteNuevo}
					/>
				}
			></GenericLayout>
		</>
	);
};

export default Inicio;

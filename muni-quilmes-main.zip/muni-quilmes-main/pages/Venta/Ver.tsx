import React from "react";
import GenericLayout from "@/components/templates/GenericLayout";
import ComprobanteVer from "@/components/organism/VentaVer/VentaVer";
const Inicio = () => {
	return (
		<>
			<GenericLayout children={<ComprobanteVer/>}></GenericLayout>
		</>
	);
};

export default Inicio;

import Layout from "@/components/templates/Layout";
import NavbarLandingPage from "@/components/atoms/NavbarLandingPage/NavbarLandingPage";
import Contacto from "@/components/atoms/Contacto/Contacto";
import Footer from "@/components/atoms/Footer/Footer";
import HeaderLandingPage from "@/components/atoms/HeaderLandingPage/HeaderLandingPage";
import BodyLandingPage from "@/components/atoms/BodyLandingPage/BodyLandingPage";
import { setProvincias } from "@/Redux/features/provinciasReducer";
import { fetchDataProvincias } from "@/utils/ApiRequest";
import { useDispatch } from "react-redux";
import { useEffect } from "react";
//Landing Pagenpm install firebase firebase-admin

export default function IndexPage() {
	const dispatch = useDispatch();
	useEffect(() => {
		async function fetchProvincias() {
			const data = await fetchDataProvincias();
			if (data) {
				dispatch(setProvincias(data));
			}
		}
		fetchProvincias();
	}, []);

	return (
		<Layout title={"SGC"}>
			<NavbarLandingPage />
			<BodyLandingPage />
			<Footer />
		</Layout>
	);
}

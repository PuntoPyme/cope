import React from "react";
import GenericLayout from "@/components/templates/GenericLayout";
import ProveedorVer from "@/components/organism/proveedorVer";
const Inicio = () => {
	return (
		<>
			<GenericLayout children={<ProveedorVer />}></GenericLayout>
		</>
	);
};

export default Inicio;

import React from "react";
import GenericLayout from "@/components/templates/GenericLayout";
import ProveedorNuevo from "@/components/organism/proveedorNuevo";
const Inicio = () => {
	return (
		<>
			<GenericLayout children={<ProveedorNuevo />}></GenericLayout>
		</>
	);
};

export default Inicio;

import React from "react";
import {
	ThemeProvider,
	createTheme,
	Box,
	Typography,
	Grid,
} from "@mui/material";
import Imagebackground1 from "../../assets/back.jpg";
import Cardteo from "@/components/atoms/Cardteo/Cardteo";
import Image from "next/image";
import logo from "../../assets/logoquilmes.png";

// Crear tema personalizado
const theme = createTheme({
	palette: {
		primary: {
			main: "#7B62A3", // Morado profundo
		},
	},
});

export default function Paseo() {
	return (
		<ThemeProvider theme={theme}>
			<Box
				sx={{
					minHeight: "100vh",
					bgcolor: "primary.main",
					backgroundImage: `url(${Imagebackground1.src})`,
				}}
			>
				<Box
					sx={{
						p: 6,
						pl: 18,
					}}
				>
					<Grid container spacing={2}>
						<Grid item xs={8}>
							<Typography
								variant="h2"
								sx={{
									color: "white",
									fontWeight: "bold",
									fontFamily: "'Poppins', sans-serif",
									textAlign: "left",
								}}
							>
								Paseo de compras
							</Typography>
						</Grid>

						<Grid item xs={4}>
							<Image
								src={logo} // Asignar la imagen
								alt="Logo Municipalidad de Quilmes"
								width={180} // Ajusta el ancho de la imagen
								height={100} // Ajusta la altura de la imagen
								style={{
									objectFit: "contain",
									paddingLeft: "12%",
								}}
							/>
						</Grid>
					</Grid>

					<Typography
						variant="h4"
						sx={{
							color: "white",

							fontFamily: "'Poppins', sans-serif",
							fontWeight: "light",
							textAlign: "left",
						}}
					>
						Encontrá todas las cooperativas de Quilmes acá
					</Typography>
				</Box>

				<Cardteo />
			</Box>
			<Box
				sx={{
					display: "flex",
					flexDirection: { xs: "column", sm: "row" }, // En pantallas pequeñas (xs), cambiar a columna; en pantallas medianas y más grandes, usar fila
					alignItems: "center", // Centra verticalmente el contenido en pantallas grandes
					justifyContent: "center", // Centra horizontalmente
					bgcolor: "primary.main", // Fondo opcional
					p: 2, // Padding opcional
					textAlign: { xs: "center", sm: "left" }, // Centrar el texto en pantallas pequeñas
				}}
			>
				<Typography
					variant="body2"
					sx={{
						color: "white", // Color blanco
						fontFamily: "Poppins, sans-serif", // Tipografía Poppins
						fontSize: { xs: "20px", sm: "28px" }, // Tamaño de fuente ajustable para pantallas pequeñas y grandes
						// Padding solo en pantallas grandes
						mb: { xs: 2, sm: 0 }, // Margen inferior en pantallas pequeñas para separar del logo
					}}
				>
					Creado por la Municipalidad de Quilmes
				</Typography>

				<Image
					src={logo} // Asignar la imagen
					alt="Logo Municipalidad de Quilmes"
					width={180} // Ajusta el ancho de la imagen
					height={100} // Ajusta la altura de la imagen
					style={{
						objectFit: "contain",
						paddingLeft: "12%",
					}}
				/>
			</Box>
		</ThemeProvider>
	);
}

import React from "react";
import GenericLayout from "@/components/templates/GenericLayout";
import ClienteVer from "@/components/organism/clienteVer";
const Inicio = () => {
	return (
		<>
			<GenericLayout children={<ClienteVer></ClienteVer>}></GenericLayout>
		</>
	);
};

export default Inicio;

import React from "react";
import GenericLayout from "@/components/templates/GenericLayout";
import ClienteNuevo from "@/components/organism/clienteNuevo";
const Inicio = () => {
	return (
		<>
			<GenericLayout
				children={<ClienteNuevo ></ClienteNuevo>}
			></GenericLayout>
		</>
	);
};

export default Inicio;

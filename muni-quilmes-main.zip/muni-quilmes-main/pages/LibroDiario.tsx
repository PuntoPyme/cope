import React from "react";
import GenericLayout from "@/components/templates/GenericLayout";
import LibroDiarioTemplate from "@/components/moleculas/CardInicio/Libros/LibroDiarioTemplete";

const Inicio = () => {
	return (
		<>
			<GenericLayout children={<LibroDiarioTemplate />}></GenericLayout>
		</>
	);
};

export default Inicio;

import { createTheme } from "@mui/material";

const defaultTheme = createTheme({
	typography: {
		allVariants: {
			fontFamily: ["Poppins", "Roboto", "Inter"].join(","),
		},

		titleChart: {
			fontFamily: ["Poppins", "Roboto", "Inter"].join(","),
			fontWeight: "500",
			lineHeight: "60px",
			letterSpacing: "0em",
			textAlign: "left",
		},
		headerTitle: {
			fontFamily: ["Poppins", "Roboto", "Inter"].join(","),
			fontSize: "60px",
			fontWeight: "300",
			lineHeight: "90px",
			letterSpacing: "0em",
			textAlign: "left",
		},

		navbarTitle: {
			fontFamily: ["Poppins", "Roboto", "Inter"].join(","),
			fontSize: "50px",
			fontWeight: "300",
			lineHeight: "75px",
			letterSpacing: "0em",
			textAlign: "left",
		},

		logoTitle: {
			fontFamily: ["Poppins", "Roboto", "Inter"].join(","),
			/*FontStyle: "Medium",
			 */ fontSize: "40px",
			lineHeight: "60px",
			textAlign: "left",
		},

		sidebarLine: {
			fontFamily: ["Poppins", "Roboto", "Inter"].join(","),
			fontSize: "20px",
			fontWeight: "400",
			lineHeight: "30px",
			letterSpacing: "0em",
			textAlign: "left",
		},

		buttonLetter: {
			fontFamily: ["Poppins", "Roboto", "Inter"].join(","),

			fontSize: "18px",
			fontWeight: "500",
			lineHeight: "20px",
			letterSpacing: "0.10000000149011612px",
			textAlign: "left",
		},

		userInitials: {
			fontFamily: "Inter",
			fontSize: "25px",
			fontWeight: "700",
			lineHeight: "30px",
			letterSpacing: "0em",
			textAlign: "center",
		},

		cardsTitle: {
			fontFamily: ["Poppins", "Roboto", "Inter"].join(","),

			fontSize: "24px",
			fontWeight: "700",
			lineHeight: "28px",
			letterSpacing: "0em",
			textAlign: "center",
		},

		cardsCaption: {
			fontFamily: ["Poppins", "Roboto", "Inter"].join(","),
			fontSize: "16px",
			fontWeight: "500",
			lineHeight: "24px",
			letterSpacing: "0em",
			textAlign: "center",
		},

		itemsCards: {
			fontFamily: ["Poppins", "Roboto", "Inter"].join(","),
			fontSize: "16px",
			fontWeight: "500",
			lineHeight: "24px",
			letterSpacing: "0em",
			textAlign: "center",
		},

		titleCardsTerrain: {
			fontFamily: ["Poppins", "Roboto", "Inter"].join(","),
			fontSize: "25px",
			fontWeight: "400",
			lineHeight: "24px",
			letterSpacing: "0.15000000596046448px",
			textAlign: "left",
		},

		pageDiv: {
			fontFamily: ["Poppins", "Roboto", "Inter"].join(","),
			fontSize: "14px",
			fontWeight: "500",
			lineHeight: "16px",
			letterSpacing: "1.25px",
			textAlign: "center",
		},

		filterLetter: {
			fontFamily: ["Poppins", "Roboto", "Inter"].join(","),
			fontSize: "16px",
			fontWeight: "400",
			lineHeight: "24px",
			letterSpacing: "0.5px",
			textAlign: "center",
		},

		inputLetter: {
			fontFamily: ["Poppins", "Roboto", "Inter"].join(","),
			fontSize: "24px",
			fontWeight: "400",
			lineHeight: "30px",
			letterSpacing: "0em",
			textAlign: "center",
		},

		cropList: {
			fontFamily: ["Poppins", "Roboto", "Inter"].join(","),

			fontSize: "16px",
			fontWeight: "400",
			lineHeight: "24px",
			letterSpacing: "0.5px",
			textAlign: "left",
		},

		monthsYears: {
			fontFamily: ["Poppins", "Roboto", "Inter"].join(","),
			fontSize: "24px",
			fontWeight: "500",
			lineHeight: "36px",
			letterSpacing: "0em",
			textAlign: "right",
		},

		cardsPrices: {
			fontFamily: "Poppins",
			fontSize: "24px",
			fontWeight: "400",
			lineHeight: "30px",
			letterSpacing: " 0em",
			textAlign: "center",
		},
	},
});

export default defaultTheme;

import "@mui/material/styles";
declare module "@mui/material/styles" {
	/* 
	interface Palette {
		header: {
			background: React.CSSProperties['color'];
			text: React.CSSProperties['color'];
		};
		ribbon: {
			primary: React.CSSProperties['color'];
		};
	}

	interface PaletteOptions {
		header: {
			background: React.CSSProperties['color'];
			text: React.CSSProperties['color'];
		};
		ribbon: {
			primary: React.CSSProperties['color'];
		};
	} */

	interface TypographyVariants {
		headerTitle: React.CSSProperties;
		navbarTitle: React.CSSProperties;
		logoTitle: React.CSSProperties;
		sidebarLine: React.CSSProperties;
		buttonLetter: React.CSSProperties;
		userInitials: React.CSSProperties;
		cardsTitle: React.CSSProperties;
		cardsCaption: React.CSSProperties;
		itemsCards: React.CSSProperties;
		cardsCaption: React.CSSProperties;
		titleCardsTerrain: React.CSSProperties;
		titleChart: React.CSSProperties;
		pageDiv: React.CSSProperties;
		filterLetter: React.CSSProperties;
		inputLetter: React.CSSProperties;
		cropList: React.CSSProperties;
		monthsYears: React.CSSProperties;
		cardsPrices: React.CSSProperties;
	}

	interface TypographyVariantsOptions {
		headerTitle: React.CSSProperties;
		navbarTitle: React.CSSProperties;
		logoTitle: React.CSSProperties;
		sidebarLine: React.CSSProperties;
		buttonLetter: React.CSSProperties;
		userInitials: React.CSSProperties;
		cardsTitle: React.CSSProperties;
		cardsCaption: React.CSSProperties;
		itemsCards: React.CSSProperties;
		cardsCaption: React.CSSProperties;
		titleCardsTerrain: React.CSSProperties;
		titleChart: React.CSSProperties;
		pageDiv: React.CSSProperties;
		filterLetter: React.CSSProperties;
		inputLetter: React.CSSProperties;
		cropList: React.CSSProperties;
		monthsYears: React.CSSProperties;
		cardsPrices: React.CSSProperties;
	}
}

declare module "@mui/material/Typography" {
	interface TypographyPropsVariantOverrides {
		headerTitle: true;
		navbarTitle: true;
		logoTitle: true;
		sidebarLine: true;
		buttonLetter: true;
		userInitials: true;
		cardsTitle: true;
		cardsCaption: true;
		itemsCards: true;
		cardsCaption: true;
		titleCardsTerrain: true;
		titleChart: true;
		pageDiv: true;
		filterLetter: true;
		inputLetter: true;
		cropList: true;
		monthsYears: true;
		cardsPrices: true;
	}

	interface TypographyOptions {
		headerTitle: React.CSSProperties;
		navbarTitle: React.CSSProperties;
		logoTitle: React.CSSProperties;
		sidebarLine: React.CSSProperties;
		buttonLetter: React.CSSProperties;
		userInitials: React.CSSProperties;
		cardsTitle: React.CSSProperties;
		cardsCaption: React.CSSProperties;
		itemsCards: React.CSSProperties;
		cardsCaption: React.CSSProperties;
		titleCardsTerrain: React.CSSProperties;
		titleChart: React.CSSProperties;
		pageDiv: React.CSSProperties;
		filterLetter: React.CSSProperties;
		inputLetter: React.CSSProperties;
		cropList: React.CSSProperties;
		monthsYears: React.CSSProperties;
		cardsPrices: React.CSSProperties;
	}
}

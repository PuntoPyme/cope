export interface app {}
export interface TableCompraIVA {
	fecha: Date;
	tipo: string;
	comprobante: string;
	proveedor: string;
	cuit: string;
	condIva: string;
	netoGravado21: number;
	iva21: number;
	netoGravado105: number;
	iva105: number;
	netoGravado27: number;
	iva27: number;
	retIva: number;
	percIva: number;
	percIibb: number;
	impInternos: number;
	noGravadoExento: number;
	total: number;
}

export interface totalIVACompra {
	responsableInscripto: number[];
	consumidorFinal: number[];
	monotributista: number[];
	noAlcanzado: number[];
	exento: number[];
	totalGeneral: number[];
}
export interface productoServicio {
	id: string;
	producto: string;
	centroCost: string;
	observaciones: string;
	cantidad: string;
	precio: number;
	dto: number;
	importe: number;
	IVA: string;
	total: number;
}
export interface ubicacionAPIgobierno {
	id: string;
	nombre: string;
}
export interface ProvinciaState {
	cantidad: number;
	inicio: number;
	provincias: ubicacionAPIgobierno[];
	total: number;
}
export interface MunicipioState {
	cantidad: number;
	inicio: number;
	municipios: ubicacionAPIgobierno[];
	total: number;
}
export interface AddressMyType {
	apartament: string;
	building: string;
	city: string;
	floor: number | null;
	number: string;
	postalCode: number;
	province: string;
	street: string;
}
export interface ContactMyType {
	email: string;
	phone: string | null;
}
export interface clienteProveedorVer {
	id: number;
	name: string;
	cuit: string;
	vat: string;
	address: AddressMyType;
	contact: ContactMyType;
	active?: boolean;
	enabled?: boolean;
	country?: string;
	checked?: boolean;
}
export interface clienteNuevo {
	name: string;
	cuit: string;
	street: string;
	number: string;
	building: string;
	floor: number;
	apartament: string;
	province: string;
	city: string;
	postalCode: number;
	vat: string;
	country: string;
	email: string;
	phone: string;
}
export interface compraNuevo {
	proveedor: string;
	comprobante: string;
	fechaComprobante: Date | string;
	condicionPago: string;
	numero: string;
	vencimientoPago: Date | string;
}

export interface compraVer {
	id: number;
	supplierName: string; // Obligatorio
	province: string;
	invoiceType: string;
	date: string;
	expiration_date: string;
	number: string;
	paymentMethod: string;
	amount: number;
	vat: number;
	vat21: number;
	vat105: number;
	grossAmount: number;
	enabled: boolean;
}
export interface ivaLibro {
	salesInvoices?: ventaVer[];
	purchaseInvoices?: compraVer[];
	totalAmount: number;
	totalVat: number;
	totalVat21: number;
	totalVat105: number;
	totalGrossAmount: number;
	totalRetVat: number;
	totalIibb: number;
	totalInternalTaxes: number;
	totalAmountNet21: number;
	totalAmountNet105: number;
	totalAmountNet0: number;
	customerVatConditions: string | null;
}
export interface ventaVer {
	id: number;
	customerName: string;
	province: string;
	invoiceType: string;
	date: string;
	expiration_date: string;
	number: string;
	paymentMethod: string;
	amount: number;
	vat: number;
	vat21: number;
	vat105: number;
	grossAmount: number;
	enabled: boolean;
	amountNet21: number;
	amountNet105: number;
	amountNet0: number;
	retVat: number;
	iibb: number;
	internalTaxes: number;
	vatCondition: string;
	customerVatCondition: string | null;
	checked?: boolean; // Optional, as it's not in the backend data but used in the frontend
}
export interface ProcessedJournalEntry {
	id: number;
	date: string | Date;
	document?: string;
	renderLines: {
		isDebit: boolean;
		accountName: string;
		amount: number;
	}[];
	totalDebit: number;
	totalCredit: number;
}
export interface InvoiceClient {
	customerName?: string;
	supplierName?: string;
	province: string;
	invoiceType: string;
	date: string | Date; // String para formato ISO
	expirationDate: string | Date; // String para formato ISO
	number: string;
	paymentMethod: string;
	enabled: boolean;
}
export interface InvoiceProduct {
	description: string;
	additionalInfo: string;
	quantity: number;
	amount: number;
	discount: number;
	vat: number;
	grossAmount: number;
	invoiceId: string | number;
}
export interface Invoice extends InvoiceClient {
	items: InvoiceProduct[];
	customer_id?: number;
	vat?: string;
}
export interface proveedorNuevo {
	name: string;
	cuit: string;
	street: string;
	number: string;
	building: string;
	floor: number;
	apartament: string;
	province: string;
	city: string;
	postalCode: number;
	vat: string;
	country: string;
	email: string;
	phone: string;
	active: boolean;
}
export interface registerCompany {
	companyName: string;
	cuit: string;
}
export interface registerUser {
	email: string;
	password: string;
	firstName: string;
	lastName: string;
}

export interface accountForJournal {
	name: string;
	id: number | string;
	code: number;
}
export interface JournalEntryLine {
	id: number;
	amount: number;
	debitAccountId: number;
	debitAccountName?: string;
	creditAccountId: number;
	creditAccountName?: string;
}

export interface JournalEntry {
	description: string;
	date: string;
	journalEntryLines: JournalEntryLine[];
}
export interface JournalEntryResponse {
	result: string;
	errorDescription: string;
	id: number;
	date: Date;
	description: string;
	document?: string;
	journalEntryLines: {
		id: number;
		debitAccountName: string;
		creditAccountName: string;
		debitAccountId: number;
		creditAccountId: number;
		amount: number;
	}[];
}

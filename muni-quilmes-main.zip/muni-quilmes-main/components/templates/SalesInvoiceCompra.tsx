import React from "react";
import {
	Document,
	Page,
	View,
	Text,
	StyleSheet,
	Image,
} from "@react-pdf/renderer";
import { logoRedondo, logoGobierno } from "../../utils/ImageBase64";
import { compraVer, ivaLibro, ventaVer } from "@/types";
import { styles } from "./StyleTables";
import { convertValueString } from "@/utils/Functions/ValidationInputs";
import { formatDate } from "@/utils/Functions/Filters";
import { addDays } from "date-fns";

interface PDFSalesReportProps {
	totals: ivaLibro;
	type: "purchase" | "sales";
}

const PDFPurchaseInvoiceIVA: React.FC<PDFSalesReportProps> = ({
	totals,
	type,
}) => {
	return (
		<Document>
			<Page style={styles.page} orientation="landscape">
				<View style={styles.title}>
					<Text>Libro IVA compras</Text>
				</View>

				{/* Sales Invoices Table */}
				<View style={styles.table}>
					<View style={styles.tableRowHeader}>
						<Text style={styles.tableCellHeader}>Factura</Text>
						<Text style={styles.tableCellHeader}>
							{type === "purchase" ? "Proveedor" : "Cliente"}
						</Text>
						<Text style={styles.tableCellHeader}>Fecha</Text>
						<Text style={styles.tableCellHeader}>Vencimiento</Text>
						<Text style={styles.tableCellHeader}>Tipo de factura</Text>
						<Text style={styles.tableCellHeader}>Monto Bruto</Text>
						<Text style={styles.tableCellHeader}>Método de Pago</Text>
						<Text style={styles.tableCellHeader}>IVA%</Text>
						<Text style={styles.tableCellHeader}>IVA 10.5%</Text>
						<Text style={styles.tableCellHeader}>IVA 21%</Text>
						<Text style={styles.tableCellHeader}>Total</Text>
					</View>
					{totals.purchaseInvoices?.map((invoice) => (
						<View style={styles.tableRow} key={invoice.id}>
							<Text style={styles.tableCell}>{invoice.number}</Text>
							<Text style={styles.tableCell}>{invoice.supplierName}</Text>
							<Text style={styles.tableCell}>
								{formatDate(addDays(new Date(invoice.date), 1))}
							</Text>
							<Text style={styles.tableCell}>
								{formatDate(addDays(new Date(invoice.expiration_date), 1))}
							</Text>
							<Text style={styles.tableCell}>
								{convertValueString(invoice.invoiceType)}
							</Text>
							<Text style={styles.tableCell}>
								{invoice.grossAmount.toFixed(2)}
							</Text>
							<Text style={styles.tableCell}>
								{convertValueString(invoice.paymentMethod)}
							</Text>
							<Text style={styles.tableCell}>{invoice.vat.toFixed(2)}</Text>
							<Text style={styles.tableCell}>{invoice.vat105.toFixed(2)}</Text>
							<Text style={styles.tableCell}>{invoice.vat21.toFixed(2)}</Text>
							<Text style={styles.tableCell}>{invoice.amount.toFixed(2)}</Text>
						</View>
					))}
				</View>

				{/* Totals Table */}
				<View style={[styles.table, { marginTop: 20 }]}>
					<View style={styles.tableRowHeader}>
						<Text style={styles.tableCellHeader}>Categoría</Text>
						<Text style={styles.tableCellHeader}>IVA 21%</Text>
						<Text style={styles.tableCellHeader}>IVA 10.5%</Text>
						<Text style={styles.tableCellHeader}>Total IVA</Text>
						<Text style={styles.tableCellHeader}>Total</Text>
						<Text style={styles.tableCellHeader}>Importe bruto</Text>
					</View>
					<View style={styles.tableRow}>
						<Text style={styles.tableCell}>Totales</Text>
						<Text style={styles.tableCell}>{totals.totalVat21.toFixed(2)}</Text>
						<Text style={styles.tableCell}>
							{totals.totalVat105.toFixed(2)}
						</Text>
						<Text style={styles.tableCell}>{totals.totalVat.toFixed(2)}</Text>
						<Text style={styles.tableCell}>
							{totals.totalAmount.toFixed(2)}
						</Text>
						<Text style={styles.tableCell}>
							{totals.totalGrossAmount.toFixed(2)}
						</Text>
					</View>
				</View>
				<View style={styles.footer}>
					<Image src={logoGobierno} style={styles.image} />
				</View>
			</Page>
		</Document>
	);
};

export default PDFPurchaseInvoiceIVA;

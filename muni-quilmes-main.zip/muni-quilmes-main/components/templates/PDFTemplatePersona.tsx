import React from "react";
import {
	Document,
	Page,
	View,
	StyleSheet,
	Text,
	Image,
} from "@react-pdf/renderer";
import { clienteProveedorVer, ventaVer } from "@/types";
import { styles } from "./StyleTables";
import { logoRedondo, logoGobierno } from "../../utils/ImageBase64";
import { convertValueString } from "@/utils/Functions/ValidationInputs";

interface PDFComponentProps {
	row: clienteProveedorVer[];
	persona: string;
	// Propiedades de la CardComponent necesarias para generar el PDF
}

const PDFComponentPersona: React.FC<PDFComponentProps> = ({ row, persona }) => {
	return (
		<Document>
			<Page style={styles.page} orientation="landscape">
				<View style={styles.title}>
					<Text>{persona}:</Text>
				</View>
				<View style={styles.table}>
					<View style={styles.tableRowHeader}>
						<Text style={styles.tableCellHeader}>Nombre</Text>
						<Text style={styles.tableCellHeader}>CUIT</Text>
						<Text style={styles.tableCellHeader}>Condición IVA</Text>
						<Text style={styles.tableCellHeader}>Teléfono</Text>
						<Text style={styles.tableCellHeader}>Email</Text>
						<Text style={styles.tableCellHeader}>Provincia</Text>
						<Text style={styles.tableCellHeader}>Ciudad</Text>
						<Text style={styles.tableCellHeader}>Dirección</Text>
						<Text style={styles.tableCellHeader}>Unidad</Text>
						<Text style={styles.tableCellHeader}>País</Text>
					</View>
					{row.map((data) => (
						<View style={styles.tableRow} key={data.id}>
							<Text style={styles.tableCell}>{data.name}</Text>
							<Text style={styles.tableCell}>{data.cuit}</Text>
							<Text style={styles.tableCell}>
								{convertValueString(data.vat)}
							</Text>
							<Text style={styles.tableCell}>{data.contact.phone}</Text>
							<Text style={styles.tableCell}>{data.contact.email}</Text>
							<Text style={styles.tableCell}>
								{convertValueString(data.address.province)}
							</Text>

							<Text style={styles.tableCell}>
								{convertValueString(data.address.city)}
								<br></br>
								CP: {data.address.postalCode}
							</Text>
							<Text style={styles.tableCell}>
								{data.address.street}
								<br></br>
								{data.address.number}
							</Text>
							<Text style={styles.tableCell}>
								Edificio: {data.address.building}
								<br></br>
								Piso: {data.address.floor}
								<br></br>
								Departamento: {data.address.apartament}
							</Text>
							<Text style={styles.tableCell}>{data.country}</Text>
						</View>
					))}
				</View>
				<View style={styles.footer}>
					<Image src={logoGobierno} style={styles.image}></Image>
				</View>
			</Page>
		</Document>
	);
};

export default PDFComponentPersona;

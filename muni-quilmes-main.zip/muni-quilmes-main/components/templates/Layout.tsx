import { Box, Container } from "@mui/material";
import Head from "next/head";
import { FC, ReactNode } from "react";

interface ILayoutWithHeaderAndFooter {
	children?: ReactNode;
	title: string;
}

const Layout: FC<ILayoutWithHeaderAndFooter> = ({ children, title }) => {
	return (
		<>
			<Head>
				<title>{title}</title>
			</Head>
			<Box
				component={"main"}
				sx={{
					width: "100vw !important",
					display: "flex",
					flexDirection: "column",
					alignItems: "center",
					justifyContent: "center",
					background: "#7A61A2"
				}}
			>
				{children}
			</Box>
		</>
	);
};

export default Layout;

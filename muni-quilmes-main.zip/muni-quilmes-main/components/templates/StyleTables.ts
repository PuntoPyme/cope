import { StyleSheet } from "@react-pdf/renderer";

export const styles = StyleSheet.create({
	page: {
		padding: 20,
	},
	image: {
		width: 150,
		height: 50,
	},
	section: {
		margin: 10,
		padding: 10,
	},
	table: {
		display: "flex",
		width: "auto",
		borderStyle: "solid",
		borderWidth: 1,
		borderColor: "#bfbfbf",
		marginBottom: 20,
	},
	tableRowHeader: {
		flexDirection: "row",
		backgroundColor: "#f0f0f0",
		borderBottomWidth: 1,
		borderBottomColor: "#bfbfbf",
		borderBottomStyle: "solid",
	},
	tableRow: {
		flexDirection: "row",
		border: "1px solid black",
		borderTop: "none",
		width: "100%",
	},
	tableCellHeader: {
		margin: 5,
		fontWeight: "bold",
		fontSize: 10,
		width: "100%",
		display: "flex",
		justifyContent: "center",
		alignItems: "center",
		textAlign: "center",
	},
	tableCell: {
		fontSize: 10,
		width: "100%", // Ajusta el ancho de acuerdo a tus necesidades
		display: "flex",
		justifyContent: "center",
		alignItems: "center",
		textAlign: "center",
	},
	title: {
		display: "flex",
		flexDirection: "row",
		marginBottom: 30,
		alignItems: "flex-start",
		justifyContent: "flex-start",
	},
	footer: {
		display: "flex",
		flexDirection: "row",
		alignItems: "center",
		justifyContent: "flex-end",
		position: "absolute",
		bottom: "0",
		right: "0",
		width: "100vw",
		padding: "2%",
		borderTop: "1px solid gray",
	},
});

import React, { FC, useEffect, useState } from "react";
import Grid from "@mui/material/Grid";
import Navbar from "../atoms/Navbar/Navbar";
import Header from "../atoms/Header/Header";
import FooterIn from "../atoms/FooterIn/FooterIn";
import { Box, Container, Typography } from "@mui/material";
import { useRouter } from "next/router";
import { objetoPath, routerPaths } from "@/utils/routerPaths";
import { useSelector } from "react-redux";
import { RootState } from "@/Redux/store";
import { useDispatch } from "react-redux";
import { resetCodeJwtState } from "@/Redux/features/Codejwt";

interface IGenericLayout {
	children: React.ReactNode;
}

const GenericLayout: FC<IGenericLayout> = ({ children }) => {
	const { codejwt, expirationTime, creationTime } = useSelector(
		(state: RootState) => state.storeJwt
	);
	const dispatch = useDispatch();
	const router = useRouter();
	useEffect(() => {
		console.log(creationTime, expirationTime, "CREATION TIME");
		const interval = setInterval(() => {
			if (creationTime && expirationTime) {
				const timeElapsed = Date.now() - creationTime; // Tiempo transcurrido desde la creación
				const isExpired = timeElapsed >= expirationTime - creationTime;
				if (isExpired) {
					dispatch(resetCodeJwtState());
					router.push("/");
				}
			}
		}, 1000);

		return () => clearInterval(interval);
	}, [dispatch, expirationTime, creationTime, router]);

	return (
		<>
			<Box
				sx={{
					padding: "0 !important",
					margin: "0",
					width: "100vw",
					height: "90vh",
					overflowX: "scroll",
					background: "#D4D2D2",
				}}
			>
				<Navbar />
				<Box
					marginTop={"7rem"}
					width={"100vw"}
					display="flex"
					flexDirection={"column"}
					alignItems={"center"}
					justifyContent={"space-between"}
					height={"fit-content"}
				>
					{children}
				</Box>
				<FooterIn />
			</Box>
		</>
	);
};

export default GenericLayout;

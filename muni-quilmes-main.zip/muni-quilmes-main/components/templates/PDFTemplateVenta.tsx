import React from "react";
import {
	Document,
	Page,
	View,
	StyleSheet,
	Text,
	Image,
} from "@react-pdf/renderer";
import { compraVer, ventaVer } from "@/types";
import { logoGobierno } from "../../utils/ImageBase64";
import { styles } from "./StyleTables";
import { convertValueString } from "@/utils/Functions/ValidationInputs";
interface PDFComponentProps {
	row: ventaVer[] | compraVer[];
	title: "Venta" | "Compra";
	// Propiedades de la CardComponent necesarias para generar el PDF
}

const PDFComponentVenta: React.FC<PDFComponentProps> = ({ row, title }) => {
	return (
		<Document>
			<Page style={styles.page} orientation="landscape">
				<View style={styles.title}>
					<Text>{`Facturas de ${title}`}</Text>
				</View>
				<View style={styles.table}>
					<View style={styles.tableRowHeader}>
						<Text style={styles.tableCellHeader}>Número</Text>
						<Text style={styles.tableCellHeader}>Fecha</Text>
						<Text style={styles.tableCellHeader}>
							{title === "Compra" ? "Proveedor" : "Cliente"}
						</Text>
						<Text style={styles.tableCellHeader}>Tipo</Text>
						<Text style={styles.tableCellHeader}>Monto bruto</Text>
						<Text style={styles.tableCellHeader}>IVA 21%</Text>
						<Text style={styles.tableCellHeader}>Total</Text>
						<Text style={styles.tableCellHeader}>Método de pago</Text>
						<Text style={styles.tableCellHeader}>Provincia</Text>
					</View>
					{row.map((data) => (
						<View key={data.id} style={styles.tableRow}>
							<Text style={styles.tableCell}> {data.number}</Text>
							<Text style={styles.tableCell}>
								{new Date(data.date).toLocaleDateString()}
							</Text>
							<Text style={styles.tableCell}>
								{"customerName" in data
									? data.customerName
									: "supplierName" in data
									? data.supplierName
									: ""}
							</Text>
							<Text style={styles.tableCell}>
								{convertValueString(data.invoiceType)}
							</Text>
							<Text style={styles.tableCell}> {data.grossAmount}</Text>
							<Text style={styles.tableCell}> {data.vat21}</Text>
							<Text style={styles.tableCell}> {data.amount}</Text>
							<Text style={styles.tableCell}> {data.paymentMethod}</Text>
							<Text style={styles.tableCell}>
								{convertValueString(data.province)}
							</Text>
						</View>
					))}
				</View>
				<View style={styles.footer}>
					<Image src={logoGobierno} style={styles.image}></Image>
				</View>
			</Page>
		</Document>
	);
};

export default PDFComponentVenta;

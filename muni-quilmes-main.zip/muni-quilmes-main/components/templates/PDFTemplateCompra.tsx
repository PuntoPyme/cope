import React from "react";
import {
	Document,
	Page,
	View,
	StyleSheet,
	Text,
	Image,
} from "@react-pdf/renderer";
import { compraVer, ventaVer } from "@/types";
import { logoRedondo, logoGobierno } from "../../utils/ImageBase64";
import { styles } from "./StyleTables";
import { convertValueString } from "@/utils/Functions/ValidationInputs";
interface PDFComponentProps {
	row: compraVer[] | ventaVer[];
}

const PDFComponentCompra: React.FC<PDFComponentProps> = ({ row }) => {
	return (
		<Document>
			<Page style={styles.page} orientation="landscape">
				<View style={styles.title}>
					<Text>Compras:</Text>
				</View>
				<View style={styles.table}>
					<View style={styles.tableRowHeader}>
						<Text style={styles.tableCellHeader}>Factura</Text>
						<Text style={styles.tableCellHeader}>Proveedor</Text>
						<Text style={styles.tableCellHeader}>Fecha</Text>
						<Text style={styles.tableCellHeader}>Vencimiento</Text>
						<Text style={styles.tableCellHeader}>Tipo de factura</Text>
						<Text style={styles.tableCellHeader}>Monto Bruto</Text>
						<Text style={styles.tableCellHeader}>Método de Pago</Text>
						<Text style={styles.tableCellHeader}>Provincia</Text>
						<Text style={styles.tableCellHeader}>IVA%</Text>
						<Text style={styles.tableCellHeader}>IVA 10.5%</Text>
						<Text style={styles.tableCellHeader}>IVA 21%</Text>
						<Text style={styles.tableCellHeader}>Total</Text>
					</View>
					{row.map((data) => (
						<View key={data.id} style={styles.tableRow}>
							<Text style={styles.tableCell}>{data.number}</Text>
							<Text style={styles.tableCell}>
								{"customerName" in data
									? data.customerName
									: "supplierName" in data
									? data.supplierName
									: ""}
							</Text>
							<Text style={styles.tableCell}>
								{new Date(data.date).toLocaleDateString()}
							</Text>
							<Text style={styles.tableCell}>
								{new Date(data.expiration_date).toLocaleDateString()}
							</Text>
							<Text style={styles.tableCell}>
								{convertValueString(data.invoiceType)}
							</Text>
							<Text style={styles.tableCell}>{data.grossAmount}</Text>
							<Text style={styles.tableCell}>
								{convertValueString(data.paymentMethod)}
							</Text>
							<Text style={styles.tableCell}>
								{convertValueString(data.province)}
							</Text>
							<Text style={styles.tableCell}>{data.vat}</Text>
							<Text style={styles.tableCell}>{data.amount}</Text>
						</View>
					))}
				</View>
				<View style={styles.footer}>
					<Image src={logoGobierno} style={styles.image}></Image>
				</View>
			</Page>
		</Document>
	);
};

export default PDFComponentCompra;

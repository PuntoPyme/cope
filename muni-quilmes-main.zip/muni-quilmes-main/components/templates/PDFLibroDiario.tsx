import React from "react";
import {
	Document,
	Page,
	View,
	Text,
	Image,
	StyleSheet,
} from "@react-pdf/renderer";
import { logoRedondo, logoGobierno } from "../../utils/ImageBase64";

import { convertValueString } from "@/utils/Functions/ValidationInputs";
import { ProcessedJournalEntry } from "@/types";

const styles = StyleSheet.create({
	page: {
		padding: 40,
		fontSize: 12,
	},
	table: {
		width: "auto",
		borderStyle: "solid",
		borderWidth: 1,
		borderRightWidth: 0,
		borderBottomWidth: 0,
	},
	tableRow: {
		margin: "auto",
		flexDirection: "row",
	},
	tableRowHeader: {
		margin: "auto",
		flexDirection: "row",
		backgroundColor: "#f0f0f0",
	},
	tableCol: {
		width: "25%",
		borderStyle: "solid",
		borderWidth: 1,
		borderLeftWidth: 0,
		borderTopWidth: 0,
	},
	tableCell: {
		margin: "auto",
		marginTop: 5,
		fontSize: 10,
		padding: 3,
	},
	documentRow: {
		backgroundColor: "#f9f9f9",
		fontWeight: "bold",
	},
	totalRow: {
		borderTopWidth: 1,
		borderTopColor: "#000",
		fontWeight: "bold",
	},
	footer: {
		position: "absolute",
		bottom: 30,
		left: 0,
		right: 0,
		textAlign: "center",
	},
	logo: {
		width: 150,
		height: "auto",
	},
});

interface PDFLibroDiarioProps {
	entries: ProcessedJournalEntry[];
}

const PDFLibroDiario: React.FC<PDFLibroDiarioProps> = ({ entries }) => {
	const calculateTotals = () => {
		let totalDebitSum = 0;
		let totalCreditSum = 0;

		entries.forEach((entry) => {
			totalDebitSum += entry.totalDebit || 0;
			totalCreditSum += entry.totalCredit || 0;
		});

		return { totalDebitSum, totalCreditSum };
	};

	// Obtén los totales de la función
	const { totalDebitSum, totalCreditSum } = calculateTotals();
	console.log(entries);
	return (
		<Document>
			<Page style={styles.page} orientation="landscape">
				<View style={styles.table}>
					<View style={styles.tableRowHeader}>
						<View style={styles.tableCol}>
							<Text style={styles.tableCell}>Fecha</Text>
						</View>
						<View style={styles.tableCol}>
							<Text style={styles.tableCell}>Cuenta</Text>
						</View>
						<View style={styles.tableCol}>
							<Text style={styles.tableCell}>Debe</Text>
						</View>
						<View style={styles.tableCol}>
							<Text style={styles.tableCell}>Haber</Text>
						</View>
					</View>
					{entries.map((entry) => (
						<React.Fragment key={entry.id}>
							<View style={[styles.tableRow, styles.documentRow]}>
								<View style={[styles.tableCol, { width: "100%" }]}>
									<Text style={styles.tableCell}>
										Documento: {entry.document || `Asiento N° ${entry.id}`}
									</Text>
								</View>
							</View>
							{entry.renderLines.map((line, index) => (
								<View
									style={styles.tableRow}
									key={`${entry.id}-${line.accountName}-${index}`}
								>
									{index === 0 && (
										<View style={styles.tableCol}>
											<Text style={styles.tableCell}>
												{entry.date
													? new Date(entry.date).toLocaleDateString("es-ES")
													: ""}
											</Text>
										</View>
									)}
									{index !== 0 && <View style={styles.tableCol}></View>}
									<View style={styles.tableCol}>
										<Text style={styles.tableCell}>{line.accountName}</Text>
									</View>
									<View style={styles.tableCol}>
										<Text style={styles.tableCell}>
											{line.isDebit
												? convertValueString(line.amount.toFixed(2))
												: ""}
										</Text>
									</View>
									<View style={styles.tableCol}>
										<Text style={styles.tableCell}>
											{!line.isDebit
												? convertValueString(line.amount.toFixed(2))
												: ""}
										</Text>
									</View>
								</View>
							))}
							<View style={[styles.tableRow, styles.totalRow]}>
								<View style={styles.tableCol}></View>
								<View style={styles.tableCol}>
									<Text style={styles.tableCell}>Totales</Text>
								</View>
								<View style={styles.tableCol}>
									<Text style={styles.tableCell}>
										{convertValueString(entry.totalDebit.toFixed(2))}
									</Text>
								</View>
								<View style={styles.tableCol}>
									<Text style={styles.tableCell}>
										{convertValueString(entry.totalCredit.toFixed(2))}
									</Text>
								</View>
							</View>
						</React.Fragment>
					))}
					<View style={[styles.tableRow]}>
						<View style={styles.tableCol}></View>
						<View style={styles.tableCol}>
							<Text style={styles.tableCell}>Totales Generales</Text>
						</View>
						<View style={styles.tableCol}>
							<Text style={styles.tableCell}>
								{convertValueString(totalDebitSum.toFixed(2))}
							</Text>
						</View>
						<View style={styles.tableCol}>
							<Text style={styles.tableCell}>
								{convertValueString(totalCreditSum.toFixed(2))}
							</Text>
						</View>
					</View>
				</View>
				<View style={styles.footer}>
					<Image src={logoGobierno} style={styles.logo} />
				</View>
			</Page>
		</Document>
	);
};

export default PDFLibroDiario;

import React from "react";
import {
	Document,
	Page,
	View,
	StyleSheet,
	Text,
	Image,
	Link,
} from "@react-pdf/renderer";
// import imageLogo from "../../assets/logofooter.png";
import { logoRedondo, logoGobierno } from "../../utils/ImageBase64";
interface PDFComponentProps {
	instrucciones: string;
	// Propiedades de la CardComponent necesarias para generar el PDF
}

const PDFInstructivo: React.FC<PDFComponentProps> = ({ instrucciones }) => {
	const styles = StyleSheet.create({
		page: {
			padding: "5vw",
			display: "flex",
			flexDirection: "column",
			alignItems: "center",
			height: "100vh",
		},
		image: {
			width: 160,
			height: 50,
			marginRight: "20px",
			//borderRadius:'50px'
		},

		title: {
			fontSize: 20,
			fontWeight: "bold",
			marginBottom: 30,
			marginTop: 30,
			textAlign: "center",
			alignItems: "center",
		},
		content: {
			display: "flex",
			alignItems: "flex-start",
			width: "100%",
			justifyContent: "center",
			marginBottom: "1vw",
			textAlign: "center",
		},
		alignText: {
			fontSize: 15,
			width: "90%",
		},
		footer: {
			display: "flex",
			alignItems: "center",
			justifyContent: "center",
			width: "100vw",
			padding: "2%",
			borderBottom: "1px solid gray",
			paddingRight: "2vw",
		},
		link: {
			color: "blue",
			textDecoration: "underline",
		},
	});
	return (
		<Document>
			<Page style={styles.page}>
				<View style={styles.footer}>
					<Image src={logoGobierno} style={styles.image}></Image>
				</View>
				<View style={styles.alignText}>
					<Text style={styles.title}>Registro para cooperativas</Text>
				</View>
				<View style={styles.alignText}>
					<Text style={styles.content}>
						{" "}
						Para poder acceder al sistema contable-administrativo de ECOSOL La
						Cooperativa deberá estar en el Registro Municipal de Asociativismo y
						de Economía Social (REMAES).
					</Text>
					<Text style={styles.content}>
						{" "}
						Para mas información contactarse al siguiente CEL:
						<Link src="tel:+54 9 11 2686-5593" style={styles.link}>
							+54 9 11 2686-5593
						</Link>{" "}
						, vía e-mail
						<Link
							src="mailto:dir.gen.economiasocial@gmail.com"
							style={styles.link}
						>
							{" "}
							dir.gen.economiasocial@gmail.com{" "}
						</Link>
						o presencialmente hacia Punto Pyme / Oficina de Economía Social y
						Acciòn Cooperativa
						<Link
							src="https://www.google.com.ar/maps/place/Humberto+Primo+55,+B1878+Quilmes,+Provincia+de+Buenos+Aires/@-34.7257767,-58.2608565,17z/data=!3m1!4b1!4m5!3m4!1s0x95a32e6a0684ac3b:0xc1da196e377dc10!8m2!3d-34.7257811!4d-58.2582816?entry=ttu&g_ep=EgoyMDI0MTAyMy4wIKXMDSoASAFQAw%3D%3D"
							style={styles.link}
						>
							{" "}
							(HUMBERTO PRIMO 55 ESQ. SAN MARTÌN, 1er Piso)
						</Link>
						.
					</Text>
					<Text style={styles.content}> Lunes a Viernes de 08:00-14:00hs</Text>
				</View>
			</Page>
		</Document>
	);
};

export default PDFInstructivo;

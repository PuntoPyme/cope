import React, { useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { Container, Grid, IconButton, InputAdornment } from "@mui/material";
import { ButtonHome } from "../Button/Button-home/ButtonHome";
import Image from "next/image";
import { style } from "./DataFormularioStyle";
import { typographies } from "@/utils/styles/tipographies";
import logo from "../../../assets/SGC.png";
import {
	formatCUIT,
	isValidCUIT,
	isValidEmail,
} from "@/utils/Functions/ValidationInputs";
import InputContact from "../Contacto/Inputs";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import { registerCompany, registerUser } from "@/types";

import LoadingButton from "@mui/lab/LoadingButton";
import SaveIcon from "@mui/icons-material/Save";
export interface BasicModalProps {
	onUpdateUser: (user: registerUser) => void;
	onUpdateCompany: (company: registerCompany) => void;
	onSave: () => void;
	loading: boolean;
}

export default function DataFormulario({
	onUpdateUser,
	onUpdateCompany,
	onSave,
	loading,
}: BasicModalProps) {
	const [showPassword, setShowPassword] = useState({
		password: false,
		confirmPassword: false,
	});
	const [confirmPassword, setConfirmPassword] = useState<string>("");
	const [formUsuario, setFormUsuario] = useState<registerUser>({
		lastName: "",
		firstName: "",
		email: "",
		password: "",
	});
	const [formCooperative, setFormCooperative] = useState<registerCompany>({
		companyName: "",
		cuit: "",
	});

	const [formErrors, setFormErrors] = useState({
		email: false,
		cuit: false,
		password: false,
		firstName: false,
		lastName: false,
	});

	const isValidName = (name: string) => {
		return /^[a-zA-Z\s]*$/.test(name);
	};

	const handleChange = (
		event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
	) => {
		const { name, value } = event.target;
		if (name === "confirmPassword") {
			setConfirmPassword(value);
		} else {
			const updatedFormUsuario = {
				...formUsuario,
				[name]: value,
			};
			setFormUsuario(updatedFormUsuario);
			onUpdateUser(updatedFormUsuario);
		}
		if (name === "email") {
			setFormErrors((prev) => ({ ...prev, email: !isValidEmail(value) }));
		} else if (name === "firstName" || name === "lastName") {
			setFormErrors((prev) => ({ ...prev, [name]: !isValidName(value) }));
		} else if (name === "password" || name === "confirmPassword") {
			setFormErrors((prev) => ({
				...prev,
				password:
					value !==
					(name === "password" ? confirmPassword : formUsuario.password),
			}));
		}
	};

	const handleCooperativeChange = (
		event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
	) => {
		const { name, value } = event.target;
		let updatedValue: string | number = value;

		if (name === "cuit") {
			updatedValue = formatCUIT(value);
		}
		const updatedFormState = {
			...formCooperative,
			[name]: updatedValue,
		};

		if (name === "cuit") {
			setFormErrors((prev) => ({
				...prev,
				cuit: !isValidCUIT(updatedValue as string),
			}));
		}
		setFormCooperative(updatedFormState);
		onUpdateCompany(updatedFormState);
	};

	const isFormValid = () => {
		return (
			!Object.values(formErrors).some(Boolean) &&
			Object.values(formUsuario).every(Boolean) &&
			Object.values(formCooperative).every(Boolean) &&
			confirmPassword === formUsuario.password
		);
	};

	function handleClickGuardar() {
		if (isFormValid()) {
			onUpdateUser(formUsuario);
			onUpdateCompany(formCooperative);
			onSave();
		}
	}
	return (
		<Box>
			<Box
				sx={{
					display: "flex",
					width: "100%",
					justifyContent: "center",
					alignContent: "center",
					zIndex: "100",
				}}
			>
				<Image style={style.headerImage2} src={logo} alt="Imagen" priority />
			</Box>
			<Box
				sx={{
					display: "flex",
					width: "100%",
					mt: "1vw",
					mb: "5vw",
					bottom: "0",
					justifyContent: "center",
				}}
			>
				<Box sx={style.boxModal}>
					<Grid container spacing={1.5} justifyContent="center">
						<Grid item xs={6}>
							<Typography sx={typographies.inputLetter}>
								Nombre del titular
							</Typography>
							<InputContact
								large
								type="text"
								value={formUsuario.firstName}
								onChange={handleChange}
								name="firstName"
							/>
							{formErrors.firstName && (
								<Typography color="error">Campo inválido</Typography>
							)}
						</Grid>
						<Grid item xs={6}>
							<Typography sx={typographies.inputLetter}>
								Apellido del titular
							</Typography>
							<InputContact
								large
								type="text"
								value={formUsuario.lastName}
								onChange={handleChange}
								name="lastName"
							/>
							{formErrors.lastName && (
								<Typography color="error">Campo inválido</Typography>
							)}
						</Grid>
						<Grid item xs={6}>
							<Typography sx={typographies.inputLetter}>Email</Typography>
							<InputContact
								large
								name="email"
								type="email"
								value={formUsuario.email}
								onChange={handleChange}
							/>
							{formErrors.email && (
								<Typography color="error">Campo inválido</Typography>
							)}
						</Grid>
						<Grid item xs={6}>
							<Typography sx={typographies.inputLetter}>
								Nombre de la cooperativa
							</Typography>
							<InputContact
								large
								type="text"
								name="companyName"
								value={formCooperative.companyName}
								onChange={handleCooperativeChange}
							/>
						</Grid>
						<Grid item xs={6}>
							<Typography sx={typographies.inputLetter}>CUIT</Typography>
							<InputContact
								large
								type="text"
								name="cuit"
								value={formCooperative.cuit}
								onChange={handleCooperativeChange}
							/>
							{formErrors.cuit && (
								<Typography color="error">Campo inválido</Typography>
							)}
						</Grid>
						<Grid item xs={6}>
							<Typography sx={typographies.inputLetter}>Contraseña</Typography>
							<InputContact
								large
								name="password"
								type={showPassword ? "text" : "password"}
								value={formUsuario.password}
								onChange={handleChange}
								InputProps={{
									endAdornment: (
										<InputAdornment position="end">
											<IconButton
												onClick={() =>
													setShowPassword((prev) => ({
														...prev,
														password: !prev.password,
													}))
												}
												edge="end"
											>
												{showPassword ? (
													<VisibilityIcon />
												) : (
													<VisibilityOffIcon />
												)}
											</IconButton>
										</InputAdornment>
									),
								}}
							/>
						</Grid>
						<Grid item xs={6}>
							<Typography sx={typographies.inputLetter}>
								Repetir contraseña
							</Typography>
							<InputContact
								large
								name="confirmPassword"
								type={showPassword ? "text" : "password"}
								onChange={handleChange}
								value={confirmPassword}
								InputProps={{
									endAdornment: (
										<InputAdornment position="end">
											<IconButton
												onClick={() =>
													setShowPassword((prev) => ({
														...prev,
														confirmPassword: !prev.confirmPassword,
													}))
												}
												edge="end"
											>
												{showPassword ? (
													<VisibilityIcon />
												) : (
													<VisibilityOffIcon />
												)}
											</IconButton>
										</InputAdornment>
									),
								}}
							/>
							{formErrors.password && (
								<Typography color="error">
									Las contraseñas no coinciden
								</Typography>
							)}
						</Grid>
					</Grid>
					<Container sx={style.buttonStyle}>
						<LoadingButton
							onClick={() => {
								handleClickGuardar();
							}}
							disabled={!isFormValid()}
							sx={{
								minWidth: "fit-content",
								background:
									"linear-gradient(90deg, #3C316C 22.14%, #7A61A1 99.97%) !important",
								color: "white",
								borderRadius: "40px",
								px: "2%",
							}}
							loading={loading}
							loadingPosition="start"
							startIcon={<SaveIcon />}
						>
							Registrarse
						</LoadingButton>
					</Container>
				</Box>
			</Box>
		</Box>
	);
}

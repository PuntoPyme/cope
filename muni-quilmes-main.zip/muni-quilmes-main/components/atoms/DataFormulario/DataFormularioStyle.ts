import { CSSProperties } from "@mui/styles";
export const style: Record<string, CSSProperties> = {
	buttonStyle: {
		display: "flex",
		bottom: "3vw !important",
		height: "100% !important",
		justifyContent: "center",
		alignItems: "center",
		marginTop: "3rem",
	},
	inputsStyle: {
		margin: "%",
		justifyContent: "center",
		alignItems: "center",
		textAlign: "center",
	},
	headerImage: {
		width: "100%",
		height: "100%",
		"@media (maxWidth: 780px)": {
			width: "50%",
			height: "50vh",
		},
	},
	headerImage2: {
		width: "10%",
		height: "unset",
	},

	boxModal: {
		position: "relative",
		display: "flex",
		flexDirection: "column",
		alignItems: "center",
		justifyContent: "center",
		textAlign: "center",
		width: "50%",
		borderRadius: "4%",
		overflow: "hidden",
		padding: "8%",
		fontSize: "vw !important",
		background:
			"linear-gradient(180.08deg, #D9D9D9 0%, rgba(255, 255, 255, 0.5) 100%)",
		"& .MuiTypography-root": {
			marginTop: "0.5vw ",
		},
		"@media (max-width: 420px)": {
			borderRadius: "2vw",
			height: "85vw !important",
			["& .MuiOutlinedInput-root"]: {
				height: "6vw",
			},
			"& .MuiTypography-root": {
				marginTop: "1rem !important",
			},
		},
	},
};

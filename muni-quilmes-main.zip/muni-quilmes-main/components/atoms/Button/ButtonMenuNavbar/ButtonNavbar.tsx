import { Button, SvgIconProps } from "@mui/material";
import { useRouter } from "next/router";
import React, { ReactNode } from "react";

export interface ButtonNavbarProps {
	onClick: (event: any) => void;
	Icon: React.ComponentType<SvgIconProps>;
	sx?: object;
	title: string;
	dropdownIcon?: ReactNode;
}
export const ButtonNavbar = ({
	onClick,
	Icon,
	dropdownIcon,
	title,
}: ButtonNavbarProps) => {
	const routerString = useRouter();
	const currentPath = routerString.asPath.split("/")[1];
	const normalizeAndCompare = (str1: string, str2: string) => {
		const normalizeString = (str: string) => {
			return str.replace(/\s+/g, "").replace(/\//g, "").toLowerCase();
		};

		const normalizedStr1 = normalizeString(str1);
		const normalizedStr2 = normalizeString(str2);
		return normalizedStr1 === normalizedStr2;
	};
	return (
		<>
			<Button
				onClick={onClick}
				sx={{
					color: normalizeAndCompare(currentPath, title) ? "black" : "white",
					textTransform: "capitalize",
					fontSize: "1vw",
					whiteSpace: "nowrap",
					fontWeight: "800",
					borderRadius: "40px",
					background: normalizeAndCompare(currentPath, title)
						? "#ffffff90"
						: "transparent",
					":hover": {
						background: "#ffffff90",
						color: "black",
					},
				}}
			>
				<Icon sx={{ marginRight: "2%" }} />
				{title}
				{dropdownIcon ? dropdownIcon : null}
			</Button>
		</>
	);
};

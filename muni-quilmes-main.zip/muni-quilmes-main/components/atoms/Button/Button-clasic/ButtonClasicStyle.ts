import { CSSProperties } from "@mui/styles";
export const ButtonClasicStyles: Record<string, CSSProperties> = {
	button: {
		minWidth: "fit-content",
		whiteSpace: "pre",
		fontFamily: "poppins",
		width: "80% !important",
		height: "3rem",
		borderRadius: "40px",
		textTransform: "capitalize",
		border: "1px solid #7A61A1",
		fontSize: "1rem",
		fontWeight: "500",
		"&:hover": {
			background: "white",
		},
	},
	primary: {
		background: "#7A61A1",
		color: "white",
		"&:hover": {
			background: "#7A61A1",
		},
	},
	secondary: {
		color: "#674D8B",
		background: "white",
	},
};

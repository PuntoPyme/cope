import React from "react";
import { Button } from "@mui/material";
import { ButtonClasicStyles } from "./ButtonClasicStyle";

export interface ButtonClasicProps {
	children: React.ReactNode;
	onClick?: React.MouseEventHandler<HTMLButtonElement>;
	disabled?: boolean;
	primary: boolean;
}
export const ButtonClasic = ({
	children,
	primary,
	...props
}: ButtonClasicProps) => {
	const styleMode = primary
		? ButtonClasicStyles.primary
		: ButtonClasicStyles.secondary;
	return (
		<Button sx={{ ...ButtonClasicStyles.button, ...styleMode }} {...props}>
			{children}
		</Button>
	);
};

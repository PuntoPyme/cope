import { Button } from "@mui/material";
import React from "react";
import Styles from "./ButtonIconStyle";
import { typographies } from "../../../../utils/styles/tipographies";

export interface ButtonIconProps {
	onClick?: () => void;
	children: string | undefined;
	startIcon?: React.ReactNode | undefined;
	sx?: object;
}
export const ButtonIcon = ({
	children,
	onClick,
	startIcon,
}: ButtonIconProps) => {
	return (
		<>
			<Button sx={[Styles.buttonIcon]} onClick={onClick} startIcon={startIcon}>
				+ {children}
			</Button>
		</>
	);
};

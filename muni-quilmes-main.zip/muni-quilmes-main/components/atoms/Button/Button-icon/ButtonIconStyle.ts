import { CSSProperties } from "@mui/styles";

const Styles: Record<string, CSSProperties> = {
	buttonIcon: {
		minWidth: "fit-content",
		whiteSpace: "pre",
		fontFamily: "poppins",
		fontWeight: 300,
		width: "80% ",
		height: "5vh",
		borderRadius: "40px",
		textTransform: "capitalize",
		border: "1px solid #7A61A1",
		color: "white",
		fontSize: "1rem",
		background: "#7A61A1",
		"&:hover": {
			background: "#7A61A1",
		},
	},
};

export default Styles;

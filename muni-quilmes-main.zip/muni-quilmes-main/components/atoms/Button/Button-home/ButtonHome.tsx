import { Button } from "@mui/material";
import { ButtonHomeStyles } from "./ButtonHomeStyle";
import { typographies } from "@/utils/styles/tipographies";

interface ButtonHomeProps {
	primary?: boolean;
	backgroundColor?: string;
	size?: "small" | "medium" | "large";
	children?: React.ReactNode;
	onClick?: () => void;
	link?: string;
	style?: React.CSSProperties;
	disabled?: boolean;
	type?: "button" | "submit" | "reset";
}
export const ButtonHome = ({
	primary = false,
	children,
	disabled,
	size = "medium",
	link,
	type = "button",
	...props
}: ButtonHomeProps) => {
	const mode = primary ? ButtonHomeStyles.primary : ButtonHomeStyles.secondary;
	return (
		<Button
			type={type}
			href={link}
			disabled={disabled}
			disableElevation
			disableRipple
			sx={[ButtonHomeStyles.buttonHome, mode, typographies?.sidebarLine]}
			{...props}
		>
			{children}
		</Button>
	);
};

import { CSSProperties } from "@mui/styles";
import { gradients } from "@/utils/styles/gradients";
export const ButtonHomeStyles: Record<string, CSSProperties> = {
	buttonHome: {
		whiteSpace: "pre",
		height: "100%",
		width: "100%",
		fontStyle: "normal",
		fontWeight: 300,
		/*fontFamily: typographies?.allVariants?.fontFamily?.split(",")[2],*/
		fontSize: "1.5vw !important",
		lineHeight: "30px",
		textTransform: "capitalize",
		color: "#FFFFFF !important",
		borderRadius: "50px !important",
		position: "relative",
		letterSpacing: ".0rem",
		minWidth: "fit-content",
	},
	primary: {
		background:
			"linear-gradient(90deg, #3C316C 22.14%, #7A61A1 99.97%) !important",
		whiteSpace: "pre",
		"&:hover": {
			backgroundColor: gradients.gradientGreen,
		},
	},
	secondary: {
		background: "#939393 !important",
	},
};

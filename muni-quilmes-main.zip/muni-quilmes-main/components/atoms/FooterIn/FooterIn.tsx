import * as React from "react";
import { style } from "./FooterInStyle";
import Box from "@mui/material/Box";
import image from "../../../assets/logofooter.png";
import Image from "next/image";

const FooterIn = () => {
	return (
		<>
			<Box sx={style.footerSb}>
				<Box sx={style.box2}>
					<Image style={style.img} src={image} alt="Imagen" priority={true} />
				</Box>
			</Box>
		</>
	);
};

export default FooterIn;

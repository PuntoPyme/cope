import { CSSProperties } from "@mui/styles";

export const style: Record<string, CSSProperties> = {
	footerSb: {
		width: "100vw",
		bottom: "0",
		height: "fit-content",
		background: "white",
		borderTop: "1px solid #ccc",
		position: "fixed",
	},
	img: {
		width: "10%",
		height: "unset",
		position: "relative",
	},
	box2: {
		height: "5vw",
		paddingLeft: "2vw",
		display: "flex",
		alignItems: "center",
	},
};

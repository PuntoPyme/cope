import { Avatar as AvatarMUI, Stack, useTheme } from "@mui/material";
import { colors } from "../../../utils/styles/colors";
import CSS from "csstype";
import React from "react";

export interface IAvatarListProps {
	children?: string;
	className?: string;
}

const AvatarList: React.FC<IAvatarListProps> = ({ children }) => {
	const theme = useTheme();
	let styles: CSS.Properties = {
		color: "black",
		background: colors.violet.light,
		border: `.1vw solid ${colors.violet.dark}`,
		width: "2vw",
		height: "2vw",
		marginLeft: window.innerWidth < 768 ? "30%" : "0%",
		cursor: "pointer",
		zIndex: 10,
		fontSize: window.innerWidth > 1000 ? "1rem" : ".5rem",

	};
	return (
		<>
			<Stack direction="row" spacing={2}>
				<AvatarMUI sx={{ ...styles }}>{children}</AvatarMUI>
			</Stack>
		</>
	);
};

export default AvatarList;

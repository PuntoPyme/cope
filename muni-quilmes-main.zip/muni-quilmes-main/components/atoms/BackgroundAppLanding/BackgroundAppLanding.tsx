import Image, { StaticImageData } from "next/legacy/image";
import Imagebackground from "../../../assets/Contabilidad.jpg";
import { Box } from "@mui/material";
import { styles } from "./styleLanding";

export interface IBackgroundProps {
	backgroundImage?: string | StaticImageData;
}

const BackgroundLanding: React.FC<IBackgroundProps> = ({ backgroundImage }) => (
	<Box sx={styles.degrade}>
		<Box sx={styles.bgWrap}>
			<Image
				priority={true}
				alt="QuilmesCoop"
				src={backgroundImage ? backgroundImage : Imagebackground}
				layout="fill"
				objectFit="cover"
				quality={100}
			/>
		</Box>
	</Box>
);

export default BackgroundLanding;

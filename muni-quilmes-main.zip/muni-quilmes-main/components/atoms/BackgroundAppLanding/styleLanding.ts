export const styles = {
	bgWrap: {
		background:
			"linear-gradient(90deg, rgba(0, 0, 0, 0.02) 0%, rgba(0, 0, 0, 0.60) 100%)",
		position: "relative",
		width: "99vw",
		height: "590px",
		overflow: "hidden",
		zIndex: "-1",
		borderRadius: "40px",
	},
	degrade: {
		background: "linear-gradient(to right, #00000095 20%, transparent 100%);",
		width: "99vw",
		height: "100%",
		borderRadius: "40px",
	},
};

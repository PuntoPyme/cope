import React from "react";
import { Card, CardContent, Typography, Box, Grid, Link } from "@mui/material";
import { padding, styled } from "@mui/system";
import { Language, LinkedIn, WhatsApp, Instagram } from "@mui/icons-material";
import gaia3 from "@assets/gaia2.png";
import gaia2 from "@assets/gai1.png";
import gaia1 from "@assets/gaialogo.png";
import teo3 from "@assets/teo3.png";
import teo2 from "@assets/teo2.png";
import teo1 from "@assets/teo1.png";
import agosto3 from "@assets/1rodeagostoo.png";
import agosto2 from "@assets/1roagosto.png";
import agosto1 from "@assets/1rodeagostologo.png";
import Image from "next/image";

const StyledCard = styled(Card)(({ theme }) => ({
	maxWidth: 1100,
	margin: "auto",
	padding: "0.5%",
	borderRadius: "40px",
	backgroundColor: theme.palette.white,
}));

const SocialIcon = styled(Link)(({ theme }) => ({
	color: theme.palette.text.secondary,
	marginRight: theme.spacing(2),
	"&:hover": {
		color: theme.palette.primary.main,
	},
}));

const gaiaData = [
	{
		nombre: "Teo Coop",
		descripcion: "Cooperativa de desarrollo de software",
		detalles:
			"Esta cooperativa se encarga del desarrollo de aplicaciones web, mobile, sistemas de gestion, staff aumentation, entre otras. Las principales tecnologías con las cuales trabajan son Javascript, React js, Node js, Python y Elixir.",
		contacto: {
			telefono: "116231604",
			email: "juanp.palacios@teocoop.site",
		},
		socialLinks: [
			{ icon: <Language />, href: "#" },
			{ icon: <LinkedIn />, href: "#" },
			{ icon: <WhatsApp />, href: "#" },
			{ icon: <Instagram />, href: "#" },
		],
		imagenes: [teo1, teo2, teo3],
	},
	{
		nombre: "Gaia",
		descripcion: "Cooperativa de desarrollo de software",
		detalles:
			"Esta cooperativa se encarga del desarrollo de páginas web, aplicaciones mobile, entre otras. Las principales tecnologías con las cuales trabajan son Javascript, React js, Node js, Python y Elixir.",
		contacto: {
			telefono: "1150424860",
			email: "contacto@gaiacoop.tech",
		},
		socialLinks: [
			{ icon: <Language />, href: "#" },
			{ icon: <LinkedIn />, href: "#" },
			{ icon: <WhatsApp />, href: "#" },
			{ icon: <Instagram />, href: "#" },
		],
		imagenes: [gaia1, gaia2, gaia3],
	},
	{
		nombre: "1° de Agosto",
		descripcion: "Cooperativa de pintureria",
		detalles:
			"Servicios de arenado, granallado, pintura epoxi, fabricación de la Línea Móvil Clima, chapa y pintura",
		contacto: {
			telefono: "1149725502",
			email: "contacto@gaiacoop.tech",
		},
		socialLinks: [
			{ icon: <Language />, href: "#" },
			{ icon: <LinkedIn />, href: "#" },
			{ icon: <WhatsApp />, href: "#" },
			{ icon: <Instagram />, href: "#" },
		],

		imagenes: [agosto1, agosto2, agosto3],
	},
];

export default function GaiaCard() {
	return (
		<Box>
			{gaiaData.map((data, index) => (
				<Box key={index} pb={4}>
					{" "}
					<StyledCard>
						<CardContent>
							<Grid container spacing={3}>
								<Grid item xs={12} md={6}>
									<Typography
										variant="h4"
										component="h2"
										gutterBottom
										sx={{
											fontFamily: "Poppins, sans-serif",
											fontWeight: "bold",
										}}
									>
										{data.nombre}
									</Typography>
									<Typography
										variant="h6"
										color="textSecondary"
										gutterBottom
										sx={{
											fontFamily: "Poppins, sans-serif",
											fontWeight: "medium",
										}}
									>
										{data.descripcion}
									</Typography>
									<Typography
										variant="body1"
										paragraph
										sx={{
											fontFamily: "Poppins, sans-serif",
											fontWeight: "light",
										}}
									>
										{data.detalles}
									</Typography>
									<Box mb={2}>
										<Typography
											variant="body2"
											color="textSecondary"
											sx={{
												fontFamily: "Poppins, sans-serif",
												fontWeight: "light",
											}}
										>
											📞 {data.contacto.telefono}
										</Typography>
										<Typography
											variant="body2"
											color="textSecondary"
											sx={{
												fontFamily: "Poppins, sans-serif",
												fontWeight: "light",
											}}
										>
											✉️ {data.contacto.email}
										</Typography>
									</Box>
									<Box>
										{data.socialLinks.map((link, index) => (
											<SocialIcon
												href={link.href}
												target="_blank"
												rel="noopener"
												key={index}
											>
												{link.icon}
											</SocialIcon>
										))}
									</Box>
								</Grid>
								<Grid item xs={12} md={6}>
									<Box
										display="flex"
										flexDirection="row"
										sx={{
											justifyContent: "center",
											alignItems: "center",
											height: "100%",
										}}
									>
										{data.imagenes.map((imagen, index) => (
											<Image
												key={index}
												style={{
													width: "30%",
													height: "auto",
													padding: "1%",
													borderRadius: "40px",
												}}
												src={imagen}
												alt="Imagen"
											/>
										))}
									</Box>
								</Grid>
							</Grid>
						</CardContent>
					</StyledCard>
				</Box>
			))}
		</Box>
	);
}

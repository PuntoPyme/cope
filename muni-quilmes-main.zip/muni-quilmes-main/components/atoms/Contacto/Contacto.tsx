import { useEffect, useRef, useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { Container, TextField, Grid, Button, Input } from "@mui/material";
import { style } from "./ContactoStyle";
import { ButtonHome } from "../Button/Button-home/ButtonHome";
import emailjs from "@emailjs/browser";
import InputContact from "./Inputs";

export interface BasicModalProps {
	labelName?: string;
	labelMail?: string;
	labelCelular?: string;
	labelUbicacion?: string;
	labelMensaje?: string;
}
const formStateInitialValue = {
	name: "",
	mail: "",
	phone: 0,
	message: "",
	location: "",
};
export default function BasicModal({
	labelName,
	labelMail,
	labelCelular,
	labelUbicacion,
	labelMensaje,
}: BasicModalProps) {
	const [formState, setFormState] = useState<{
		name: string;
		mail: string;
		location: string;
		phone: number;
		message: string;
	}>(formStateInitialValue);
	const nameRegex = /^[a-zA-Z]+$/;
	const mailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
	const isMailValid = mailRegex.test(formState.mail);
	const errorMessage = "Inválido";
	const [disabledButton, setDisabledButon] = useState<boolean>(false);
	const handleInputChange = (
		event: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>
	) => {
		const { name, value } = event.target;
		setFormState((prevState) => ({
			...prevState,
			[name]: value,
		}));
	};

	const form = useRef<HTMLFormElement>(null);
	const sendEmail = (e: React.FormEvent<HTMLFormElement>) => {
		console.log("ejecuta");
		e.preventDefault();
		if (form.current) {
			emailjs
				.sendForm(
					"service_xylsc1a",
					"template_yo50453",
					form.current,
					"YLioAFg8Tc7cYR5_g"
				)
				.then((result: any) => {
					form.current && form.current.reset();
					if (result.status === 200) {
						setFormState(formStateInitialValue);
					}
				});
		}
	};
	useEffect(() => {
		if (
			formState.name.length > 0 &&
			isMailValid &&
			formState.message.length > 10
		) {
			setDisabledButon(true);
		}
	}, [formState, isMailValid]);
	return (
		<form ref={form} onSubmit={sendEmail}>
			<Grid container sx={style.boxModal} id="contacto">
				<Grid
					item
					xs={12}
					sx={{
						display: "flex",
						justifyContent: "center",
						alignItems: "center",
						flexDirection: "column",
						marginBottom: "5%",
						height: "20% !important",
					}}
				>
					<Typography sx={style.contactTittle}>{"Contacto"}</Typography>
					<Box
						sx={{
							width: "15vw !important",
							background: "pink",
							height: ".5vw",
							borderRadius: "20px",
						}}
					/>
				</Grid>
				<Grid item xs={12}>
					<Grid
						container
						display="flex"
						alignItems={"center"}
						justifyContent={"center"}
						sx={{ padding: "0 5%", height: "60%" }}
					>
						{/* --------------------------GRID DE LA IZQUIERDA -----------------------*/}
						<Grid item xs={6}>
							<Box flexDirection={"column"} display="flex">
								<Typography sx={style.contactLabel}>{labelName}</Typography>
								<Box display={"flex"} alignItems={"center"}>
									<InputContact
										type="string"
										name="name"
										value={formState.name}
										onChange={handleInputChange}
									/>
								</Box>
							</Box>
							<Box flexDirection={"column"} display="flex">
								<Typography sx={style.contactLabel}>{labelCelular}</Typography>
								<Box display={"flex"} alignItems={"center"}>
									<InputContact
										type="number"
										name="phone"
										value={formState.phone}
										onChange={handleInputChange}
									/>
								</Box>
							</Box>
						</Grid>
						{/* --------------------------GRID DE LA DERECHA -----------------------*/}
						<Grid item xs={6}>
							<Box flexDirection={"column"} display="flex">
								<Typography sx={style.contactLabel}>{labelMail}</Typography>
								<Box display={"flex"} alignItems={"center"}>
									<InputContact
										type="email"
										name="mail"
										value={formState.mail}
										onChange={handleInputChange}
									/>

									{!isMailValid && formState.mail.length > 0 && (
										<Typography
											variant="caption"
											color="error"
											sx={{
												marginLeft: "2%",
												fontSize: { xs: "1.5vw", md: "2vw" },
											}}
										>
											{errorMessage}
										</Typography>
									)}
								</Box>
							</Box>
							<Box flexDirection={"column"} display="flex">
								<Typography sx={style.contactLabel}>
									{labelUbicacion}
								</Typography>
								<InputContact
									type="string"
									name="location"
									value={formState.location}
									onChange={handleInputChange}
								/>
							</Box>
						</Grid>
						<Grid
							item
							xs={12}
							height={"40%"}
							sx={{ minHeight: "fit-content", height: "20vh" }}
						>
							<Typography sx={style.contactLabel}>{labelMensaje}</Typography>
							<InputContact
								type="string"
								large={true}
								name="message"
								value={formState.message}
								onChange={handleInputChange}
							/>
						</Grid>
					</Grid>
				</Grid>
				<Grid
					item
					xs={12}
					sx={{
						display: "flex",
						justifyContent: "center	",
						marginTop: "2rem",
						width: "100vw",
						alignItems: "center",
						heigth: "10% !important",
						my: "3%",
					}}
				>
					<Box width={"25%"} height={"3vw"}>
						<ButtonHome primary={true} type="submit" disabled={!disabledButton}>
							Enviar
						</ButtonHome>
					</Box>
				</Grid>
			</Grid>
		</form>
	);
}

BasicModal.defaultProps = {
	labelName: "Nombre",
	labelMail: "Mail",
	labelCelular: "Teléfono",
	labelUbicacion: "Ubicación",
	labelMensaje: "Mensaje",
};

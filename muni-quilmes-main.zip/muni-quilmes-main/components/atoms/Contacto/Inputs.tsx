import { TextField } from "@mui/material";
import * as React from "react";

interface InputContactProps {
	name: string;
	onChange: (
		event: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>
	) => void;
	value: string | number;
	type: string;
	large?: boolean;
	InputProps?: object;
}

const InputContact: React.FC<InputContactProps> = ({
	name,
	onChange,
	type,
	value,
	large,
	InputProps,
}) => {
	const handleChange = (
		e: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>
	) => {
		onChange(e); // Llama a la función del padre con el evento de cambio
	};

	return (
		<TextField
			type={type}
			InputProps={{
				...InputProps, // Pasa InputProps directamente aquí
				inputProps: {
					style: { MozAppearance: "textfield" },
				},
			}}
			sx={{
				width: large ? "93%" : "90%",
				height: large ? "50%" : { xs: "7vw", sm: "3.5vw" },
				borderRadius: "20px",
				background: "white",
				overflow: "hidden",
				paddingLeft: "5%",
				border: "1px solid gray",
				".MuiInputBase-input": {
					fontSize: { xs: "1.5vw" },
					padding: "0",
					height: large ? "5vh" : { xs: "7vw", sm: "4vw" },
					width: "100% !important",
					paddingLeft: "2vh",
					"&:-webkit-autofill": {
						WebkitBoxShadow: "0 0 0 1000px white inset",
						WebkitTextFillColor: "black",
						caretColor: "black",
					},
				},
				"& .MuiOutlinedInput-root": {
					"& fieldset": {
						border: "none", // Elimina el borde
					},
				},
				"& input::-webkit-outer-spin-button, & input::-webkit-inner-spin-button":
					{
						WebkitAppearance: "none", // Para Chrome, Safari y Edge
						margin: 0,
					},
				"& input": {
					MozAppearance: "textfield", // Para Firefox
				},
			}}
			name={name}
			value={value}
			onChange={handleChange} // Maneja el cambio de valor
		/>
	);
};

export default InputContact;

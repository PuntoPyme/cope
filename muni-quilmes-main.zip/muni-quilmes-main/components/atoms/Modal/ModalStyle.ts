import { CSSProperties } from "@mui/styles";
export const style: Record<string, CSSProperties> = {
	modal: {
		background: "#00000080",
		display: "flex",
		alignItems: "flex-start",
		justifyContent: "center",
		overflowY: "auto",
		height: "100vh",
		minHeight: "fit-content !important",
		"&::-webkit-scrollbar": {
			width: "8px",
			backgroundColor: "#7A61A1",
		},
		"&::-webkit-scrollbar-thumb": {
			backgroundColor: "#fff",
			borderRadius: "4px",
		},
	},
	scrollContainer: {
		overflowY: "hidden",
		background: "white",
		padding: "0 2%",
		borderRadius: "40px",
		height: "fit-content",
		margin: "2% 0",
	},
};

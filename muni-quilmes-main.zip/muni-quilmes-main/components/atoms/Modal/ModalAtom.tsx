import { Box, Modal } from "@mui/material";
import React, { ReactElement, useEffect, useState, FC } from "react";
import { style } from "./ModalStyle";
interface modalInterface {
	children: ReactElement;
	openProp: boolean;
}

export const ModalComponent: FC<modalInterface> = ({ children, openProp }) => {
	const [open, setOpen] = useState(false);

	const handleCloseModal = () => {
		setOpen(false);
	};
	return (
		<Modal
			sx={style.modal}
			open={openProp}
			onClose={handleCloseModal}
			aria-labelledby="modal-modal-title"
			aria-describedby="modal-modal-description"
		>
			<Box
				display={"flex"}
				alignItems={"flex-end"}
				justifyContent={"center"}
				flexDirection={"column"}
				sx={style.scrollContainer}
			>
				{children}
			</Box>
		</Modal>
	);
};

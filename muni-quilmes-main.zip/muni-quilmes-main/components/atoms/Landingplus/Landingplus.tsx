import { Box, Grid, Typography } from "@mui/material";
import Script from "next/script";
import image from "../../../assets/compu.png";
import image2 from "../../../assets/celusig.png";
import Image from "next/image";
import { style } from "./LandingplusStyle";
import Footer from "../Footer/Footer";

const Landingplus = () => {
	return (
		<>
			<Box
				sx={{
					width: "100%",
					height: "auto",
					background:
						"linear-gradient(0.03deg, #000000 -36.61%, #040709 42.83%, #FFFFFF 75.78%)",
					"@media (max-width: 900px)": {},
				}}
			>
				<br></br>
				<br></br>
				<br></br>
				<br></br>
				<Box>
					<Typography
						sx={{
							fontFamily: "Poppins, sans-serif",
							fontSize: "100px",
							lineHeight: "25px",
							textAlign: "center",
							color: "black",
							justifyContent: "flexStart",
							position: "relative",
							padding: "3rem",
							"@media (maxWidth: 900px)": {
								fontSize: "50px",
							},
							"@media (minWidth: 900px) and (max-width: 1400px)": {
								fontSize: "60px",
							},
						}}
					>
						{"¿Por qué SIGCHA?"}
					</Typography>
					<br></br>
					<br></br>

					<Grid container spacing={0} alignItems="center">
						<Grid item xs={7}>
							<Image
								style={{
									width: "100%",
									height: "unset",
									position: "relative",
								}}
								src={image}
								alt="Imagen1"
							/>
						</Grid>
						<Grid item xs={4}>
							<Typography
								sx={{
									fontFamily: "Poppins, sans-serif",
									fontSize: "24px",
									margin: "%",
									color: "black",
									position: "relative",
									textAlign: "center",
									"@media (maxWidth: 900px)": {
										fontSize: "20px",
									},
									"@media (minWidth: 900px) and (max-width: 1400px)": {
										fontSize: "30px",
									},
								}}
							>
								{
									"El SIGCHA organiza de una manera coherente la información económica y técnica de chacras hortícolas,  para proyectar escenarios futuros y evaluar sus resultados económicos, respondiendo a preguntas del tipo “¿qué pasa si?” (por ej. ¿qué pasa si se pierde la cosecha de tomates de junio producto de la sequía? ¿qué pasa si aumentan en un 50% los precios de los fertilizantes en agosto?). "
								}
							</Typography>
						</Grid>
					</Grid>
					<Typography sx={style.headerH5}>
						{
							"El SIGCHA busca potenciar la posibilidad del sector hortícola de planificar a corto, mediano y largo plazo, tomar decisiones basadas en datos para mejorar su rentabilidad y, con ello, tender hacia modelos productivos sustentables en el tiempo desde un punto de vista económico, social y ambiental."
						}
					</Typography>
				</Box>
				<Box id="funcionalidadess">
					<br></br>
					<br></br>
					<br></br>
					<br></br>
					<br></br>
					<br></br>
					<br></br>{" "}
					<Typography
						sx={{
							fontFamily: "Poppins, sans-serif",
							fontSize: "90px",
							lineHeight: "25px",
							textAlign: "center",
							color: "white",
							justifyContent: "flexStart",
							position: "relative",
							"@media (maxWidth: 900px)": {
								fontSize: "60px",
							},
							"@media (min-width: 900px) and (max-width: 1050px)": {
								fontSize: "75px",
							},
						}}
					>
						{"Funcionalidades"}
					</Typography>
					<br></br>
					<br></br>
					<Grid container spacing={3} alignItems="center">
						<Grid item xs={5}>
							<Typography sx={style.headerH4}>
								{
									"El SIGCHA es una plataforma que habilita a los usuarios a crear distintas simulaciones. Dentro de cada una de ellas, los usuarios podrán:"
								}
							</Typography>
							<Typography sx={style.headerH4}>
								<Box>
									<ul>
										<li>
											Cargar el calendario de siembra futuro de todos sus
											cultivos y visualizarlo en los distintos sectores que
											disponga en su terreno.
										</li>
										<br></br>
										<li>
											Visualizar la proyección de las cantidades cosechadas de
											los distintos cultivos a lo largo del escenario simulado.
										</li>
									</ul>
								</Box>
							</Typography>
						</Grid>

						<Grid item xs={7}>
							<Image
								style={{
									width: "80%",
									height: "unset",
									position: "relative",
								}}
								src={image2}
								alt="Imagen2"
							/>
						</Grid>
					</Grid>
					<Typography sx={style.headerH4}>
						<Box>
							<ul>
								<li>
									Proyectar precios e ingresos ya que SIGCHA se vale de modelos
									estadísticos para realizar proyecciones de precios de los
									distintos cultivos hortícolas. De este modo, habilita al
									usuario a calcular el monto de sus ingresos futuros a lo largo
									del tiempo.
								</li>
								<br></br>
								<li>
									Sistematizar los principales egresos de tu actividad a lo
									largo del tiempo ya que la app habilita a los usuarios a
									cargar información sobre los principales egresos de su
									actividad a lo largo del período simulado
								</li>
								<br></br>
								<li>Evaluar los resultados económicos de las simulaciones</li>
							</ul>
						</Box>
					</Typography>
					<Footer></Footer>
				</Box>
			</Box>
		</>
	);
};
export default Landingplus;

import { CSSProperties } from "@mui/styles";
export const style: Record<string, CSSProperties> = {
	headerH5: {
		fontFamily: "Poppins, sans-serif",
		fontSize: "25px",
		margin: "7%",
		color: "black",
		position: "relative",
		textAlign: "center",

		"@media (max-width: 900px)": {
			fontSize: "15px",
		},
		"@media (min-width: 900px) and (max-width: 1400px)": {
			fontSize: "30px",
		},
	},
	headerH4: {
		fontFamily: "Poppins, sans-serif",
		fontSize: "25px",
		color: "white",
		margin: "7%",
		position: "relative",
		"@media (max-width: 900px)": {
			fontSize: "22px",
		},
		"@media (min-width: 900px) and (max-width: 1200px)": { fontSize: "30px" },
	},
};

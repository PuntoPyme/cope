import Image, { StaticImageData } from "next/legacy/image";
import Imagebackground from "../../../assets/backgroundApp.png";
import { Box, Container } from "@mui/material";
import { styles } from "./style";

export interface IBackgroundProps {
	backgroundImage: string | StaticImageData;
}

const BackgroundPage: React.FC<IBackgroundProps> = ({ backgroundImage }) => (
	<Box sx={styles.bgWrap}>
		<Image
			priority={true}
			alt="cultivos"
			src={backgroundImage}
			layout="fill"
			objectFit="cover"
			quality={100}
		/>
	</Box>
);

export default BackgroundPage;

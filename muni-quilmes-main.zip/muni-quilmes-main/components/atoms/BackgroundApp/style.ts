export const styles = {
	bgWrap: {
		position: "fixed",
		height: "110vh",
		width: "110vw",
		overflow: "hidden",
		zIndex: "-1",
		top:'0'
	},
};

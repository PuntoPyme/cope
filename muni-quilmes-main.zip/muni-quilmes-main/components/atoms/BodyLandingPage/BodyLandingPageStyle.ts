import { CSSProperties } from "@mui/styles";

export const style: Record<string, CSSProperties> = {
	headerH3: {
		fontFamily: "Poppins, sans-serif",
		fontSize: "6vw",
		lineHeight: "8vw",
		"@media (max-width: 820px)": {
			fontSize: "10vw",
			lineHeight: "10vw",
		},
	},
	headerH5: {
		fontFamily: "Poppins, sans-serif",
		fontSize: "2vw",
		color: "black",
		position: "relative",
		textAlign: "center",
		fontStyle: "normal",
		fontWeight: "300",
		"@media (max-width: 920px)": {
			fontSize: "3vw",
		},
	},
	body: {
		width: "100%",
		padding: "0 !important",
		height: "auto",
		mt: "2vw",
		display: "flex",
		flexDirection: "column",
		alignItems: "center",
		justifyContent: "center",
	},
	bodyImage3: {
		width: "80%",
		height: "auto",
		display: "flex",
		alignItems: "center",
		justifyContent: "center",
	},
};

export const animations = {
	"@keyframes slideRight": {
		"0%": {
			transform: "translateX(0)",
		},
		"100%": {
			transform: "translateX(100px)",
		},
	},
	"@webkitKeyframes slideRight": {
		"0%": {
			webkitTransform: "translateX(0)",
			transform: "translateX(0)",
		},
		"100%": {
			webkitTransform: "translateX(100px)",
			transform: "translateX(100px)",
		},
	},
	slideRight: {
		webkitAnimation:
			"slideRight 0.5s cubic-bezier(0.250, 0.460, 0.450, 0.940) 0.5s both",
		animation:
			"slideRight 0.5s cubic-bezier(0.250, 0.460, 0.450, 0.940) 0.5s both",
	},
};

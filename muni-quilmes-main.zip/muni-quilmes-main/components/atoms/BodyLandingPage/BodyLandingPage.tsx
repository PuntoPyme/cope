import React from "react";
import { style } from "./BodyLandingPageStyle";
import { Box, Grid, Typography } from "@mui/material";
import image from "../../../assets/quilmes.png";
import image3 from "../../../assets/Creada.png";
import Image from "next/image";
import { TestimoniosGrid } from "../TestimoniosGrid/TestimoniosGrid";
import HeaderLandingPage from "../HeaderLandingPage/HeaderLandingPage";
import Contacto from "@/components/atoms/Contacto/Contacto";

const BodyLandingPage = () => {
	return (
		<Box sx={style.body} id="queEsSGC">
			<Grid
				container
				alignItems="stretch"
				sx={{
					padding: "0 2vw",
					background: "white",
					height: { xs: "100vh", sm: "fit-content" },
				}}
			>
				<Grid
					item
					xs={12}
					sx={{
						justifyContent: "center",
						alignItems: "center",
						display: "flex",
						flexDirection: "column",
					}}
				>
					<HeaderLandingPage />
				</Grid>
				<Grid
					item
					xs={12}
					sm={6}
					sx={{
						justifyContent: "center",
						alignItems: "center",
						display: "flex",
						flexDirection: "column",
					}}
				>
					<Typography
						sx={{
							textAlign: "center",
							...style.headerH3,
						}}
					>
						{"¿Qué es SGC?"}
					</Typography>
					<Typography
						sx={{ ...style.headerH5, display: { xs: "none", sm: "flex" } }}
					>
						{
							"El Sistema de Gestión Contable para Cooperativas permite a las cooperativas generar y cargar facturas de compras y ventas, así como gestionar ingresos y egresos de dinero. A partir de estos registros, es posible obtener diversos libros contables en formato PDF."
						}
					</Typography>
				</Grid>
				<Grid
					item
					xs={6}
					sm={6}
					sx={{
						display: "flex", // Añadido para asegurar que la imagen ocupe todo el espacio disponible
						justifyContent: "center",
						alignItems: "flex-start",
						order: { xs: "2" },
					}}
				>
					<Image
						className="slideRight"
						style={{
							width: "100%",
							height: "unset",
						}}
						src={image}
						alt="Imagen1"
					/>
				</Grid>
				<Grid sx={{ display: { xs: "flex", sm: "none" } }} item xs={6} sm={0}>
					<Typography
						sx={{
							...style.headerH5,
							display: { xs: "flex", sm: "none" },
						}}
					>
						{
							"El Sistema de Gestión Contable para Cooperativas permite a las cooperativas generar y cargar facturas de compras y ventas, así como gestionar ingresos y egresos de dinero. A partir de estos registros, es posible obtener diversos libros contables en formato PDF."
						}
					</Typography>
				</Grid>
			</Grid>
			<Grid
				item
				xs={12}
				sx={{
					width: "100%",
					height: "fit-content",
					display: "flex",
					alignItems: "center",
					justifyContent: "center",
				}}
			>
				<Image style={style.bodyImage3} src={image3} alt="Imagen" />
			</Grid>
			<Box
				id="testimonios"
				sx={{
					width: "100vw",
					display: "flex",
					alignItems: "center",
					justifyContent: "center",
					flexDirection: "column",
					gap: "5vw",
					minHeight: "fit-content !important",
					mb: "5%",
				}}
			>
				<TestimoniosGrid />
				<Contacto />
			</Box>
		</Box>
	);
};

export default BodyLandingPage;

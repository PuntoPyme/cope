import { Avatar as AvatarMUI, Stack, useTheme } from "@mui/material";
import { grey } from "@mui/material/colors";
import CSS from "csstype";
import React, { CSSProperties } from "react";
import { colors } from "../../../utils/styles/colors";

export interface IAvatarProps {
	avatarImg?: string | null | undefined;
	positionRelative?: boolean;
	children?: string;
	className?: string;
}

const Avatar: React.FC<IAvatarProps> = ({
	avatarImg,
	children,
	positionRelative,
}) => {
	const theme = useTheme();
	let styles: CSS.Properties = {
		backgroundColor: grey[900],
		width: "4vw",
		height: "4vw",
		cursor: "pointer",
		zIndex: 10,
		fontSize: "1.5vw",
		border: "none",
	};
	if (!avatarImg) {
		styles = {
			...styles,
			color: "black",
			background: colors.violet.light,
			border: `none`,
		};
	}
	if (positionRelative) {
		styles = {
			...styles,
			width: "2vw",
			height: "2vw",
		};
	}
	return (
		<>
			<Stack direction="row" spacing={2}>
				{avatarImg ? (
					<AvatarMUI src={avatarImg} sx={styles} />
				) : (
					<AvatarMUI sx={{ ...styles, bgcolor: theme.palette.primary.main }}>
						{children}
					</AvatarMUI>
				)}
			</Stack>
		</>
	);
};

export default Avatar;

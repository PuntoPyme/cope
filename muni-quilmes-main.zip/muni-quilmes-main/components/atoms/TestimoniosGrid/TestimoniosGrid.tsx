import { Box, Grid, Typography } from "@mui/material";
import React, { FC, ReactNode } from "react";
import { style } from "./style";
import Testimonios from "../Testimonios/Testimonios";

export const TestimoniosGrid = () => {
	const gridItems = [1, 2, 3]; // Para agregar más elementos, solo aumenta el array

	return (
		<Grid
			sx={{
				background: "white",
				height: "fit-content ",
				width: "80vw !important",
				minHeight: "fit-content !important",
				pb: "4vh",
				borderRadius: "40px",
			}}
		>
			<Grid
				item
				xs={12}
				sx={{
					display: "flex",
					justifyContent: "center",
					alignItems: "center",
					flexDirection: "column",
				}}
			>
				<Typography sx={style.headerH7}>{"Testimonios"}</Typography>
				<Box
					sx={{
						width: "20vw !important",
						background: "pink",
						height: ".5vw",
						borderRadius: "20px",
					}}
				/>
			</Grid>
			<Testimonios />
		</Grid>
	);
};

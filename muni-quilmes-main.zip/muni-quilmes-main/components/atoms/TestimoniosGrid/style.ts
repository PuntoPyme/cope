import { CSSProperties } from "@mui/styles";

export const style: Record<string, CSSProperties> = {
	headerH7: {
		fontFamily: "Poppins, sans-serif",
		fontSize: "4vw",
		color: "#7A61A2",
		position: "relative",
		textAlign: "center",
		justifyContent: "center",
		"@media (max-width: 900px)": {
			fontSize: "3vh",
		},
	},
};

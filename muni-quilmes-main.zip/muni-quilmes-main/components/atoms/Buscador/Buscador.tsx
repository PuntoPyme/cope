import { Box, TextField } from "@mui/material";
import * as React from "react";
import SearchIcon from "@mui/icons-material/Search";
import { StyleSearch } from "./Style";
import { useState, ChangeEvent } from "react";
interface buscadorProps {
	result: (value: string) => string;
	value: string;
}
const BuscadorAtom: React.FC<buscadorProps> = ({ result, value }) => {
	const [search, setSearch] = useState<string>("");
	const handleChange = (
		event: ChangeEvent<HTMLTextAreaElement | HTMLInputElement>
	) => {
		const value = event.target.value;

		setSearch(value);
		result(value);
	};

	React.useEffect(() => {
		setSearch(value);
	}, [value]);
	
	return (
		<Box sx={StyleSearch.input}>
			<TextField
				onChange={(e) => {
					handleChange(e);
				}}
				type={"text"}
				sx={{ width: "100%" }}
				value={search}
				disabled={false}
				InputLabelProps={{
					//propiedad para deshabilitar la animacion del input
					shrink: true,
				}}
			></TextField>
			<SearchIcon />
		</Box>
	);
};

export default BuscadorAtom;

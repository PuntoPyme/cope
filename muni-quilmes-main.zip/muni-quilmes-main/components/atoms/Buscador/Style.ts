import { CSSProperties } from "@mui/styles";
export const StyleSearch: Record<string, CSSProperties> = {
	input: {
		background: "white",
		border: "1px solid gray",
		display: "flex",
		alignItems: "center",
		borderRadius: "50px",
		width: "80%",
		height: "5vh",
		".MuiSvgIcon-root": {
			marginRight: "5%",
			color: "black",
		},
		"& .MuiInputBase-input": {
			height: "4vh",
			padding:'0',
			width: "100%",
			borderRadius: "50px",
			pl:'10%'
		},
		["& .MuiOutlinedInput-notchedOutline"]: {
			border: "none !important",
		},
	},
};

import * as React from "react";
import { style } from "./FooterStyle";
import { Twitter, Instagram, Facebook } from "@mui/icons-material";
import Box from "@mui/material/Box";
import { Grid, Typography } from "@mui/material";
import image from "../../../assets/Creadoteo.png";
import Image from "next/image";
import Link from "next/link";

const Footer = () => {
	return (
		<Box sx={style.footerSb}>
			<Box sx={style.footerLinks}>
				<Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 8, md: 1 }}>
					<Grid item xs={3} ml={5}>
						<Typography sx={style.footerH4}>{"Contacto"}</Typography>
						<Typography sx={style.footerP}>
							{"Búscanos en nuestras redes"}
						</Typography>
						<Box
							sx={{
								cursor: "pointer",
								justifyContent: "space-around",
								ml: "2vh",
							}}
						>
							<Instagram sx={style.socialIcon} />{" "}
							<Twitter sx={style.socialIcon} />{" "}
							<Facebook sx={style.socialIcon} />{" "}
						</Box>
					</Grid>
					<Grid item xs={3}>
						<Typography sx={style.footerH4}>{"Conocer mas"}</Typography>
						<Typography sx={style.footerP}>{"Sobre nosotros"}</Typography>
					</Grid>
					<Grid item xs={3}>
						<Link href={`/ecosol/landing`} className="flex flex-col">
							<Typography sx={style.footerH4}>{"Eco Sol"}</Typography>
							<Typography sx={style.footerP}>{"Plataforma"}</Typography>
						</Link>
					</Grid>
				</Grid>
			</Box>

			<hr></hr>

			<Box>
				<Grid container columnSpacing={{ xs: 1, sm: 8, md: 1 }}>
					<Grid item xs={9}>
						<Typography sx={style.footerC}>
							@{new Date().getFullYear()} Quilmes Coop. All right reserved.
						</Typography>
					</Grid>
					<Grid item xs={3}>
						<Image
							style={{
								width: "80%",
								height: "unset",
								position: "relative",
								cursor: "pointer",
							}}
							src={image}
							alt="Imagen1"
						/>
					</Grid>
				</Grid>
			</Box>
		</Box>
	);
};

export default Footer;

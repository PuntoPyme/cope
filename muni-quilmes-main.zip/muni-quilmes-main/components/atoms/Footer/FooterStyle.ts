export const style = {
	footerSb: {
		width: "100vw",
		background: "black",
		pt: "2%",
		
	},

	footerLinks: {
		display: "flex",
		justifyContent: "spaceBetween",
		alignItems: "flexStart",
		flexDirection: "row",
		flexWrap: "wrap",
		width: "100%",
		textAling: "left",
		marginButtom: "2rem",
	},
	footerH4: {
		ml: "2vh",
		fontFamily: "Poppins, sans-serif",
		fontSize: "1.5vw",

		color: "#FFFFFF",
		justifyContent: "flexStart",
	},

	footerP: {
		ml: "2vh",
		fontFamily: "Poppins, sans-serif",
		fontSize: "1vw",

		width: "50%",
		cursor: "pointer",
		color: "#FFFFFF",
		display: "flexStart",
	},

	footerC: {
		fontFamily: "Poppins, sans-serif",
		fontSize: "2vh",

		width: "100%",
		cursor: "pointer",
		color: "#FFFFFF",
		justifyContent: "flexStart",
	},

	socialIcon: {
		color: "white",
	},
};

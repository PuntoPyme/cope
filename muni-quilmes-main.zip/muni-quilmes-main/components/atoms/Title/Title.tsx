import { Box, Grid, Typography } from "@mui/material";
import Script from "next/script";
import { style } from "./TitleStyle";

const Header = () => {
	return (
		<Box sx={{}}>
			<Box
				sx={{
					mt: "4.1%",
					width: "1539px",
					height: "54px",
					background: "white",
					boxShadow: "0px 4px 4px 0px rgba(0, 0, 0, 0.25)",

					"@media (max-width: 900px)": {},
				}}
			>
				<Typography
					sx={{
						fontFamily: "Poppins, sans-serif",
						fontSize: "25px",
						lineHeight: "25px",
						ml: "5%",
						pt: "1%",
						color: "black",
						display: "flex",
						position: "relative",
						"@media (maxWidth: 900px)": {
							fontSize: "50px",
						},
						"@media (minWidth: 900px) and (max-width: 1400px)": {
							fontSize: "60px",
						},
					}}
				>
					{"Inicio"}
				</Typography>
			</Box>
			<Box
				sx={{
					width: "1539px",
					height: "77px",
					background: "#D4D2D2",
					boxShadow: "0px 4px 4px 0px rgba(0, 0, 0, 0.25)",

					"@media (max-width: 900px)": {},
				}}
			>
				<Typography
					sx={{
						fontFamily: "Poppins, sans-serif",
						fontSize: "25px",
						lineHeight: "25px",
						color: "black",
						ml: "5%",
						pt: "1.5%",
						justifyContent: "center",
						position: "relative",
						"@media (maxWidth: 900px)": {
							fontSize: "50px",
						},
						"@media (minWidth: 900px) and (max-width: 1400px)": {
							fontSize: "60px",
						},
					}}
				>
					{"Bienvenido a Quilmes Coop"}
				</Typography>
			</Box>
		</Box>
	);
};
export default Header;

import { CSSProperties } from "@mui/styles";
export const style: Record<string, CSSProperties> = {
	headerH1: {
		fontFamily: "Poppins, sans-serif",
		fontSize: "8vw",
		lineHeight: "8vw",
		color: "#FFFFFF",
		"@media (max-width: 820px)": {
			paddingBottom: "2vh",
			fontSize: "15vw",
			lineHeight: "15vw",
		},
		// "@media (min-width: 780px) and (max-width: 1020px)": {
		// 	fontSize: "75px",
		// },
		// "@media (min-width: 1020px) and (max-width: 1100px)": {
		// 	fontSize: "80px",
		// },
		"@media (min-width: 1100px) and (max-width: 1300px)": {
			fontSize: "10vw",
		},
	},

	headerH1c: {
		fontFamily: "Poppins, sans-serif",
		fontSize: "4vw",
		lineHeight: "px",
		color: "#FFFFFF",
		"@media (min-width: 1250px) and (max-width: 1430px)": {
			fontSize: "4vw",
		},
		"@media (max-width: 820px)": {
			fontSize: "8vw",
			lineHeight: "12vw",
		},
		// "@media (min-width: 1100px) and (max-width: 1250px)": {
		// 	fontSize: "40px",
		// },
		// "@media (min-width: 1020px) and (max-width: 1100px)": {
		// 	fontSize: "45px",
		// },
		// "@media (min-width: 800px) and (max-width: 1020px)": {
		// 	fontSize: "35px",
		// },
		// "@media (max-width: 780px)": {
		// 	fontSize: "4vw",
		// },
	},
};

import * as React from "react";
import { style } from "./HeaderLandingPageStyle";
import { Box, Container, Typography } from "@mui/material";
import { ButtonHome } from "../Button/Button-home/ButtonHome";
import Imagebackground from "../../../assets/Contabilidad.jpg";

const HeaderLandingPage = () => {
	return (
		<>
			<Box
				sx={{
					width: "97%",
					height: "70vh",
					minHeight: "fit-content !important",
					mt: "5%",
					backgroundImage: `url(${Imagebackground.src})`,
					backgroundPosition: "center",
					backgroundRepeat: "no-repeat",
					backgroundSize: "cover",
					borderRadius: "40px",
					"@media (max-width: 920px)": {
						mt: "15%",
						height: "60vh",
					},
				}}
			>
				<Box
					sx={{
						display: "flex",
						justifyContent: "space-evenly",
						flexDirection: "column",
						height: "100%",
						ml: "4vh",
						width: "fit-content",
					}}
				>
					<Typography sx={style.headerH1}>{"SGC"}</Typography>
					<Typography sx={style.headerH1c}>
						{"Sistema de gestion contable para cooperativas"}
					</Typography>
					<Box width={"20%"} height={"4vw"} >
						<ButtonHome link="/configuracion" primary>
							{"Crear Cuenta"}
						</ButtonHome>
					</Box>
				</Box>
			</Box>
		</>
	);
};

export default HeaderLandingPage;

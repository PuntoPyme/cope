import { Box, Typography } from "@mui/material";
import teo from "../../../assets/teotestimonios.png";
import gaia from "../../../assets/gaias.png";
import agosto from "../../../assets/agosto.png";
import Image from "next/image";


const testimoniosData = [
	{
		text: "Gran aplicación super funcional y necesaria",
		image: teo,
		nombre: "Teo Coop",
		rol: "Cooperativa",
	},
	{
		text: "La plataforma me facilita toda mi gestión contable",
		image: gaia,
		nombre: "Gaia",
		rol: "Cooperativa",
	},
	{
		text: "Gran plataforma contable",
		image: agosto,
		nombre: "1° de Agosto",
		rol: "Cooperativa",
	},
];

const Testimonios = () => {
	return (
		<Box
			sx={{
				padding: "4%",
				display: "flex",
				flexDirection: "row",
				gap: 8,
				justifyContent: "space-evenly",
			}}
		>
			{testimoniosData.map((testimonio, index) => (
				<Box
					key={index}
					sx={{
						background: "#FFECAB",
						padding: "0.3vw",
						width: "80%",
						height: { xs: "20vw", md: "25vw" },
						minHeight: "fit-content",
						borderRadius: "20px",
						display: "flex",
						alignItems: "center",
						flexDirection: "column",
						justifyContent: "space-around",
						overflow: "hidden",
						boxShadow: "0px 5px 3px #00000080",
					}}
				>
					<Box
						sx={{
							display: "flex",
							alignItems: "center",
							justifyContent: "space-between",
							width: "80%",
							flexDirection: "column",
						}}
					>
						<Box>
							<span style={{ color: "#ffcf2e", fontSize: 24 }}>&#9733;</span>
							<span style={{ color: "#ffcf2e", fontSize: 24 }}>&#9733;</span>
							<span style={{ color: "#ffcf2e", fontSize: 24 }}>&#9733;</span>
							<span style={{ color: "#ffcf2e", fontSize: 24 }}>&#9733;</span>
							<span style={{ color: "#ffcf2e", fontSize: 24 }}>&#9733;</span>
						</Box>
						<Typography
							sx={{
								fontSize: "1vw",
								fontFamily: "Poppins",
								textAlign: "center",
								"@media (max-width: 768px)": {
									fontSize: "0.8vw",
								},
							}}
						>
							{testimonio.text}
						</Typography>
					</Box>
					<Box
						sx={{
							display: "flex",
							alignItems: "center",
							width: "70%",
							mr: "20%",
							mt: "-30%",
						}}
					>
						<Image
							style={{
								width: "60%",
								height: "auto",
							}}
							src={testimonio.image}
							alt="Imagen"
						/>
						<Box
							display="flex"
							justifyContent={"flex-end"}
							flexDirection={"column"}
						>
							<Typography
								style={{
									fontFamily: "Poppins",
									fontSize: "1vw",
									fontWeight: 700,
									color: "#23A6F0",
								}}
							>
								{testimonio.nombre}
							</Typography>
							<Typography
								style={{
									fontFamily: "Poppins",
									fontSize: "0.8vw",
									fontWeight: 500,
								}}
							>
								{testimonio.rol}
							</Typography>
						</Box>
					</Box>
				</Box>
			))}
		</Box>
	);
};

export default Testimonios;
import React, { useState, useEffect } from "react";
import {
	Box,
	FormControl,
	InputLabel,
	MenuItem,
	Modal,
	Select,
	SelectChangeEvent,
} from "@mui/material";
import { container, large, small } from "../Style";

export interface SelectInputProps {
	arrayOptions?: any[];
	componenteModal?: React.ReactNode;
	onValueChange: (value: string) => void;
	value: string | number;
	labelMasOpciones?: string;
	disabled?: boolean;
	size?: string;
}

const SelectInput: React.FC<SelectInputProps> = ({
	arrayOptions,
	componenteModal,
	onValueChange,
	value,
	labelMasOpciones,
	disabled,
	size,
}) => {
	const [open, setOpen] = useState(false);

	const handleSelectChange = (event: SelectChangeEvent<string>) => {
		const { value } = event.target;
		onValueChange(value);
	};

	const handleOpenModal = () => {
		setOpen(true);
	};

	const handleCloseModal = () => {
		setOpen(false);
	};
	return (
		<>
			{arrayOptions && arrayOptions.length > 0 ? (
				<Box
					sx={{
						...container,
						...(size === "small" ? small : large),
					}}
				>
					<FormControl size="small">
						<Select
							disabled={disabled}
							labelId="demo-select-small-label"
							id="demo-select-small"
							value={value?.toString() || ""}
							onChange={handleSelectChange}
							sx={{ width: "100%" }}
						>
							{arrayOptions.map((name, index) => (
								<MenuItem value={name} key={name.toString() + index}>
									{name}
								</MenuItem>
							))}
							{componenteModal && (
								<MenuItem onClick={handleOpenModal} sx={{ color: "blue" }}>
									{labelMasOpciones || "Otro"}
								</MenuItem>
							)}
						</Select>
					</FormControl>
					{componenteModal && (
						<Modal
							sx={{
								background: "#00000080",
								display: "flex",
								alignItems: "center",
								justifyContent: "center",
							}}
							open={open}
							onClose={handleCloseModal}
							aria-labelledby="modal-modal-title"
							aria-describedby="modal-modal-description"
						>
							<Box
								display={"flex"}
								alignItems={"flex-end"}
								flexDirection={"column"}
							>
								{React.cloneElement(
									componenteModal as React.ReactElement<any>,
									{
										onClickCancelar: handleCloseModal, // Pasar la función de cierre aquí
									}
								)}
							</Box>
						</Modal>
					)}
				</Box>
			) : null}
		</>
	);
};
export default SelectInput;

import { Box, Input } from "@mui/material";
import React, { useEffect, useState } from "react";
import { container, large, rounded } from "../Style";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import "dayjs/locale/es";
import dayjs, { Dayjs } from "dayjs";
import { format, isBefore } from "date-fns";

interface DateInputProps {
	name: string;
	value: Date | null;
	onChange: (value: Date | null) => void;
	isRounded: boolean;
	minDate?: Date;
	disabled?: boolean;
}

const DateInput: React.FC<DateInputProps> = ({
	name,
	value,
	onChange,
	isRounded,
	minDate,
	disabled = false,
}) => {
	const [date, setDate] = useState<Dayjs | null>(value ? dayjs(value) : null);

	useEffect(() => {
		setDate(value ? dayjs(value) : null);
	}, [value]);

	const handleDateChange = (newDate: Dayjs | null) => {
		setDate(newDate);
		if (newDate && newDate.isValid()) {
			const finalDate =
				minDate && newDate.isBefore(minDate) ? dayjs(minDate) : newDate;
			onChange(finalDate.toDate());
		} else {
			onChange(null);
		}
	};

	return (
		<Box sx={{ ...large, ...(isRounded ? rounded : container) }}>
			<LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale="es">
				<DatePicker
					minDate={minDate ? dayjs(minDate) : undefined}
					name={name}
					label=""
					disabled={disabled}
					value={date}
					onChange={handleDateChange}
					slotProps={{
						textField: {
							fullWidth: true,
							variant: "outlined",
						},
					}}
				/>
			</LocalizationProvider>
		</Box>
	);
};

export default DateInput;

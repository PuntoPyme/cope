import { TextField } from "@mui/material";
import { Box } from "@mui/system";
import React from "react";
import { container, large, rounded } from "../Style";

export interface ITextInputProps {
	enabled: boolean;
	value: string | undefined;
	name?: string;
	InputProps?: Record<string, any>;
	roundedProp?: boolean;
	error?: boolean;
	onChange: (
		event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
	) => void;
	helperText?: string;
}

const TextInput: React.FC<ITextInputProps> = ({
	enabled,
	value,
	InputProps,
	name = "",
	onChange,
	roundedProp,
	error,
	helperText,
}) => {
	const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		const value = e.target.value;
		const syntheticEvent: React.ChangeEvent<
			HTMLInputElement | HTMLTextAreaElement
		> = {
			...e,
			target: {
				...e.target,
				name,
				value: value.toString(),
			},
		};
		onChange(syntheticEvent);
	};
	return (
		<Box sx={{ ...large, ...(roundedProp ? rounded : container) }}>
			<TextField
				type={"text"}
				sx={{ width: "100%" }}
				name={name}
				helperText={helperText}
				value={value}
				error={error}
				disabled={!enabled}
				InputProps={InputProps}
				InputLabelProps={{
					//propiedad para deshabilitar la animacion del input
					shrink: true,
				}}
				onChange={handleChange}
			></TextField>
		</Box>
	);
};

export default TextInput;

export const container = {
	"& .MuiFormControl-root": {
		".MuiButtonBase-root": { mr: "5%" },
		["& .MuiOutlinedInput-root"]: {
			// el input en si
			padding: "0 !Important",
			borderRadius: "5px !important",
			border: "1px solid gray",
			["& .MuiOutlinedInput-notchedOutline"]: {
				borderRadius: "5px !important",
				border: "none !important",
			},
		},
	},
	".MuiInputBase-input": {
		padding: "0 .5rem !important",
	},
};
export const large = {
	".MuiSelect-select": { height: "4vh" },
	["& .MuiOutlinedInput-root"]: {
		width: "15vw",
		height: "4vh",
	},
};
export const small = {
	["& .MuiOutlinedInput-root"]: {
		width: "10vw",
		height: "5vh",
	},
};
export const rounded = {
	"& .MuiFormControl-root": {
		["& .MuiOutlinedInput-root"]: {
			height: "5vh",
			width: "100%",
		},
	},
	".MuiInputBase-input": {
		padding: "0 .5rem !important",
	},
};
export const tableMode = {};

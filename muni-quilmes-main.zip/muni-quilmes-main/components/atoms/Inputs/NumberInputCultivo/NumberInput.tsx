import { TextField } from "@mui/material";
import { Box } from "@mui/system";
import React from "react";
import { container, large, rounded, small } from "../Style";

export interface INumberInputProps {
	enabled: boolean;
	value: number | undefined;
	name?: string;
	InputProps?: Record<string, any>;
	onChange: (
		event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
	) => void;
	roundedProp?: boolean;
}

const NumberInput: React.FC<INumberInputProps> = ({
	enabled,
	value = 1,
	name = "",
	InputProps,
	onChange,
	roundedProp,
}) => {
	const [error, setError] = React.useState(false);
	const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		const value = e.target.valueAsNumber;
		const syntheticEvent: React.ChangeEvent<
			HTMLInputElement | HTMLTextAreaElement
		> = {
			...e,
			target: {
				...e.target,
				name,
				value: value.toString(),
			},
		};
		onChange(syntheticEvent);
	};
	return (
		<Box sx={{ ...large, ...(roundedProp ? rounded : container) }}>
			<TextField
				sx={{ width: "100%" }}
				name={name}
				type="number"
				value={value}
				error={error}
				disabled={!enabled}
				onChange={handleChange}
				InputProps={InputProps}
			></TextField>
		</Box>
	);
};

export default NumberInput;

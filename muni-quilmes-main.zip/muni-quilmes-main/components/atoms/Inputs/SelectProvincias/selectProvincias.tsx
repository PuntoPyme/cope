import React, { useState, useEffect } from "react";
import {
	Box,
	FormControl,
	MenuItem,
	Select,
	SelectChangeEvent,
} from "@mui/material";
import { container, large, small } from "../Style";
import { useSelector } from "react-redux";
import { RootState } from "@/Redux/store";
import { MunicipioState, ubicacionAPIgobierno } from "@/types";
import { fetchMunicipios } from "@/utils/ApiRequest";

export interface SelectInputProps {
	onValueChange: (value: { province: string; municipio: string }) => void;
	disabled?: boolean;
}

const SelectInputProvincia: React.FC<SelectInputProps> = ({
	onValueChange,
	disabled,
}) => {
	const [locationState, setLocationState] = useState<{
		province: string;
		municipio: string;
	}>({
		province: "",
		municipio: "",
	});

	const { provincias } = useSelector((state: RootState) => state.provincias);
	const [provinciasState, setProvinciasState] = useState<
		ubicacionAPIgobierno[]
	>([]);
	const [municipios, setMunicipios] = useState<MunicipioState | null>(null);
	const [provinciaSelect, setProvinciaSelect] =
		useState<ubicacionAPIgobierno>();

	useEffect(() => {
		if (provincias.length > 0) {
			setProvinciasState(provincias);
			const firstProvince = provincias[0];
			setProvinciaSelect(firstProvince);
			fetchMunicipios(firstProvince.id).then((data) => {
				setMunicipios(data !== undefined ? data : null);
				setLocationState((prevState) => ({
					...prevState,
					province: firstProvince.nombre,
					municipio: data?.municipios[0]?.nombre || "",
				}));
				onValueChange({
					province: firstProvince.nombre,
					municipio: data?.municipios[0]?.nombre || "",
				});
			});
		}
	}, [provincias]);

	const handleSelectProvince = (event: SelectChangeEvent<string>) => {
		const selectedProvince = provinciasState.find(
			(provincia) => provincia.nombre === event.target.value
		);
		if (selectedProvince) {
			setProvinciaSelect(selectedProvince);
			fetchMunicipios(selectedProvince.id).then((data) => {
				setMunicipios(data !== undefined ? data : null);
				setLocationState({
					province: selectedProvince.nombre,
					municipio: data?.municipios[0]?.nombre || "",
				});
				onValueChange({
					province: selectedProvince.nombre,
					municipio: data?.municipios[0]?.nombre || "",
				});
			});
		}
	};

	return (
		<>
			<Box
				sx={{
					...container,
					...large,
				}}
			>
				<FormControl size="small" sx={{ marginBottom: "1vw" }}>
					<Select
						disabled={disabled}
						labelId="demo-select-small-label"
						id="demo-select-small"
						value={provinciaSelect?.nombre || ""}
						onChange={handleSelectProvince}
					>
						{provinciasState.map((provincia, index) => (
							<MenuItem value={provincia.nombre} key={provincia.id + index}>
								{provincia.nombre}
							</MenuItem>
						))}
					</Select>
				</FormControl>
				{municipios !== null && (
					<FormControl size="small">
						<Select
							disabled={disabled}
							labelId="demo-select-small-label"
							id="demo-select-small"
							value={locationState.municipio}
							onChange={(event) =>
								setLocationState((prevState) => ({
									...prevState,
									municipio: event.target.value as string,
								}))
							}
						>
							{municipios.municipios.map(
								(municipio: ubicacionAPIgobierno, index: number) => (
									<MenuItem value={municipio.nombre} key={municipio.id + index}>
										{municipio.nombre}
									</MenuItem>
								)
							)}
						</Select>
					</FormControl>
				)}
			</Box>
		</>
	);
};
export default SelectInputProvincia;

import React, { MouseEvent } from "react";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import CheckBoxIcon from "@mui/icons-material/CheckBox";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";

interface ICheckBoxComponentProps {
	name: string;
	checked: boolean;
	size: "small" | "inherit" | "medium" | "large" | undefined;
	onChange: (event: MouseEvent<HTMLButtonElement> , name: string) => void;
	disabled?: boolean;
}

const Checkbox: React.FC<ICheckBoxComponentProps> = ({
	name,
	checked,
	size,
	onChange,
	disabled,
}) => {
	const handleCheckboxChange = (event: React.MouseEvent<HTMLButtonElement>) => {
		onChange(event, name);
	};
	
	return (
		<Box>
			<IconButton
				sx={{
					...(disabled && {
						opacity: 0.5,
						pointerEvents: "none",
					}),
				}}
				onClick={handleCheckboxChange}
				disabled={disabled}
			>
				{checked ? (
					<CheckBoxIcon strokeWidth={1.5} color="secondary" fontSize={size} />
				) : (
					<CheckBoxOutlineBlankIcon
						strokeWidth={1.5}
						color="secondary"
						fontSize={size}
					/>
				)}
			</IconButton>
		</Box>
	);
};

export default Checkbox;

Checkbox.defaultProps = {
	checked: true,
	size: "small",
	disabled: false,
};

import React, { useState } from "react";
import { Button, Menu, MenuItem } from "@mui/material";
import Styles from "./Style";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import ArrowDropUpIcon from "@mui/icons-material/ArrowDropUp";

export interface ButtonActionsProps {
	children: string;
	acciones: string[];
	onActionSelect: (accion: string) => void;
}

export const ButtonActions = ({
	children,
	acciones,
	onActionSelect,
}: ButtonActionsProps) => {
	const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
	const open = Boolean(anchorEl);

	const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
		setAnchorEl(event.currentTarget);
	};

	const handleClose = () => {
		setAnchorEl(null);
	};
	const handleMenuItemClick = (accion: string) => {
		onActionSelect(accion);
		handleClose();
	};
	return (
		<>
			<Button
				id="basic-button"
				aria-controls={open ? "basic-menu" : undefined}
				aria-haspopup="true"
				aria-expanded={open ? "true" : undefined}
				onClick={handleClick}
				sx={Styles.button}
			>
				{children}
				{open ? <ArrowDropUpIcon /> : <ArrowDropDownIcon />}
			</Button>
			<Menu
				id="basic-menu"
				open={open}
				anchorEl={anchorEl}
				onClose={handleClose}
				MenuListProps={{
					"aria-labelledby": "basic-button",
				}}
				sx={{
					".MuiPaper-root": {
						width: "10vw",
					},
				}}
			>
				{acciones.map((accion) => (
					<MenuItem key={accion} onClick={() => handleMenuItemClick(accion)}>
						{accion}
					</MenuItem>
				))}
			</Menu>
		</>
	);
};

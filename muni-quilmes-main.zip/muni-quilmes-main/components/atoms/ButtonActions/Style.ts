import { CSSProperties } from "@mui/styles";
const Styles: Record<string, CSSProperties> = {
	button: {
		minWidth: "fit-content",
		whiteSpace: "pre",
		fontFamily: "poppins",
		fontWeight: 300,
		width: "80% !important",
		height: "5vh",
		borderRadius: "40px",
		textTransform: "capitalize",
		border: "1px solid #7A61A1",
		background: "white",
		color: "#7A61A1",
		fontSize: "1rem",
		"&:hover": {
			background: "white",
		},
	},
};

export default Styles;

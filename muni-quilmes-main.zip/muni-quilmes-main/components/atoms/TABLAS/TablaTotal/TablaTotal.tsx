import * as React from "react";
import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";

interface TableTotalProps {
	totals: { totalBruto: number; totalImpuesto: number; total: number };
}
export default function TablaTotal({ totals }: TableTotalProps) {
	return (
		<TableContainer
			component={Paper}
			sx={{ width: "70%", border: "1px solid #00000050" }}
		>
			<Table sx={{ minWidth: "100%" }} aria-label="simple table">
				<TableHead>
					<TableRow>
						<TableCell>Total neto</TableCell>
						<TableCell>$ {totals.totalBruto}</TableCell>
						<TableCell align="right">Total impuesto</TableCell>
						<TableCell>$ {totals.totalImpuesto}</TableCell>
						<TableCell align="right">Total bruto</TableCell>
						<TableCell>$ {totals.total}</TableCell>
					</TableRow>
				</TableHead>
			</Table>
		</TableContainer>
	);
}

import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import Checkbox from "../../Checkbox/Checkbox";
import { style } from "../style";
import { compraVer } from "@/types";
import React, { useEffect, useState } from "react";
import { PDFViewer } from "@react-pdf/renderer";
import PDFComponent from "@/components/templates/PDFTemplateVenta";
import { Alert, Box, IconButton, Modal, Typography } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import {
	filterRowsByDateRange,
	useActionHandler,
} from "@/utils/Functions/Filters";
import { fetchGetRequest, fetchPostRequest } from "@/utils/ApiRequest";
import { useSelector } from "react-redux";
import { RootState } from "@/Redux/store";
import { convertValueString } from "@/utils/Functions/ValidationInputs";
import { filtrarBusqueda } from "@/utils/Functions/Filters";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
	[`&.${tableCellClasses.head}`]: {
		backgroundColor: theme.palette.common.black,
		color: theme.palette.common.white,
	},
	[`&.${tableCellClasses.body}`]: {
		fontSize: 14,
	},
}));
interface tablaProps {
	resultadoAccion: string;
	periodo?: { desde: Date | null; hasta: Date | null };
	resultadoBusqueda?: string;
	itemsForRows: compraVer[];
	checkoutPage: boolean;
}

const InvoicePurchase: React.FC<tablaProps> = ({
	resultadoAccion,
	periodo,
	resultadoBusqueda,
	itemsForRows,
	checkoutPage,
}) => {
	const { codejwt } = useSelector((state: RootState) => state.storeJwt);

	const [isPdfVisible, setIsPdfVisible] = useState<boolean>(false);
	const [originalRows, setOriginalRows] = useState<compraVer[]>(itemsForRows);
	const [rowsState, setRowsState] = useState<compraVer[]>(itemsForRows);
	const [checkedState, setCheckedState] = useState<{ [key: number]: boolean }>(
		{}
	);
	const [rowsChecked, setRowsChecked] = useState<{ [key: number]: compraVer }>(
		{}
	);
	const [headerChecked, setHeaderChecked] = useState<boolean>(false);

	const closePdfModal = () => {
		setIsPdfVisible(false);
	};
	useEffect(() => {
		setOriginalRows(itemsForRows);
	}, [itemsForRows]);

	useEffect(() => {
		setCheckedState(
			originalRows.reduce((acc, invoice) => {
				acc[invoice.id] = false;
				return acc;
			}, {} as { [key: number]: boolean })
		);
	}, [originalRows]);

	useEffect(() => {
		if (resultadoBusqueda && resultadoBusqueda.length > 0) {
			setRowsState(filtrarBusqueda(originalRows, resultadoBusqueda));
		} else {
			setRowsState(originalRows);
		}
	}, [resultadoBusqueda, originalRows]);

	useEffect(() => {
		if (
			periodo &&
			periodo.desde &&
			periodo.hasta &&
			periodo.desde !== null &&
			periodo.hasta !== null &&
			originalRows.length > 0
		) {
			setRowsState(
				filterRowsByDateRange(periodo.desde, periodo.hasta, originalRows)
			);
		} else {
			setRowsState(originalRows);
		}
	}, [periodo, originalRows]);
	const { alert, alertText, alertType } = useActionHandler(
		resultadoAccion,
		rowsChecked,
		{
			onPrint: () => setIsPdfVisible(true),
			onDelete: async (idsToDelete) => {
				await Promise.all(
					idsToDelete.map((id) =>
						fetchPostRequest(
							`/accountant/sales-invoice/update-status`,
							{ salesInvoiceId: id, status: false },
							codejwt
						)
					)
				);
				setOriginalRows((rows) =>
					rows.filter((row) => !idsToDelete.includes(row.id))
				);
			},
		}
	);

	const handleChange = (
		event: React.MouseEvent<HTMLButtonElement>,
		id: string
	) => {
		const rowId = parseInt(id, 10);
		setCheckedState((prev) => {
			const newState = { ...prev, [rowId]: !prev[rowId] };
			setRowsChecked((prevRows) => {
				const selectedRow = rowsState.find((row) => row.id === rowId);
				if (newState[rowId] && selectedRow) {
					return {
						...prevRows,
						[rowId]: selectedRow,
					};
				} else {
					const { [rowId]: _, ...rest } = prevRows;
					return rest;
				}
			});
			return newState;
		});
	};

	const handleHeaderCheckboxChange = () => {
		const isChecked = !headerChecked;
		setHeaderChecked(isChecked);
		setCheckedState((prev) => {
			const newCheckedState = { ...prev };
			rowsState.forEach((row) => {
				newCheckedState[row.id] = isChecked;
			});
			return newCheckedState;
		});
		setRowsChecked(() => {
			if (isChecked) {
				const allRowsChecked = rowsState.reduce<{ [key: number]: compraVer }>(
					(acc, row) => {
						acc[row.id] = row;
						return acc;
					},
					{}
				);
				return allRowsChecked;
			} else {
				return {};
			}
		});
	};

	const ventasArray: compraVer[] = Object.values(rowsChecked);

	return (
		<>
			<Box width={"95vw"}>
				<TableContainer component={Paper} sx={style.table}>
					<Table sx={{ minWidth: "100%" }} aria-label="sales table">
						<TableHead>
							<TableRow>
								<TableCell align="right">
									<Checkbox
										checked={headerChecked}
										size="small"
										onChange={handleHeaderCheckboxChange}
										name="header-checkbox"
									/>
								</TableCell>
								<TableCell>Fecha</TableCell>
								<TableCell>Tipo</TableCell>
								<TableCell>Comprobante</TableCell>
								<TableCell>Proveedor</TableCell>
								<TableCell>Vencimiento</TableCell>
								<TableCell>Monto Bruto</TableCell>
								<TableCell>Método de Pago</TableCell>
								<TableCell>Provincia</TableCell>

								<TableCell>Total</TableCell>
							</TableRow>
						</TableHead>
						<TableBody>
							{rowsState.map((row) => (
								<TableRow key={row.id}>
									{checkoutPage && (
										<StyledTableCell component="th" scope="row">
											<Checkbox
												checked={checkedState[row.id] || false}
												size="small"
												onChange={handleChange}
												name={`${row.id}`}
											/>
										</StyledTableCell>
									)}
									<StyledTableCell>
										{new Date(row.date).toLocaleDateString()}
									</StyledTableCell>
									<StyledTableCell>
										{convertValueString(row.invoiceType)}
									</StyledTableCell>
									<StyledTableCell>{row.number}</StyledTableCell>
									<StyledTableCell>{row.supplierName}</StyledTableCell>
									<StyledTableCell>
										{new Date(row.expiration_date).toLocaleDateString()}
									</StyledTableCell>
									<StyledTableCell>
										{row.grossAmount.toFixed(2)}
									</StyledTableCell>
									<StyledTableCell>
										{convertValueString(row.paymentMethod)}
									</StyledTableCell>
									<StyledTableCell>
										{convertValueString(row.province)}
									</StyledTableCell>

									<StyledTableCell>{row.amount.toFixed(2)}</StyledTableCell>
								</TableRow>
							))}
						</TableBody>
					</Table>
				</TableContainer>
				<Modal
					open={isPdfVisible}
					onClose={closePdfModal}
					aria-labelledby="pdf-modal-title"
					aria-describedby="pdf-modal-description"
				>
					<Box
						style={{
							display: "flex",
							justifyContent: "center",
							height: "100%",
							alignItems: "center",
						}}
					>
						<Box
							sx={{
								borderRadius: "50% !important",
								position: "absolute",
								top: "5vh",
								right: "15%",
								".MuiButtonBase-root": {
									border: "2px solid white",
									"&:hover": {
										boxShadow: " 5px 5px #ffffff90",
									},
								},
							}}
						>
							<IconButton onClick={closePdfModal} sx={{ color: "white" }}>
								<CloseIcon />
							</IconButton>
						</Box>
						<PDFViewer width="50%" height="90%">
							<PDFComponent row={ventasArray} title="Compra" />
						</PDFViewer>
					</Box>
				</Modal>
				{alert ? (
					<Box
						sx={{
							width: "40%",
							right: "30%",
							position: "absolute",
							top: "40%",
						}}
					>
						<Alert variant="filled" severity={alertType}>
							{alertText}
						</Alert>
					</Box>
				) : null}
			</Box>
		</>
	);
};

export default InvoicePurchase;

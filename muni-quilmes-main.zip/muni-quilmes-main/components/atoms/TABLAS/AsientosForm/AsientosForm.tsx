import React, { useEffect, useMemo, useState } from "react";
import {
	Button,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	Paper,
	IconButton,
	Select,
	MenuItem,
	SelectChangeEvent,
	Box,
	Typography,
	Alert,
} from "@mui/material";
import { Delete as DeleteIcon, Add as AddIcon } from "@mui/icons-material";
import TextInput from "@/components/atoms/Inputs/TextInput/TextInput";
import DateInput from "@/components/atoms/Inputs/InputDate/DateInput";
import { RootState } from "@/Redux/store";
import { useSelector } from "react-redux";
import { container } from "../../Inputs/Style";
import { ButtonClasic } from "../../Button/Button-clasic/ButtonClasic";
import { fetchGetRequest, fetchPostRequest } from "@/utils/ApiRequest";
import { useDispatch } from "react-redux";
import { setAccountJournal } from "@/Redux/features/AccountForBook";
import { responseAccountJournal } from "@/utils/Functions/ValidationInputs";
import { error } from "console";

interface JournalEntryLine {
	id: number;
	accountId: number | null;
	debit: number;
	credit: number;
	debitAccountId?: number;
	creditAccountId?: number;
}
interface JournalEntry {
	description: string;
	date: string;
	journalEntryLines: JournalEntryLine[];
}
const journalEntriesInitialState: JournalEntry = {
	description: "",
	date: "",
	journalEntryLines: [
		{
			id: 1,
			accountId: 0,
			debitAccountId: 0,
			creditAccountId: 0,
			credit: 0,
			debit: 0,
		},
		{
			id: 2,
			accountId: 0,
			debitAccountId: 0,
			creditAccountId: 0,
			credit: 0,
			debit: 0,
		},
	],
};
export default function JournalEntryForm() {
	const { codejwt } = useSelector((state: RootState) => state.storeJwt);
	const accounts = useSelector(
		(state: RootState) => state.accountJournal.account
	);
	console.log(accounts);
	const dispatch = useDispatch();
	const [isMounted, setIsMounted] = useState(false);
	const [journalEntry, setJournalEntry] = useState<JournalEntry>(
		journalEntriesInitialState
	);
	const [alert, setAlert] = useState<boolean>(false);
	const [alertType, setAlertType] = useState<"success" | "info" | "error">(
		"success"
	);
	const [alertText, setAlertText] = useState<string>("");
	const [totalDebit, setTotalDebit] = useState(0);
	const [totalCredit, setTotalCredit] = useState(0);
	const [balance, setBalance] = useState(0);
	useEffect(() => {
		console.log("EJECUTA ACÁ ");
		fetchGetRequest("/accountant/accounts/company", codejwt).then((data) => {
			if (responseAccountJournal(data)) {
				dispatch(setAccountJournal(data.accounts));
			}
		});
	}, []);
	// Función para calcular los totales y la diferencia
	const calculateTotals = () => {
		const totalDebe = journalEntry.journalEntryLines.reduce(
			(acc, line) => acc + (line.debit || 0),
			0
		);
		const totalHaber = journalEntry.journalEntryLines.reduce(
			(acc, line) => acc + (line.credit || 0),
			0
		);
		setTotalDebit(totalDebe);
		setTotalCredit(totalHaber);
		setBalance(totalDebe - totalHaber); // La diferencia entre debe y haber
	};

	useEffect(() => {
		calculateTotals(); // Calcular cuando cambian las líneas del asiento
	}, [journalEntry]);
	const handleAmountChange = (
		index: number,
		field: "debit" | "credit",
		value: number
	) => {
		setJournalEntry((prevState) => {
			let updatedLines = prevState.journalEntryLines.map((line, i) => {
				if (i === index) {
					return { ...line, [field]: value };
				}
				return line;
			});
			if (field === "debit") {
				const debitAccountId =
					prevState.journalEntryLines[index].accountId || undefined;
				updatedLines = updatedLines.map((line) => {
					if (line.credit > 0) {
						return { ...line, debitAccountId };
					}
					return line;
				});
			}
			return { ...prevState, journalEntryLines: updatedLines };
		});
	};

	const addLine = () => {
		const newId =
			Math.max(...journalEntry.journalEntryLines.map((line) => line.id), 0) + 1;

		setJournalEntry({
			...journalEntry,
			journalEntryLines: [
				...journalEntry.journalEntryLines,
				{
					id: newId,
					accountId: 0,
					debitAccountId: 0,
					creditAccountId: 0,
					credit: 0,
					debit: 0,
				},
			],
		});
	};

	const handleDescriptionChange = (
		event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
	) => {
		setJournalEntry({ ...journalEntry, description: event.target.value });
	};

	const handleDateChange = (date: Date | null) => {
		const convertValue = date?.toISOString();
		convertValue && setJournalEntry({ ...journalEntry, date: convertValue });
	};

	const removeLine = (index: number) => {
		if (journalEntry.journalEntryLines.length > 2) {
			const newLines = journalEntry.journalEntryLines.filter(
				(_, i) => i !== index
			);
			const updatedLines = newLines;
			setJournalEntry({ ...journalEntry, journalEntryLines: updatedLines });
		}
	};

	const handleAccountChange = (index: number, accountId: number) => {
		setJournalEntry((prevState) => {
			const updatedLines = prevState.journalEntryLines.map((line, i) => {
				if (i === index) {
					return { ...line, accountId };
				}
				if (prevState.journalEntryLines[index].debit > 0 && line.credit > 0) {
					return { ...line, debitAccountId: accountId };
				}
				return line;
			});
			return { ...prevState, journalEntryLines: updatedLines };
		});
	};
	const hasValidLines = () => {
		return journalEntry.journalEntryLines.some(
			(line) => line.debit > 0 || line.credit > 0
		);
	};

	const handleSubmit = () => {
		let totalDebe = 0;
		let totalHaber = 0;
		const debitLines: { debitAccountId: number | null; amount: number }[] = [];
		const creditLines: { creditAccountId: number | null; amount: number }[] =
			[];
		journalEntry.journalEntryLines.forEach((line) => {
			const { debit, credit, accountId } = line;
			if (debit > 0) {
				totalDebe += debit;
				debitLines.push({ debitAccountId: accountId, amount: debit });
			}
			if (credit > 0) {
				totalHaber += credit;
				creditLines.push({ creditAccountId: accountId, amount: credit });
			}
		});
		if (totalDebe !== totalHaber) {
			return;
		}
		const linesToSend: {
			debitAccountId: number | null;
			creditAccountId: number | null;
			amount: number;
		}[] = [];
		let debitIndex = 0;
		let creditIndex = 0;
		while (debitIndex < debitLines.length && creditIndex < creditLines.length) {
			const debitLine = debitLines[debitIndex];
			const creditLine = creditLines[creditIndex];
			const minAmount = Math.min(debitLine.amount, creditLine.amount); // El valor más bajo para cancelar
			linesToSend.push({
				debitAccountId: debitLine.debitAccountId,
				creditAccountId: creditLine.creditAccountId,
				amount: minAmount,
			});
			debitLine.amount -= minAmount;
			creditLine.amount -= minAmount;
			if (debitLine.amount === 0) {
				debitIndex++;
			}
			if (creditLine.amount === 0) {
				creditIndex++;
			}
		}
		const payload = {
			description: journalEntry.description,
			date: journalEntry.date.toString().split("T")[0],
			journalEntryLines: linesToSend,
		};
		console.log(payload);

		fetchPostRequest(
			"/accountant/journal-entries/create",
			payload,
			codejwt
		).then((data) => {
			if (data.status === 200) {
				setJournalEntry(journalEntriesInitialState);
				setAlertType("success");
				setAlertText("Asiento cargado con éxito");
				setAlert(true);
			} else {
				setAlertType("error");
				setAlertText("Error al cargar asiento");
				setAlert(true);
			}
		});
	};
	useEffect(() => {
		if (alert) {
			const timer = setTimeout(() => setAlert(false), 3000);
			return () => clearTimeout(timer); 
		}
	}, [alert]);
	const isFormValid =
		journalEntry.description.trim() !== "" &&
		journalEntry.date !== "" &&
		balance === 0 &&
		hasValidLines();

	useEffect(() => {
		setIsMounted(true);
	}, []);
	if (!isMounted) {
		return null;
	}
	console.log(journalEntry.description);
	return (
		<>
			<form onSubmit={handleSubmit}>
				<Typography
					variant="h4"
					width="100%"
					textAlign="center"
					fontFamily="Poppins"
				>
					Carga de asientos para libro diario
				</Typography>
				<Box
					sx={{ background: "gray", width: "100%", height: "2px", my: "5%" }}
				/>
				<Box
					display="flex"
					alignItems="flex-end"
					justifyContent="space-around"
					mb="2vw"
				>
					<Box>
						<Typography fontFamily="Poppins">Descripción</Typography>
						<TextInput
							enabled={true}
							value={journalEntry.description}
							name="description"
							onChange={handleDescriptionChange}
							InputProps={{ label: "Descripción" }}
						/>
					</Box>
					<DateInput
						isRounded
						onChange={handleDateChange}
						name="date"
						value={journalEntry.date ? new Date(journalEntry.date) : null}
					/>
				</Box>
				<TableContainer component={Paper}>
					<Table>
						<TableHead>
							<TableRow>
								<TableCell>Cuenta</TableCell>
								<TableCell>Debe</TableCell>
								<TableCell>Haber</TableCell>
								<TableCell>Acciones</TableCell>
							</TableRow>
						</TableHead>
						<TableBody>
							{journalEntry.journalEntryLines.map((line, index) => (
								<TableRow key={line.id}>
									<TableCell width={"25%"}>
										{accounts.length > 0 ? (
											<Select
												sx={{
													...container,
													height: "4vh",
													width: "100%",
												}}
												value={line.accountId || ""}
												onChange={(e) =>
													handleAccountChange(index, Number(e.target.value))
												}
												fullWidth
											>
												{accounts.map((account) => (
													<MenuItem
														key={account.id}
														value={account.id.toString()}
													>
														{account.name} ({account.code})
													</MenuItem>
												))}
											</Select>
										) : (
											<Typography color={"red"}>
												No hay cuentas disponibles
											</Typography>
										)}
									</TableCell>
									<TableCell>
										<TextInput
											enabled={true}
											value={line.debit.toString()}
											name={`debit-${index}`}
											onChange={(e) =>
												handleAmountChange(
													index,
													"debit",
													Number(e.target.value)
												)
											}
											InputProps={{ type: "number" }}
										/>
									</TableCell>
									<TableCell>
										<TextInput
											enabled={true}
											value={line.credit.toString()}
											name={`credit-${index}`}
											onChange={(e) =>
												handleAmountChange(
													index,
													"credit",
													Number(e.target.value)
												)
											}
											InputProps={{ type: "number" }}
										/>
									</TableCell>
									<TableCell>
										<IconButton
											onClick={() => removeLine(index)}
											color="secondary"
										>
											<DeleteIcon />
										</IconButton>
									</TableCell>
								</TableRow>
							))}
							<TableRow>
								<TableCell>Total</TableCell>
								<TableCell>{totalDebit.toFixed(2)}</TableCell>
								<TableCell>{totalCredit.toFixed(2)}</TableCell>
								<TableCell>{balance.toFixed(2)}</TableCell>
							</TableRow>
						</TableBody>
					</Table>
				</TableContainer>
				<Box display="flex" gap="10%" mt="5%" px="15%">
					<ButtonClasic primary={false} onClick={addLine}>
						Agregar línea
					</ButtonClasic>
					<ButtonClasic primary onClick={handleSubmit} disabled={!isFormValid}>
						Guardar
					</ButtonClasic>
				</Box>
			</form>
			{alert && (
				<Box
					sx={{
						width: "40%",
						right: "30%",
						position: "absolute",
						top: "40%",
					}}
				>
					<Alert variant="filled" severity={alertType}>
						{alertText}
					</Alert>
				</Box>
			)}
		</>
	);
}

import { CSSProperties } from "@mui/styles";
export const style: Record<string, CSSProperties> = {
	table: {
		boxShadow: "0px 10px 20px 0px rgba(0, 0, 0, .25)",
		border: "1px solid gray",
		width: "100%",
		/* Estilos para la barra de scroll completa */
		"::-webkit-scrollbar ": {
			height: ".5vw",
		},
		/* Estilos para el "thumb" de la barra de scroll (la parte que se mueve) */
		"::-webkit-scrollbar-thumb": {
			backgroundColor: "#a6d4f2",
			borderRadius: "10px",
			width: "1vw",
			height: "100vw",
		},
		/* (el fondo de la barra) */
		"::-webkit-scrollbar-track": {
			backgroundColor: "transparent",
			borderRadius: "10px",
		},
		/* Hover effect */
		"::-webkit-scrollbar-thumb:hover": {
			backgroundColor: "#5ab8e9" /* Cambio de color al hover */,
		},
		".MuiTableCell-root": {
			whiteSpace: "nowrap",
			textAlign: "center",
		},
		".MuiTableHead-root": {
			background: "#a6d4f2",
		},
		".MuiTableBody-root": {
			".MuiTableCell-root": {
				minWidth: "10vh",
			},
		},
	},
};

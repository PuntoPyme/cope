import * as React from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import TextInput from "../../Inputs/TextInput/TextInput";
import { Box, IconButton, Typography } from "@mui/material";
import { ButtonClasic } from "../../Button/Button-clasic/ButtonClasic";
import NumberInput from "../../Inputs/NumberInputCultivo/NumberInput";
import { style } from "../style";
import { v4 as uuidv4 } from "uuid"; // Importa uuid para generar IDs únicos
import DeleteIcon from "@mui/icons-material/Delete";
import { useSelector } from "react-redux";
import { RootState } from "@/Redux/store";
import { useDispatch } from "react-redux";
import { useState, useEffect } from "react";
import SelectInput from "../../Inputs/SelectInput/SelectInput";
import { vatValue } from "@/utils/Functions/ValidationInputs";
import { InvoiceProduct } from "@/types";
import { setProductRedux } from "@/Redux/features/productReducer";

interface TableProductProps {
	onRowsChange: (rows: InvoiceProduct[]) => void;
}

const RowsInitialState: InvoiceProduct[] = [
	{
		invoiceId: uuidv4(),
		description: "",
		additionalInfo: "",
		quantity: 0,
		amount: 0,
		discount: 0,
		vat: 0,
		grossAmount: 0,
	},
];

const TableProduct: React.FC<TableProductProps> = ({ onRowsChange }) => {
	// -------------------- REDUX -----------------------
	const { items } = useSelector((state: RootState) => state.productReducer);
	const dispatch = useDispatch();
	const [rows, setRows] = useState<InvoiceProduct[]>(RowsInitialState);

	// Función para validar que un valor sea numérico válido
	const validateNumber = (value: any) => {
		return isNaN(value) || value === null || value === undefined ? 0 : value;
	};

	const handleAddRow = () => {
		setRows([
			...rows,
			{
				invoiceId: uuidv4(),
				description: "",
				additionalInfo: "",
				quantity: 0,
				amount: 0,
				discount: 0,
				vat: 0,
				grossAmount: 0,
			},
		]);
	};

	const handleDeleteRow = (id: string) => {
		if (rows.length > 1) {
			const updatedRows = rows.filter((row) => row.invoiceId !== id);
			setRows(updatedRows);
			onRowsChange(updatedRows);
			dispatch(setProductRedux(updatedRows));
		}
	};

	const handleRowChange = <K extends keyof InvoiceProduct>(
		index: number,
		field: K,
		value: InvoiceProduct[K]
	) => {
		const updatedRows = rows.map((row, i) => {
			if (i === index) {
				// Valida que los valores numéricos sean válidos
				const updatedRow = {
					...row,
					[field]: typeof value === "number" ? validateNumber(value) : value,
				};
				updatedRow.grossAmount = calculateAmounts(
					validateNumber(updatedRow.quantity),
					validateNumber(updatedRow.amount),
					validateNumber(updatedRow.discount),
					validateNumber(updatedRow.vat)
				);
				return updatedRow;
			}
			return row;
		});
		setRows(updatedRows);
		onRowsChange(updatedRows);
		dispatch(setProductRedux(updatedRows));
	};

	const handleSelectChange = (index: number, value: string) => {
		const updatedRows = rows.map((row, i) => {
			if (i === index) {
				const newVat = validateNumber(parseFloat(value));
				const updatedRow = {
					...row,
					vat: newVat,
					grossAmount: calculateAmounts(
						validateNumber(row.quantity),
						validateNumber(row.amount),
						validateNumber(row.discount),
						newVat
					),
				};
				return updatedRow;
			}
			return row;
		});
		setRows(updatedRows);
		onRowsChange(updatedRows);
		dispatch(setProductRedux(updatedRows));
	};

	useEffect(() => {
		if (items && items.length > 0) {
			setRows(
				items.map((item) => ({
					...item,
					quantity: validateNumber(item.quantity),
					amount: validateNumber(item.amount),
					discount: validateNumber(item.discount),
					vat: validateNumber(item.vat),
					grossAmount: validateNumber(item.grossAmount),
				}))
			);
		}
	}, [items]);

	return (
		<>
			<TableContainer component={Paper} sx={style.table}>
				<Table sx={{ minWidth: "100%" }} aria-label="simple table">
					<TableHead>
						<TableRow>
							<TableCell>Porcentaje de IVA</TableCell>
							<TableCell align="right">Descripción</TableCell>
							<TableCell align="right">Información adicional</TableCell>
							<TableCell align="right">Cantidad</TableCell>
							<TableCell align="right">Precio</TableCell>
							<TableCell align="right">%Dto.</TableCell>
							<TableCell align="right">Importe bruto</TableCell>
						</TableRow>
					</TableHead>
					<TableBody>
						{rows.map((row, index) => (
							<TableRow key={index}>
								<TableCell sx={{ display: "flex", px: "0 !important" }}>
									<IconButton
										onClick={() => handleDeleteRow(row.invoiceId.toString())}
									>
										<DeleteIcon />
									</IconButton>
									<SelectInput
										arrayOptions={vatValue}
										value={row.vat}
										onValueChange={(value) => handleSelectChange(index, value)}
										size="small"
									/>
								</TableCell>
								<TableCell>
									<TextInput
										enabled={true}
										value={row.description}
										onChange={(e) =>
											handleRowChange(index, "description", e.target.value)
										}
										name="description"
										roundedProp={true}
									/>
								</TableCell>
								<TableCell>
									<TextInput
										enabled={true}
										value={row.additionalInfo}
										onChange={(e) =>
											handleRowChange(index, "additionalInfo", e.target.value)
										}
										name="additionalInfo"
										roundedProp={true}
									/>
								</TableCell>
								<TableCell>
									<NumberInput
										enabled={true}
										value={row.quantity}
										onChange={(e) =>
											handleRowChange(
												index,
												"quantity",
												validateNumber(parseFloat(e.target.value))
											)
										}
										name="precio"
										roundedProp={true}
									/>
								</TableCell>
								<TableCell>
									<NumberInput
										enabled={true}
										value={row.amount}
										onChange={(event) =>
											handleRowChange(
												index,
												"amount",
												validateNumber(parseFloat(event.target.value))
											)
										}
										name="amount"
										roundedProp={true}
									/>
								</TableCell>
								<TableCell>
									<NumberInput
										enabled={true}
										value={row.discount}
										onChange={(event) =>
											handleRowChange(
												index,
												"discount",
												validateNumber(parseFloat(event.target.value))
											)
										}
										name="discount"
										roundedProp={true}
									/>
								</TableCell>
								<TableCell>
									<Typography>$ {row.grossAmount}</Typography>
								</TableCell>
							</TableRow>
						))}
					</TableBody>
				</Table>
			</TableContainer>
			<Box marginTop={"2vw"} marginBottom={"2vw"} width={"15%"}>
				<ButtonClasic primary={false} onClick={handleAddRow}>
					Agregar Item
				</ButtonClasic>
			</Box>
		</>
	);
};

export default TableProduct;
const calculateAmounts = (
	quantity: number,
	amount: number,
	discount: number,
	vat: number
) => {
	const baseAmount = quantity * amount;
	const discountAmount = baseAmount * (discount / 100);
	const vatAmount = (baseAmount - discountAmount) * (vat / 100);
	const grossAmount = baseAmount - discountAmount + vatAmount;
	return grossAmount;
};

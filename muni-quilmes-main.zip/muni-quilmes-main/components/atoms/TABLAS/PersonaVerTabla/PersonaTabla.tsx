import React, { useEffect, useState } from "react";
import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import Checkbox from "../../Checkbox/Checkbox";
import { style } from "../style";
import { Alert, Box, IconButton, Modal, Typography } from "@mui/material";
import CloseIcon from "@/assets/Icons/CloseIcon";
import { PDFViewer } from "@react-pdf/renderer";
import PDFComponentPersona from "@/components/templates/PDFTemplatePersona";
import { fetchGetRequest, fetchPostRequest } from "@/utils/ApiRequest";
import { RootState } from "@/Redux/store";
import { useSelector } from "react-redux";
import { convertValueString } from "@/utils/Functions/ValidationInputs";
import { clienteProveedorVer } from "@/types";
import { filtrarBusqueda, useActionHandler } from "@/utils/Functions/Filters";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
	[`&.${tableCellClasses.head}`]: {
		backgroundColor: theme.palette.common.black,
		color: theme.palette.common.white,
	},
	[`&.${tableCellClasses.body}`]: {
		fontSize: 14,
	},
}));

interface TablaComprobanteProps {
	resultadoAccion: string;
	resultadoBusqueda: string;
	persona: "Proveedores" | "Clientes";
	urlDelete: string;
	data: clienteProveedorVer[];
	onDeleteComplete: () => void; // Nueva prop
}
const TablePerson: React.FC<TablaComprobanteProps> = ({
	resultadoAccion,
	resultadoBusqueda,
	persona,
	urlDelete,
	data,
	onDeleteComplete,
}) => {
	const { codejwt } = useSelector((state: RootState) => state.storeJwt);
	const [headerChecked, setHeaderChecked] = useState<boolean>(false);
	const [isPdfVisible, setIsPdfVisible] = useState<boolean>(false);
	const [originalRows, setOriginalRows] = useState<clienteProveedorVer[]>([]);
	const [checkedState, setCheckedState] = useState<{
		[key: number]: boolean;
	}>({});
	const [rowsChecked, setRowsChecked] = useState<{
		[key: number]: clienteProveedorVer;
	}>({});
	const [rowsState, setRowsState] = useState<clienteProveedorVer[]>([]);
	const closePdfModal = () => {
		setIsPdfVisible(false);
	};

	useEffect(() => {
		setRowsState(data);
		setOriginalRows(data);
		setCheckedState(
			data.reduce((acc, cliente) => {
				acc[cliente.id] = false;
				return acc;
			}, {} as { [key: number]: boolean })
		);
	}, [data]);
	const clientesArray: clienteProveedorVer[] = Object.values(rowsChecked);
	const { alert, alertText, alertType } = useActionHandler(
		resultadoAccion,
		rowsChecked,
		{
			onPrint: () => setIsPdfVisible(true),
			onDelete: async (idsToDelete) => {
				await Promise.all(
					idsToDelete.map((id) =>
						fetchPostRequest(
							urlDelete,
							{ salesInvoiceId: id, status: false },
							codejwt
						)
					)
				);
				setOriginalRows((rows) =>
					rows.filter((row) => !idsToDelete.includes(row.id))
				);
			},
		}
	);

	const handleChange = (
		event: React.MouseEvent<HTMLButtonElement>,
		id: string
	) => {
		const rowId = parseInt(id, 10);
		setCheckedState((prev) => {
			const newState = { ...prev, [rowId]: !prev[rowId] };
			setRowsChecked((prevRows) => {
				const selectedRow = rowsState.find((row) => row.id === rowId);
				if (newState[rowId] && selectedRow) {
					return {
						...prevRows,
						[rowId]: selectedRow,
					};
				} else {
					const { [rowId]: _, ...rest } = prevRows;
					return rest;
				}
			});
			return newState;
		});
	};

	const handleHeaderCheckboxChange = (
		event: React.MouseEvent<HTMLButtonElement>
	) => {
		const isChecked = !headerChecked;
		setHeaderChecked(isChecked);
		// Actualiza el estado de todos los checkboxes
		setCheckedState((prev) => {
			const newCheckedState = { ...prev };
			rowsState.forEach((row) => {
				newCheckedState[row.id] = isChecked;
			});
			return newCheckedState;
		});
		// Actualiza el estado de las filas seleccionadas
		setRowsChecked(() => {
			if (isChecked) {
				const allRowsChecked = rowsState.reduce<{
					[key: number]: clienteProveedorVer;
				}>((acc, row) => {
					acc[row.id] = row;
					return acc;
				}, {});
				return allRowsChecked;
			} else {
				return {};
			}
		});
	};

	useEffect(() => {
		if (resultadoBusqueda.length > 0) {
			setRowsState(filtrarBusqueda(originalRows, resultadoBusqueda));
		} else {
			setRowsState(originalRows);
		}
	}, [resultadoBusqueda, originalRows]);

	return (
		<>
			{rowsState.length > 0 ? (
				<TableContainer
					component={Paper}
					sx={{
						...style.table,
					}}
				>
					<Table sx={{ minWidth: "100%" }} aria-label="simple table">
						<TableHead>
							<TableRow>
								<TableCell>
									<Checkbox
										checked={headerChecked}
										size="small"
										onChange={handleHeaderCheckboxChange}
										name=""
									/>
								</TableCell>
								<TableCell>Nombre</TableCell>
								<TableCell align="right">CUIT</TableCell>
								<TableCell align="right">Condición IVA</TableCell>
								<TableCell align="right">Teléfono</TableCell>
								<TableCell align="right">Email</TableCell>
								<TableCell align="right">Provincia</TableCell>
								<TableCell align="right">Ciudad</TableCell>
								<TableCell align="right">Dirección</TableCell>
								<TableCell align="right">Unidad</TableCell>
								{persona === "Proveedores" && (
									<TableCell align="right">País</TableCell>
								)}
							</TableRow>
						</TableHead>
						<TableBody>
							{rowsState.map((row) => (
								<TableRow key={row.id}>
									<StyledTableCell component="th" scope="row">
										<Checkbox
											checked={checkedState[row.id]}
											size="small"
											onChange={handleChange}
											name={`${row.id}`}
										/>
									</StyledTableCell>
									<StyledTableCell component="th" scope="row">
										{row.name}
									</StyledTableCell>
									<StyledTableCell component="th" scope="row">
										{row.cuit}
									</StyledTableCell>
									<StyledTableCell component="th" scope="row">
										{convertValueString(row.vat)}
									</StyledTableCell>
									<StyledTableCell component="th" scope="row">
										{row.contact.phone}
									</StyledTableCell>
									<StyledTableCell component="th" scope="row">
										{row.contact.email}
									</StyledTableCell>
									<StyledTableCell component="th" scope="row">
										{convertValueString(row.address.province)}
									</StyledTableCell>

									<StyledTableCell component="th" scope="row">
										{convertValueString(row.address.city)}
										<br></br>
										CP: {row.address.postalCode}
									</StyledTableCell>
									<StyledTableCell component="th" scope="row">
										{row.address.street}
										<br></br>
										{row.address.number}
									</StyledTableCell>
									<StyledTableCell component="th" scope="row">
										Edificio: {row.address.building}
										<br></br>
										Piso: {row.address.floor}
										<br></br>
										Departamento: {row.address.apartament}
									</StyledTableCell>
									{persona === "Proveedores" && (
										<StyledTableCell component="th" scope="row">
											{row.country}
										</StyledTableCell>
									)}
								</TableRow>
							))}
						</TableBody>
					</Table>
				</TableContainer>
			) : (
				<Typography
					textTransform={"uppercase"}
					variant="h5"
					fontFamily={"Poppins"}
					textAlign={"center"}
					sx={{ background: "#ffffff90", p: "5%", borderRadius: "40px" }}
				>
					NO HAY {persona} CARGADOS,
					<br></br>
					para crear un nuevo {persona === "Clientes"
						? "cliente"
						: "proveedor"}{" "}
					selecciona "nueva ventana"
				</Typography>
			)}
			<Modal
				open={isPdfVisible}
				onClose={closePdfModal}
				aria-labelledby="pdf-modal-title"
				aria-describedby="pdf-modal-description"
			>
				<Box
					style={{
						display: "flex",
						justifyContent: "center",
						height: "100%",
						alignItems: "center",
					}}
				>
					<Box
						sx={{
							borderRadius: "50% !important",
							position: "absolute",
							top: "5vh",
							right: "15%",
							".MuiButtonBase-root": {
								border: "2px solid white",
								"&:hover": {
									boxShadow: " 5px 5px #ffffff90",
								},
							},
						}}
					>
						<IconButton onClick={closePdfModal} sx={{ color: "white" }}>
							<CloseIcon />
						</IconButton>
					</Box>
					<PDFViewer width="50%" height="90%">
						<PDFComponentPersona row={clientesArray} persona={persona} />
					</PDFViewer>
				</Box>
			</Modal>
			{alert ? (
				<Box
					sx={{
						width: "40%",
						right: "30%",
						position: "absolute",
						top: "40%",
					}}
				>
					<Alert variant="filled" severity={alertType}>
						{alertText}
					</Alert>
				</Box>
			) : null}
		</>
	);
};
export default TablePerson;

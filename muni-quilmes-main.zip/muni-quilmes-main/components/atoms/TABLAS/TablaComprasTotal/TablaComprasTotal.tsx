import * as React from "react";
import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import TextInput from "../../Inputs/TextInput/TextInput";
import NumberInput from "../../Inputs/NumberInputCultivo/NumberInput";
import { style } from "../style";
import { ButtonClasic } from "../../Button/Button-clasic/ButtonClasic";
import { Box, IconButton } from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import { v4 as uuidv4 } from "uuid"; // Importa uuid para generar IDs únicos

interface rowsType {
	id: string;
	producto: string;
	observaciones: string;
	importe: number;
}
export default function TablaComprasTotal() {
	const [rows, setRows] = React.useState<rowsType[]>([
		{ id: uuidv4(), producto: "", observaciones: "", importe: 0 },
	]);

	const handleAddRow = () => {
		setRows([
			...rows,
			{ id: uuidv4(), producto: "", observaciones: "", importe: 0 },
		]);
	};

	const handleRowChange = <K extends keyof rowsType>(
		index: number,
		field: K,
		value: rowsType[K]
	) => {
		const updatedRows = [...rows];
		updatedRows[index][field] = value;
		setRows(updatedRows);
	};
	const handleDeleteRow = (id: string) => {
		if (rows.length > 1) {
			const updatedRows = rows.filter((row) => row.id !== id);
			setRows(updatedRows);
		}
	};
	return (
		<>
			<TableContainer component={Paper} sx={style.table}>
				<Table sx={{ minWidth: "100%" }} aria-label="simple table">
					<TableHead>
						<TableRow>
							<TableCell>Producto/Impuesto</TableCell>
							<TableCell align="right">Observaciones</TableCell>
							<TableCell align="right">Importe</TableCell>
						</TableRow>
					</TableHead>
					<TableBody>
						{rows.map((rows, index) => (
							<TableRow key={index}>
								<TableCell sx={{ display: "flex" }}>
									<IconButton onClick={() => handleDeleteRow(rows.id)}>
										<DeleteIcon />
									</IconButton>
									<TextInput
										enabled={true}
										value={rows.producto}
										onChange={(event) =>
											handleRowChange(
												index,
												event.target.name as keyof rowsType,
												event.target.value
											)
										}
										name="producto"
										roundedProp={true}
									/>
								</TableCell>
								<TableCell>
									<TextInput
										enabled={true}
										value={rows.observaciones}
										onChange={(event) =>
											handleRowChange(
												index,
												event.target.name as keyof rowsType,
												event.target.value
											)
										}
										name="observaciones"
										roundedProp={true}
									/>
								</TableCell>
								<TableCell>
									<NumberInput
										enabled={true}
										value={rows.importe}
										onChange={(event) =>
											handleRowChange(
												index,
												event.target.name as keyof rowsType,
												event.target.value
											)
										}
										name="importe"
										roundedProp={true}
									/>
								</TableCell>
							</TableRow>
						))}
					</TableBody>
				</Table>
			</TableContainer>
			<Box
				marginTop={"2vw"}
				marginBottom={"2vw"}
				width={"30%"}
			>
				<ButtonClasic primary={false} onClick={handleAddRow}>
					Agregar Percepción
				</ButtonClasic>
			</Box>
		</>
	);
}

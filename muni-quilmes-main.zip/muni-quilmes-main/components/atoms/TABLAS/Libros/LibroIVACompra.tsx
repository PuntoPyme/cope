import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { style } from "../style";
import { compraVer, ventaVer } from "@/types";
import React, { useEffect, useState } from "react";
import { Alert, Box } from "@mui/material";
import {
	filterRowsByDateRange,
	formatDate,
} from "@/utils/Functions/Filters";
import { convertValueString } from "@/utils/Functions/ValidationInputs";
import { addDays } from "date-fns";
import { filtrarBusqueda } from "@/utils/Functions/Filters";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
	[`&.${tableCellClasses.head}`]: {
		backgroundColor: theme.palette.common.black,
		color: theme.palette.common.white,
	},
	[`&.${tableCellClasses.body}`]: {
		fontSize: 14,
	},
}));
interface tablaProps {
	periodo?: { desde: Date | null; hasta: Date | null };
	resultadoBusqueda?: string;
	itemsForRows: compraVer[];
	type: "sales" | "purchase";
}

const BookVatCompra: React.FC<tablaProps> = ({
	periodo,
	resultadoBusqueda,
	itemsForRows,
	type,
}) => {
	const [alert, setAlert] = useState<boolean>(false);
	const [originalRows, setOriginalRows] = useState<compraVer[]>(itemsForRows);
	const [rowsState, setRowsState] = useState<compraVer[]>(itemsForRows);

	const [alertType, setAlertType] = useState<
		"error" | "info" | "success" | "warning"
	>("info");

	const [alertText, setAlertText] = useState<string>("");

	useEffect(() => {
		setOriginalRows(itemsForRows);
	}, [itemsForRows]);

	useEffect(() => {
		if (resultadoBusqueda && resultadoBusqueda.length > 0) {
			setRowsState(filtrarBusqueda(originalRows, resultadoBusqueda));
		} else {
			setRowsState(originalRows);
		}
	}, [resultadoBusqueda, originalRows]);
	useEffect(() => {
		if (
			periodo &&
			periodo.desde &&
			periodo.hasta &&
			periodo.desde !== null &&
			periodo.hasta !== null &&
			originalRows.length > 0
		) {
			setRowsState(
				filterRowsByDateRange(periodo.desde, periodo.hasta, originalRows)
			);
		} else {
			setRowsState(originalRows);
		}
	}, [periodo, originalRows]);

	useEffect(() => {
		setTimeout(() => {
			setAlert(false);
		}, 3000);
	}, [alert]);

	return (
		<>
			<Box width={"95vw"}>
				<TableContainer component={Paper} sx={style.table}>
					<Table sx={{ minWidth: "100%" }} aria-label="sales table">
						<TableHead>
							<TableRow>
								<TableCell>Fecha</TableCell>
								<TableCell>Tipo</TableCell>
								<TableCell>Comprobante</TableCell>
								<TableCell>
									{type === "purchase" ? "Proveedor" : "Cliente"}
								</TableCell>
								<TableCell>Vencimiento</TableCell>
								<TableCell>Monto Bruto</TableCell>
								<TableCell>Método de Pago</TableCell>
								<TableCell>IVA%</TableCell>
								<TableCell>IVA 10.5%</TableCell>
								<TableCell>IVA 21%</TableCell>
								<TableCell>Total</TableCell>
							</TableRow>
						</TableHead>
						<TableBody>
							{rowsState.map((row) => (
								<TableRow key={row.id}>
									<StyledTableCell>
										{formatDate(addDays(new Date(row.date), 1))}
									</StyledTableCell>
									<StyledTableCell>
										{convertValueString(row.invoiceType)}
									</StyledTableCell>
									<StyledTableCell>{row.number}</StyledTableCell>
									<StyledTableCell>
										{"customerName" in row
											? row.customerName
											: "supplierName" in row
											? row.supplierName
											: ""}
									</StyledTableCell>
									<StyledTableCell>
										{formatDate(addDays(new Date(row.expiration_date), 1))}
									</StyledTableCell>
									<StyledTableCell>
										{row.grossAmount.toFixed(2)}
									</StyledTableCell>
									<StyledTableCell>
										{convertValueString(row.paymentMethod)}
									</StyledTableCell>
									<StyledTableCell>{row.vat.toFixed(2)}</StyledTableCell>
									<StyledTableCell>{row.vat105.toFixed(2)}</StyledTableCell>
									<StyledTableCell>{row.vat21.toFixed(2)}</StyledTableCell>
									<StyledTableCell>{row.amount.toFixed(2)}</StyledTableCell>
								</TableRow>
							))}
						</TableBody>
					</Table>
				</TableContainer>
				{alert ? (
					<Box
						sx={{
							width: "40%",
							right: "30%",
							position: "absolute",
							top: "40%",
						}}
					>
						<Alert variant="filled" severity={alertType}>
							{alertText}
						</Alert>
					</Box>
				) : null}
			</Box>
		</>
	);
};

export default BookVatCompra;

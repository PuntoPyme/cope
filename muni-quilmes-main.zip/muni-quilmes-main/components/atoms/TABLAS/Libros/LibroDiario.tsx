import {
	Alert,
	Box,
	IconButton,
	Modal,
	styled,
	Typography,
} from "@mui/material";
import React, { MouseEvent, useEffect, useState } from "react";
import {
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	Paper,
} from "@mui/material";
import {
	JournalEntryLine,
	JournalEntryResponse,
	ProcessedJournalEntry,
} from "@/types";
import { addDays } from "date-fns";
import Checkbox from "../../Checkbox/Checkbox";
import { BASE_URL } from "@/utils/ApiRequest";
import { PDFViewer } from "@react-pdf/renderer";
import PDFLibroDiario from "@/components/templates/PDFLibroDiario";
import { useSelector } from "react-redux";
import { RootState } from "@/Redux/store";
import CloseIcon from "@/assets/Icons/CloseIcon";
import {
	filterRowsByDateRange,
	filtrarBusqueda,
	useActionHandler,
} from "@/utils/Functions/Filters";

type GroupedLines = {
	debit: Record<string, { accountName: string; amount: number }>;
	credit: Record<string, { accountName: string; amount: number }>;
};

interface JournalTableProps {
	journalEntries: JournalEntryResponse[] | undefined;
	resultadoBusqueda: string;
	resultadoAccion: string;
	periodo: { desde: Date | null; hasta: Date | null };
}

const HeaderRow = styled(TableRow)(({ theme }) => ({
	backgroundColor: "#a6d4f2",
	"& > th": {
		color: "black",
		fontWeight: "bold",
	},
}));

const DocumentRow = styled(TableRow)(({ theme }) => ({
	backgroundColor: theme.palette.grey[200],
	"& > td": {
		fontWeight: "bold",
		padding: theme.spacing(1, 2),
	},
}));

const TotalRow = styled(TableRow)(({ theme }) => ({
	borderTop: `2px solid ${theme.palette.divider}`,
	"& > td": {
		fontWeight: "bold",
	},
}));
const LibroDiario: React.FC<JournalTableProps> = ({
	journalEntries,
	resultadoBusqueda,
	periodo,
	resultadoAccion,
}) => {
	const [selectedEntries, setSelectedEntries] = useState<
		JournalEntryResponse[]
	>([]);
	const [headerChecked, setHeaderChecked] = useState<boolean>(false);
	const [grandTotalDebit, setGrandTotalDebit] = useState(0);
	const [grandTotalCredit, setGrandTotalCredit] = useState(0);
	const [isPdfVisible, setIsPdfVisible] = useState<boolean>(false);
	const { codejwt } = useSelector((state: RootState) => state.storeJwt);
	const closePdfModal = () => {
		setIsPdfVisible(false);
	};

	const { alert, alertText, alertType } = useActionHandler(
		resultadoAccion,
		selectedEntries,
		{
			onPrint: () => setIsPdfVisible(true),
			onDelete: async (idsToDelete) => {
				await Promise.all(
					idsToDelete.map((id) =>
						Delete(`/accountant/journal-entries`, id, codejwt)
					)
				);
				setRowsState((rows) => {
					if (!rows) return [];
					return rows.filter((row) => !idsToDelete.includes(row.id));
				});
			},
		}
	);

	const [rowsState, setRowsState] = useState<
		JournalEntryResponse[] | undefined
	>(journalEntries);

	useEffect(() => {
		setRowsState(journalEntries);
	}, [journalEntries]);

	useEffect(() => {
		if (resultadoBusqueda && journalEntries) {
			setRowsState(filtrarBusqueda(journalEntries, resultadoBusqueda));
		} else {
			setRowsState(journalEntries);
		}
	}, [resultadoBusqueda, journalEntries]);

	useEffect(() => {
		if (rowsState) {
			let totalDebit = 0;
			let totalCredit = 0;
			rowsState.forEach((entry) => {
				entry.journalEntryLines.forEach((line) => {
					if (line.debitAccountId) totalDebit += line.amount;
					if (line.creditAccountId) totalCredit += line.amount;
				});
			});
			setGrandTotalDebit(totalDebit);
			setGrandTotalCredit(totalCredit);
		}
	}, [rowsState]);
	useEffect(() => {
		if (
			periodo &&
			periodo.desde &&
			periodo.hasta &&
			periodo.desde !== null &&
			periodo.hasta !== null &&
			journalEntries &&
			journalEntries.length > 0
		) {
			setRowsState(
				filterRowsByDateRange(periodo.desde, periodo.hasta, journalEntries)
			);
		} else {
			setRowsState(journalEntries);
		}
	}, [periodo, journalEntries]);
	const formatDate = (dateString: string) => {
		const [year, month, day] = dateString.split("-").map(Number);
		const date = new Date(year, month - 1, day); // Ajusta el mes restando 1 (enero es 0)
		return date.toLocaleDateString("es-ES", {
			day: "2-digit",
			month: "2-digit",
			year: "numeric",
		});
	};

	const handleCheckboxChange = (entry: JournalEntryResponse) => {
		setSelectedEntries((prevSelected) => {
			const isSelected = prevSelected.some(
				(selectedEntry) => selectedEntry.id === entry.id
			);
			let newSelectedEntries;
			if (isSelected) {
				newSelectedEntries = prevSelected.filter(
					(selectedEntry) => selectedEntry.id !== entry.id
				);
			} else {
				newSelectedEntries = [...prevSelected, entry];
			}

			if (rowsState && newSelectedEntries.length === rowsState.length) {
				setHeaderChecked(true);
			} else {
				setHeaderChecked(false);
			}

			return newSelectedEntries;
		});
	};

	const handleHeaderCheckboxChange = () => {
		const isChecked = !headerChecked;
		setHeaderChecked(isChecked);
		if (isChecked && rowsState) {
			setSelectedEntries(rowsState);
		} else {
			setSelectedEntries([]);
		}
	};
	const handlePrintPDF = (): ProcessedJournalEntry[] => {
		return selectedEntries.map((entry) => {
			const groupedLines: GroupedLines = entry.journalEntryLines.reduce(
				(acc, line) => {
					const { debitAccountName, creditAccountName, amount } = line;

					if (debitAccountName) {
						acc.debit[debitAccountName] = acc.debit[debitAccountName] || {
							accountName: debitAccountName,
							amount: 0,
						};
						acc.debit[debitAccountName].amount += amount;
					}
					if (creditAccountName) {
						acc.credit[creditAccountName] = acc.credit[creditAccountName] || {
							accountName: creditAccountName,
							amount: 0,
						};
						acc.credit[creditAccountName].amount += amount;
					}
					return acc;
				},
				{ debit: {}, credit: {} } as GroupedLines
			);

			const renderLines = Object.entries(groupedLines).flatMap(
				([type, lines]) =>
					Object.values(lines).map((line) => ({
						...line,
						isDebit: type === "debit",
					}))
			);

			const totalDebit = renderLines
				.filter((line) => line.isDebit)
				.reduce((sum, line) => sum + line.amount, 0);

			const totalCredit = renderLines
				.filter((line) => !line.isDebit)
				.reduce((sum, line) => sum + line.amount, 0);

			return {
				id: entry.id,
				date: entry.date,
				document: entry.document,
				renderLines,
				totalDebit,
				totalCredit,
			};
		});
	};
	const renderJournalEntry = (entry: JournalEntryResponse) => {
		let totalDebit = 0;
		let totalCredit = 0;

		const groupedLines: GroupedLines = entry.journalEntryLines.reduce(
			(acc, line) => {
				const { debitAccountName, creditAccountName, amount } = line;

				if (debitAccountName) {
					acc.debit[debitAccountName] = acc.debit[debitAccountName] || {
						accountName: debitAccountName,
						amount: 0,
					};
					acc.debit[debitAccountName].amount += amount;
				}
				if (creditAccountName) {
					acc.credit[creditAccountName] = acc.credit[creditAccountName] || {
						accountName: creditAccountName,
						amount: 0,
					};
					acc.credit[creditAccountName].amount += amount;
				}
				return acc;
			},
			{ debit: {}, credit: {} } as GroupedLines
		);

		const renderLines = Object.entries(groupedLines).flatMap(([type, lines]) =>
			Object.values(lines).map((line) => ({
				...line, // Aquí ya sabemos que "line" es un objeto y el spread funciona bien
				isDebit: type === "debit",
			}))
		);

		return (
			<React.Fragment key={entry.id}>
				<DocumentRow>
					<TableCell colSpan={4}>
						<Box display="flex" alignItems="center">
							<Checkbox
								name=""
								checked={selectedEntries.includes(entry)}
								onChange={() => handleCheckboxChange(entry)}
								size="small"
							/>
							Documento:{" "}
							{entry.document || `Asiento N° ${entry.id}- ${entry.description}`}
						</Box>
					</TableCell>
				</DocumentRow>
				{renderLines.map((line, index) => {
					const { isDebit, accountName, amount } = line;
					isDebit ? (totalDebit += amount) : (totalCredit += amount);
					return (
						<TableRow key={`${entry.id}-${accountName}-${index}`}>
							{index === 0 && (
								<TableCell rowSpan={renderLines.length + 1}>
									{entry.date ? formatDate(entry.date.toString()) : ""}
								</TableCell>
							)}
							<TableCell>{accountName}</TableCell>
							<TableCell align="center">
								{isDebit ? amount.toFixed(2) : ""}
							</TableCell>
							<TableCell align="center">
								{!isDebit ? amount.toFixed(2) : ""}
							</TableCell>
						</TableRow>
					);
				})}
				<TotalRow>
					<TableCell>Totales</TableCell>
					<TableCell align="center">{totalDebit.toFixed(2)}</TableCell>
					<TableCell align="center">{totalCredit.toFixed(2)}</TableCell>
				</TotalRow>
			</React.Fragment>
		);
	};

	return (
		<>
			{rowsState && rowsState.length > 0 ? (
				<TableContainer component={Paper}>
					<Table>
						<TableHead>
							<HeaderRow>
								<TableCell sx={{ display: "flex", alignItems: "center" }}>
									<Checkbox
										checked={headerChecked}
										size="small"
										onChange={handleHeaderCheckboxChange}
										name=""
									/>
									Fecha
								</TableCell>
								<TableCell>Cuenta</TableCell>
								<TableCell align="center">Debe</TableCell>
								<TableCell align="center">Haber</TableCell>
							</HeaderRow>
						</TableHead>
						<TableBody>
							{rowsState.map(renderJournalEntry)}
							<HeaderRow>
								<TableCell sx={{ fontWeight: "bold" }}>Total</TableCell>
								<TableCell sx={{ fontWeight: "bold" }}></TableCell>
								<TableCell align="center" sx={{ fontWeight: "bold" }}>
									{grandTotalDebit}
								</TableCell>
								<TableCell align="center" sx={{ fontWeight: "bold" }}>
									{grandTotalCredit}
								</TableCell>
							</HeaderRow>
						</TableBody>
					</Table>
				</TableContainer>
			) : (
				<Typography textAlign="center" fontFamily="Poppins" variant="h4">
					No hay asientos cargados
				</Typography>
			)}
			<Modal
				open={isPdfVisible}
				onClose={closePdfModal}
				aria-labelledby="pdf-modal-title"
				aria-describedby="pdf-modal-description"
			>
				<Box
					style={{
						display: "flex",
						justifyContent: "center",
						height: "100%",
						alignItems: "center",
					}}
				>
					<Box
						sx={{
							borderRadius: "50% !important",
							position: "absolute",
							top: "5vh",
							right: "15%",
							".MuiButtonBase-root": {
								border: "2px solid white",
								"&:hover": {
									boxShadow: " 5px 5px #ffffff90",
								},
							},
						}}
					>
						<IconButton onClick={closePdfModal} sx={{ color: "white" }}>
							<CloseIcon />
						</IconButton>
					</Box>
					<PDFViewer width="50%" height="90%">
						<PDFLibroDiario entries={handlePrintPDF()} />
					</PDFViewer>
				</Box>
			</Modal>
			{alert ? (
				<Box
					sx={{
						width: "40%",
						right: "30%",
						position: "absolute",
						top: "40%",
					}}
				>
					<Alert variant="filled" severity={alertType}>
						{alertText}
					</Alert>
				</Box>
			) : null}
		</>
	);
};

export default LibroDiario;

async function Delete(url: string, id: number, jwt: string): Promise<Response> {
	const fullUrl = `${url}/${id}`;
	const response = await fetch(`${BASE_URL}${fullUrl}`, {
		method: "DELETE",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${jwt}`,
		},
	});
	if (!response.ok) {
		throw new Error(`HTTP error! status: ${response.status}`);
	}
	return response;
}

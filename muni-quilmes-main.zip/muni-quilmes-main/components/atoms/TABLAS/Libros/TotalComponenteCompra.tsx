import React from "react";
import {
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	Paper,
	styled,
} from "@mui/material";
import { style } from "../style";

export interface IvaVentaLibro {
	totalAmount: number;
	totalVat: number;
	totalVat21: number;
	totalVat105: number;
	totalGrossAmount: number;
}

const categories = [
	"ResponsableInscripto",
	"ConsumidorFinal",
	"Monotributista",
	"NoAlcanzado",
	"Exento",
	"TotalGeneral",
] as const;

const summaryLabels = [
	"Neto Gravado 21%",
	"IVA 21%",
	"Neto Gravado 10.5%",
	"IVA 10.5%",
	"Total Bruto",
] as const;

type Category = (typeof categories)[number];
type SummaryLabel = (typeof summaryLabels)[number];

type SummaryData = {
	[K in Category]: {
		[L in SummaryLabel]: number;
	};
};

export default function TotalComponenteCompra({
	data,
}: {
	data: IvaVentaLibro | undefined;
}) {
	if (!data) {
		return null; // or some loading state
	}

	const summaryData: SummaryData = {
		ResponsableInscripto: {
			"Neto Gravado 21%": data.totalAmount,
			"IVA 21%": data.totalVat21,
			"Neto Gravado 10.5%": 0,
			"IVA 10.5%": data.totalVat105,
			"Total Bruto": data.totalGrossAmount,
		},
		ConsumidorFinal: {
			"Neto Gravado 21%": 0,
			"IVA 21%": 0,
			"Neto Gravado 10.5%": 0,
			"IVA 10.5%": 0,
			"Total Bruto": 0,
		},
		Monotributista: {
			"Neto Gravado 21%": 0,
			"IVA 21%": 0,
			"Neto Gravado 10.5%": 0,
			"IVA 10.5%": 0,
			"Total Bruto": 0,
		},
		NoAlcanzado: {
			"Neto Gravado 21%": 0,
			"IVA 21%": 0,
			"Neto Gravado 10.5%": 0,
			"IVA 10.5%": 0,
			"Total Bruto": 0,
		},
		Exento: {
			"Neto Gravado 21%": 0,
			"IVA 21%": 0,
			"Neto Gravado 10.5%": 0,
			"IVA 10.5%": 0,
			"Total Bruto": 0,
		},
		TotalGeneral: {
			"Neto Gravado 21%": data.totalAmount,
			"IVA 21%": data.totalVat21,
			"Neto Gravado 10.5%": 0,
			"IVA 10.5%": data.totalVat105,
			"Total Bruto": data.totalGrossAmount,
		},
	};

	return (
		<TableContainer component={Paper} sx={style.table}>
			<Table aria-label="summary table">
				<TableHead>
					<TableRow>
						<TableCell>Categoría</TableCell>
						{summaryLabels.map((label, index) => (
							<TableCell key={index}>{label}</TableCell>
						))}
					</TableRow>
				</TableHead>
				<TableBody>
					{categories.map((category) => (
						<TableRow key={category}>
							<TableCell component="th" scope="row">
								{category}
							</TableCell>
							{summaryLabels.map((label, index) => (
								<TableCell key={index}>
									{summaryData[category][label].toFixed(2)}
								</TableCell>
							))}
						</TableRow>
					))}
				</TableBody>
			</Table>
		</TableContainer>
	);
}

import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { style } from "../style";
import { compraVer, ventaVer } from "@/types";
import React, { useEffect, useState } from "react";
import { Alert, Box } from "@mui/material";
import { convertValueString } from "@/utils/Functions/ValidationInputs";
import { addDays } from "date-fns";
import { filterRowsByDateRange, filtrarBusqueda, formatDate } from "@/utils/Functions/Filters";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
	[`&.${tableCellClasses.head}`]: {
		backgroundColor: theme.palette.common.black,
		color: theme.palette.common.white,
	},
	[`&.${tableCellClasses.body}`]: {
		fontSize: 14,
	},
}));
interface tablaProps {
	periodo?: { desde: Date | null; hasta: Date | null };
	resultadoBusqueda?: string;
	itemsForRows: ventaVer[];
	type: "sales" | "purchase";
}

const BookVat: React.FC<tablaProps> = ({
	periodo,
	resultadoBusqueda,
	itemsForRows,
	type,
}) => {
	const [alert, setAlert] = useState<boolean>(false);
	const [originalRows, setOriginalRows] = useState<ventaVer[]>(itemsForRows);
	const [rowsState, setRowsState] = useState<ventaVer[]>(itemsForRows);

	useEffect(() => {
		setOriginalRows(itemsForRows);
	}, [itemsForRows]);
	useEffect(() => {
		if (resultadoBusqueda && resultadoBusqueda.length > 0) {
			setRowsState(filtrarBusqueda(originalRows, resultadoBusqueda));
		} else {
			setRowsState(originalRows);
		}
	}, [resultadoBusqueda, originalRows]);

	useEffect(() => {
		if (
			periodo &&
			periodo.desde &&
			periodo.hasta &&
			periodo.desde !== null &&
			periodo.hasta !== null &&
			originalRows.length > 0
		) {
			setRowsState(
				filterRowsByDateRange(periodo.desde, periodo.hasta, originalRows)
			);
		} else {
			setRowsState(originalRows);
		}
	}, [periodo, originalRows]);

	useEffect(() => {
		setTimeout(() => {
			setAlert(false);
		}, 3000);
	}, [alert]);

	return (
		<>
			<Box width={"95vw"}>
				<TableContainer component={Paper} sx={style.table}>
					<Table sx={{ minWidth: "100%" }} aria-label="sales table">
						<TableHead>
							<TableRow>
								<TableCell>Fecha</TableCell>
								<TableCell>Tipo</TableCell>
								<TableCell>Comprobante</TableCell>
								<TableCell>
									{type === "purchase" ? "Proveedor" : "Cliente"}
								</TableCell>
								<TableCell>Vencimiento</TableCell>
								<TableCell>Monto Bruto</TableCell>
								<TableCell>Método de Pago</TableCell>
								<TableCell>IVA%</TableCell>
								<TableCell>IVA 10.5%</TableCell>
								<TableCell>IVA 21%</TableCell>
								<TableCell>Ret. IVA</TableCell>
								<TableCell>IIBB</TableCell>
								<TableCell>Imp. Internos</TableCell>
								<TableCell>Neto 21%</TableCell>
								<TableCell>Neto 10.5%</TableCell>
								<TableCell>Neto 0%</TableCell>
								<TableCell>Cond. IVA</TableCell>
								<TableCell>Cond. IVA Cliente</TableCell>
								<TableCell>Total</TableCell>
							</TableRow>
						</TableHead>
						<TableBody>
							{rowsState.map((row) => (
								<TableRow key={row.id}>
									<StyledTableCell>
										{formatDate(addDays(new Date(row.date), 1))}
									</StyledTableCell>
									<StyledTableCell>
										{convertValueString(row.invoiceType)}
									</StyledTableCell>
									<StyledTableCell>{row.number}</StyledTableCell>
									<StyledTableCell>{row.customerName}</StyledTableCell>
									<StyledTableCell>
										{formatDate(addDays(new Date(row.expiration_date), 1))}
									</StyledTableCell>
									<StyledTableCell>
										{row.grossAmount.toFixed(2)}
									</StyledTableCell>
									<StyledTableCell>
										{convertValueString(row.paymentMethod)}
									</StyledTableCell>
									<StyledTableCell>{row.vat.toFixed(2)}</StyledTableCell>
									<StyledTableCell>{row.vat105.toFixed(2)}</StyledTableCell>
									<StyledTableCell>{row.vat21.toFixed(2)}</StyledTableCell>
									<StyledTableCell>
										{row.retVat ? row.retVat.toFixed(2) : "0"}
									</StyledTableCell>
									<StyledTableCell>
										{row.iibb ? row.iibb.toFixed(2) : "0"}
									</StyledTableCell>
									<StyledTableCell>
										{row.internalTaxes ? row.internalTaxes.toFixed(2) : "0"}
									</StyledTableCell>
									<StyledTableCell>
										{row.amountNet21.toFixed(2)}
									</StyledTableCell>
									<StyledTableCell>
										{row.amountNet105.toFixed(2)}
									</StyledTableCell>
									<StyledTableCell>{row.amountNet0.toFixed(2)}</StyledTableCell>
									<StyledTableCell>
										{row.vatCondition
											? convertValueString(row.vatCondition)
											: ""}
									</StyledTableCell>
									<StyledTableCell>
										{row.vatCondition
											? convertValueString(row.vatCondition)
											: "N/A"}
									</StyledTableCell>
									<StyledTableCell>{row.amount.toFixed(2)}</StyledTableCell>
								</TableRow>
							))}
						</TableBody>
					</Table>
				</TableContainer>
			</Box>
		</>
	);
};

export default BookVat;

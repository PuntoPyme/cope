import React, { useState, useEffect } from "react";
import Box from "@mui/material/Box";
import { Divider, IconButton, InputAdornment } from "@mui/material";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import Typography from "@mui/material/Typography";
import { Container, Card, CardContent, TextField, Grid } from "@mui/material";
import { style } from "./InicioFormularioStyle";
import { ButtonHome } from "../Button/Button-home/ButtonHome";
import image from "../../../assets/back.jpg";
import logo from "../../../assets/logoquilmes.png";
import Image from "next/image";
import router, { useRouter } from "next/router";
import Link from "next/link";
import FooterIn from "../FooterIn/FooterIn";
import { PostLogin } from "@/utils/ApiRequest";
import { useDispatch } from "react-redux";
import { setCodeJwtState } from "@/Redux/features/Codejwt";
import InputContact from "../Contacto/Inputs";
import { isValidEmail } from "@/utils/Functions/ValidationInputs";
export interface BasicModalProps {
	labelCuenta?: string;
	labelContraseña?: string;
}

export default function BasicModal({
	labelCuenta,
	labelContraseña,
}: BasicModalProps) {
	const dispatch = useDispatch();
	const [mail, setMail] = useState("");
	const [contrasena, setContrasena] = useState("");
	const [showPassword, setShowPassword] = useState(false);
	const router = useRouter();
	const [formErrors, setFormErrors] = useState({
		email: false,
	});
	useEffect(() => {
		setFormErrors((prev) => ({ ...prev, email: !isValidEmail(mail) }));
	}, [mail]);
	const isFormValid = () => {
		return !Object.values(formErrors).some(Boolean) && contrasena.length >= 4;
	};

	const handleInput = async (mail: string, contrasena: string) => {
		const token = await PostLogin(mail, contrasena);
		if (token) {
			dispatch(setCodeJwtState(token));

			router.push("/Inicio");
		}
	};
	const [isClient, setIsClient] = useState(false);

	useEffect(() => {
		setIsClient(true);
	}, []);

	const imagenFondo = {
		boxContainer: isClient
			? {
					backgroundImage: `url(${image.src})`,
					backgroundColor: "black",
					backgroundSize: "cover",
					backgroundPosition: "center",
					backgroundRepeat: "no-repeat",
					position: "fixed",
					height: "100vh",
					width: "100%",
					zIndex: "0",
			  }
			: {},
	};
	return (
		<>
			<Box sx={imagenFondo.boxContainer}>
				<Grid
					xs={12}
					item
					sx={{
						display: "flex",
						height: "80%",
						width: "100%",
						justifyContent: "center",
						alignItems: "center",
					}}
				>
					<Card sx={style.card}>
						<CardContent sx={style.cardBody}>
							<Grid
								display={"flex"}
								alignItems={"center"}
								container
								rowSpacing={1}
								justifyContent={"space-evenly"}
								height={"100%"}
								py={"5%"}
							>
								<Grid
									item
									xs={12}
									height={"30%"}
									display={"flex"}
									flexDirection={"column"}
									alignItems={"center"}
								>
									<Typography sx={style.contactLabel}>{labelCuenta}</Typography>
									<InputContact
										name="mail"
										type="email"
										value={mail}
										onChange={(e) => setMail(e.target.value)}
									/>
								</Grid>
								<Grid
									item
									xs={12}
									height={"30%"}
									display={"flex"}
									flexDirection={"column"}
									alignItems={"center"}
								>
									<Typography sx={style.contactLabel}>
										{labelContraseña}
									</Typography>
									<InputContact
										name="contrasena"
										value={contrasena}
										onChange={(e) => setContrasena(e.target.value)}
										type={showPassword ? "text" : "password"}
										InputProps={{
											endAdornment: (
												<InputAdornment position="end">
													<IconButton
														onClick={() => setShowPassword(!showPassword)}
														edge="end"
													>
														{showPassword ? (
															<VisibilityIcon />
														) : (
															<VisibilityOffIcon />
														)}
													</IconButton>
												</InputAdornment>
											),
										}}
									/>
								</Grid>
								<Grid item xs={12} height={"20%"}>
									<Container sx={style.buttonStyle}>
										<ButtonHome
											onClick={() => handleInput(mail, contrasena)}
											primary
											disabled={!isFormValid()}
										>
											{"Acceder"}
										</ButtonHome>
									</Container>
									<Divider
										sx={{
											width: "80%",
											marginTop: "3%",
											marginBottom: "-2%",
										}}
									/>
									<Link href={"/configuracion/registro"}>
										<Typography
											style={{
												fontStyle: "normal",
												fontSize: "1vw",
												fontFamily: "Poppins",
												textAlign: "center",
												cursor: "pointer",
												marginBottom: "5%",
											}}
										>
											{"¿Aún no tienes un usuario registrado? Registrese aquí."}
										</Typography>
									</Link>
								</Grid>
							</Grid>
						</CardContent>
					</Card>
				</Grid>
			</Box>
			<FooterIn />
		</>
	);
}

BasicModal.defaultProps = {
	labelName: "Nombre",
	labelCuenta: "Cuenta",
	labelContraseña: "Contraseña",
};

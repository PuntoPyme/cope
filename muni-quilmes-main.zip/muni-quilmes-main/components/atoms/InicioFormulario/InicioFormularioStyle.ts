import { colors } from "@/utils";
import { typographies } from "@/utils/styles/tipographies";
import { CSSProperties } from "@mui/styles";
// import "url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap')";
export const style: Record<string, CSSProperties> = {
	buttonStyle: {
		display: "flex",
		justifyContent: "center",
		alignItems: "center",
		width: "40%",
	},
	contactLabel: {
		fontFamily: "Poppins",
		fontSize: "24px",
		fontStyle: "normal",
		fontWeight: "400",
		lineHeight: "29.5px",
		textAlign: "center",
		"@media (max-width: 780px)": {
			fontSize: "1.5rem",
		},
	},
	card: {
		boxSizing: "border-box",
		alignItems: "center !important",
		display: "inline-block !important",
		justifyContent: "center !important",
		borderRadius: "40px !important",
		height: "60%",
		width: "40vw",
		boxShadow: "#00000070 0px 4px 10px !important",
		border: `.1vw solid ${colors.black}`,
		fontFamily: typographies?.allVariants?.fontFamily?.split(",")[0],
	},
	cardBody: {
		width: "100%",
		height: "100%",
		alignItems: "center !important",
		justifyContent: "spece-bewtwen !important",
		background: colors.grey.cards,
		p: "0vw !important",
	},
	headerImage: {
		width: "100%",
		height: "150vh",
		position: "fixed",
		"@media (maxWidth: 780px)": {
			width: "50%",
			height: "100vh",
		},
	},
};

import React, { useRef, useState } from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import Button from "@mui/material/Button";
import { ButtonHome } from "../Button/Button-home/ButtonHome";
import Link from "@mui/material/Link";
import MenuIcon from "@mui/icons-material/Menu";
import {
	Drawer,
	Grid,
	IconButton,
	List,
	ListItem,
	ListItemText,
	Menu,
} from "@mui/material";

export interface INavbarLandingPageProps {}

const pages = [
	{ title: "¿Que es SGC?", id: "queEsSGC" },
	{ title: "Testimonios", id: "testimonios" },
	{ title: "Contacto", id: "contacto" },
];
function NavbarLandingPage() {
	const [open, setOpen] = useState(false);
	const toggleDrawer =
		(openState: boolean) =>
		(event: React.KeyboardEvent | React.MouseEvent): void => {
			if (
				event.type === "keydown" &&
				((event as React.KeyboardEvent).key === "Tab" ||
					(event as React.KeyboardEvent).key === "Shift")
			) {
				return;
			}
			setOpen(openState);
		};

	const list = (
		<Box
			sx={{ width: 250 }}
			role="presentation"
			onClick={toggleDrawer(false)}
			onKeyDown={toggleDrawer(false)}
		>
			<List>
				{pages.map(({ title, id }) => (
					<ListItem key={id}>
						{/* Link debe envolver una etiqueta 'a' */}
						<Link href={`#${id}`} sx={{ color: "black" }}>
							<a style={{ textDecoration: "none", color: "inherit" }}>
								<ListItemText primary={title} />
							</a>
						</Link>
					</ListItem>
				))}
			</List>
		</Box>
	);
	return (
		<AppBar
			sx={{
				background: "white",
				boxShadow: "none",
			}}
		>
			<Toolbar disableGutters>
				<Grid container>
					<Grid
						item
						display={"flex"}
						alignItems={"center"}
						justifyContent={"center"}
						xs={2}
						sx={{ display: { xs: "flex", md: "none" } }}
					>
						<IconButton
							size="large"
							edge="start"
							color="inherit"
							aria-label="menu"
							sx={{ color: "black" }}
							onClick={toggleDrawer(true)}
						>
							<MenuIcon />
						</IconButton>
						<Drawer anchor="left" open={open} onClose={toggleDrawer(false)}>
							{list}
						</Drawer>
					</Grid>

					<Grid
						item
						alignItems={"center"}
						display={"flex"}
						justifyContent={"flex-start"}
						xs={3}
						md={6}
						sx={{
							display: { xs: "none", md: "flex" },
							gap: "2vw",
						}}
					>
						{pages.map(({ title, id }) => (
							<Link href={`#${id}`} underline="none">
								<Typography
									sx={{
										ml: 7,
										my: 2,
										color: "black",
										display: "block",
										fontFamily: "poppins",
										textDecoration: "none !important",
										textTransform: "none",
										fontSize: "1.5vw",
										"@media (min-width: 900px) and (max-width: 1100px)": {
											fontSize: "px",
										},
									}}
								>
									{title}
								</Typography>
							</Link>
						))}
					</Grid>
					<Grid item xs={4} md={3} display={"flex"} alignItems={"right"} ml={35}>
						<Box
							padding={"5%"}
							display={"flex"}
							alignItems={"center"}
							justifyContent={"flex-start"} // Cambiado a flex-start para alinear a la izquierda
							sx={{
								gap: "1vw",
								paddingRight: { xs: "1%" },
								height: { xs: "60% !important", sm: "100%" },
								width: "110% !important",
							}}
						>
							<ButtonHome link={"/configuracion/inicio"}>{"Inicio"}</ButtonHome>
							<ButtonHome link={"/configuracion/registro"} primary>
								{"Crear Cuenta"}
							</ButtonHome>
						</Box>
					</Grid>
				</Grid>
			</Toolbar>
		</AppBar>
	);
}
export default NavbarLandingPage;

import { Box, Typography, Fade, Icon } from "@mui/material";
import React from "react";

import { styles } from "./styles";

export interface IToastIconProps {
	label: string;
	icon: React.ReactNode;
	visible: boolean;
}

const ToastIcon: React.FC<IToastIconProps> = ({ label, icon, visible }) => {
	return (
		<>
			<Fade in={visible} timeout={500}>
				<Box sx={styles.containerComponent}>
					<Box sx={styles.boxIcon}>
						<Icon sx={styles.icon}>{icon}</Icon>
					</Box>
					<Box sx={styles.boxlabel}>
						<Typography
							/* variant='onboardingDialog'
							 */ color={"white"}
							sx={{ fontWeight: 700 }}
						>
							{label}
						</Typography>
					</Box>
				</Box>
			</Fade>
		</>
	);
};

export default ToastIcon;

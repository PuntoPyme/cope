import { Box, Grid } from "@mui/material";
import { FC, ReactNode } from "react";
import { style } from "./HeaderStyle";
interface headerProps {
	children: ReactNode;
	children2?: ReactNode;
	background: boolean;
}

const Header: FC<headerProps> = ({ children, children2, background }) => {
	return (
		<Grid
			container
			sx={
				background
					? { ...style.boxStyle2, background: "white" }
					: style.boxStyle2
			}
		>
			<Grid item xs={6}>
				{children}
			</Grid>
			<Grid item xs={6} justifyContent={"flex-end"}>
				{children2}
			</Grid>
		</Grid>
	);
};
export default Header;

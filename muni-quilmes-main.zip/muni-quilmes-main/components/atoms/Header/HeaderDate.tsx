import { Box, Typography } from "@mui/material";
import { FC, useEffect, useState } from "react";
import DateInput from "../Inputs/InputDate/DateInput";
import { addDays, addYears } from "date-fns";

interface headerProps {
	onPeriodoChange: (periodo: {
		desde: Date | null;
		hasta: Date | null;
	}) => void;
}
const HeaderDate: FC<headerProps> = ({ onPeriodoChange }) => {
	const [dateState, setDateState] = useState<{
		desde: Date | null;
		hasta: Date | null;
	}>({
		desde: null,
		hasta: null,
	});
	const handleDateChange = (name: string, value: Date | null) => {
		setDateState((prevState) => ({
			...prevState,
			[name]: value,
		}));
	};
	useEffect(() => {
		if (dateState.desde !== null && dateState.hasta !== null) {
			onPeriodoChange(dateState);
		}
	}, [dateState]);

	return (
		<Box
			sx={{
				height: "5vw",
				width: "100%",
				display: "flex",
				alignItems: "center",

				gap: "2vw",
				".MuiFormControl-root": {
					".MuiInputBase-root": {
						background: "white",
						borderRadius: "30px",
						height: "3vw",
					},
				},
				".MuiTypography-root": {
					fontFamily: "Poppins, sans-serif",
				},
			}}
		>
			<Typography fontSize={"1.5rem"}>Filtros</Typography>
			<Typography>Desde:</Typography>
			<DateInput
				isRounded={true}
				name="desde"
				value={dateState.desde}
				onChange={(value) => handleDateChange("desde", value)}
			></DateInput>
			<Typography>Hasta:</Typography>
			<DateInput
				disabled={dateState.desde === null}
				minDate={
					dateState.desde !== null
						? addDays(dateState.desde, 1)
						: addYears(new Date(), 2)
				}
				isRounded={true}
				name="hasta"
				value={dateState.hasta}
				onChange={(value) => handleDateChange("hasta", value)}
			></DateInput>
		</Box>
	);
};
export default HeaderDate;

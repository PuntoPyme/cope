import { CSSProperties } from "@mui/styles";
export const style: Record<string, CSSProperties> = {
	boxStyle2: {
		width: "100vw",
		height: "4rem",
		boxShadow: "0px 4px 4px 0px rgba(0, 0, 0, 0.25)",
		display: "flex",
		alignItems: "center",
		justifyContent: "flex-start",
		pl: "3%",
		pr: "3%",
		".MuiGrid-item": {
			display: "flex",
			alignItems: "center",
			height: "100%",
			padding: "0 !important",
		},
		".MuiTypography-root": {
			fontFamily: "Poppins, sans-serif",
		},
	},
};

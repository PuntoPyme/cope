import * as React from "react";
import { FC } from "react";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import { Link } from "@mui/material";
import ArrowDropUpIcon from "@mui/icons-material/ArrowDropUp";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import { routerPaths } from "@/utils/routerPaths";
import { ButtonNavbar } from "../Button/ButtonMenuNavbar/ButtonNavbar";

interface MenuProps {}
const MenuNavbar: FC<MenuProps> = () => {
	const [anchorEls, setAnchorEls] = React.useState<(HTMLElement | null)[]>(
		Array(routerPaths.length).fill(null)
	);

	const handleClick = (
		event: React.MouseEvent<HTMLButtonElement>,
		index: number
	) => {
		const newAnchorEls = [...anchorEls];
		newAnchorEls[index] = event.currentTarget;
		setAnchorEls(newAnchorEls);
	};

	const handleClose = (index: number) => {
		const newAnchorEls = [...anchorEls];
		newAnchorEls[index] = null;
		setAnchorEls(newAnchorEls);
	};

	const DropdownIcon = ({ index }: { index: number }) => {
		return anchorEls[index] ? <ArrowDropUpIcon /> : <ArrowDropDownIcon />;
	};

	return (
		<>
			{routerPaths.map(({ title, id, icon: Icon, router, subPaths }, index) => {
				if (title !== "Inicio") {
					if (subPaths !== undefined) {
						return (
							<div key={id}>
								<ButtonNavbar
									title={title}
									Icon={Icon}
									onClick={(event) => handleClick(event, index)}
									dropdownIcon={<DropdownIcon index={index} />}
								></ButtonNavbar>
								<Menu
									id={`basic-menu-${id}`}
									anchorEl={anchorEls[index]}
									open={Boolean(anchorEls[index])}
									onClose={() => handleClose(index)}
									MenuListProps={{
										"aria-labelledby": `basic-button-${id}`,
									}}
									sx={{
										".MuiPaper-root": {
											width: "10vw",
											minWidth: "fit-content",
										},
									}}
								>
									{subPaths.map((item, subIndex) => (
										<Link
											key={subIndex}
											href={`/${router}/${item.router}`}
											underline="none"
											color="black"
											style={{ background: "red" }}
										>
											<MenuItem onClick={() => handleClose(index)}>
												{item.title}
											</MenuItem>
										</Link>
									))}
								</Menu>
							</div>
						);
					} else {
						return (
							<Link href={`/${router}`} key={id}>
								<ButtonNavbar onClick={() => {}} title={title} Icon={Icon} />
							</Link>
						);
					}
				}
				return null;
			})}
		</>
	);
};

export default MenuNavbar;

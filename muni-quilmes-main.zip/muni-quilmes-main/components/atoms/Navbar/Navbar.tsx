import React, { useEffect, useRef, useState } from "react";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Image from "next/image";
import { Box, Container, Grid, Typography } from "@mui/material";
import { useRouter } from "next/router";
import MenuNavbar from "./MenuNavbar";
import logoText from "../../../assets/sistema-gestion-contable.png";
import MenuConfig from "./MenuConfig";
interface NavbarProps {}

function Navbar({}: NavbarProps) {
	const router = useRouter();
	const currentPath = router.pathname.substring(1).split("/")[0];
	return (
		<AppBar
			sx={{
				height: "6rem",
				background: "#7A61A1",
				margin: "0 !important",
				padding: "0 !important",
			}}
		>
			<Toolbar disableGutters>
				<Grid
					container
					display="flex"
					alignItems="center"
					height={"6vw"}
					sx={{
						marginLeft: "3%",
						marginRight: "3%",
					}}
				>
					<Grid item xs={11}>
						<Box
							sx={{
								display: "flex",
								alignItems: "center",
								width: "100%",
								gap: "1vw",
							}}
						>
							{currentPath !== "Inicio" ? (
								<MenuNavbar />
							) : (
								<>
									<Box sx={{ width: "50%", height: "100%" }}>
										<Image
											src={logoText}
											alt="Sistema de gestión contable"
											style={{ width: "60%", height: "auto" }}
										/>
									</Box>
								</>
							)}
						</Box>
					</Grid>
					<Grid
						item
						xs={1}
						display="flex"
						alignItems="center"
						justifyContent="flex-end"
						sx={{ gap: "2vw" }}
					>
						<MenuConfig />
					</Grid>
				</Grid>
			</Toolbar>
		</AppBar>
	);
}
export default Navbar;

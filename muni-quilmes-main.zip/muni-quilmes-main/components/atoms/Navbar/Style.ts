import { CSSProperties } from "@mui/styles";
export const style: Record<string, CSSProperties> = {
	boxStyle1: {
		width: "100%",
		height: "fit-content",
		padding: "1vw 0",
		background: "transparent",
		boxShadow: "0px 4px 4px 0px rgba(0, 0, 0, 0.25)",
		display: "flex",
		alignItems: "center",
		".MuiTypography-root": {
			fontSize: "1.5vw",
			ml: "4vw",
			fontWeight: "400",
		},
	},
};

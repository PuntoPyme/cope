import { Box, Container } from "@mui/system";
import React, { useEffect, useState } from "react";
import { style } from "./InstructivoStyle";
import BackgroundPage from "../BackgroundApp/BackgroundApp";
import image from "../../../assets/back.jpg";
import { IconButton, Modal, Typography } from "@mui/material";
import imageLogo from "../../../assets/logoquilmes.png";
import Image from "next/image";
import { ButtonClasic } from "../Button/Button-clasic/ButtonClasic";
import { useRouter } from "next/router";
import HomeIcon from "@mui/icons-material/Home";
import PDFInstructivo from "@/components/templates/PDFInstructivo";
import { PDFViewer } from "@react-pdf/renderer";
import CloseIcon from "@/assets/Icons/CloseIcon";
import Link from "next/link";

export interface InstuctivoProps {}

export const InstructivoRegistro: React.FC<InstuctivoProps> = ({}) => {
	const instrucciones = `Para poder acceder al sistema contable-administrativo de ECOSOL La
							Cooperativa deberá estar en el Registro Municipal de Asociativismo
							y de Economía Social (REMAES).<br></br> Para mas información
							contactarse al siguiente CEL:{" "}
							${(<Link href={"tel:+54 9 11 2686-5593"}>+54 9 11 2686-5593</Link>)} o
							<br></br>
							vía e-mail
							${(
								<Link
									href={"mailto:dir.gen.economiasocial@gmail.com"}
									style={{ margin: "0 1%" }}
								>
									dir.gen.economiasocial@gmail.com
								</Link>
							)}
							o presencialmente hacia Punto Pyme / Oficina de Economía Social y
							Acciòn Cooperativa{" "}
							${(
								<Link
									href={
										"https://www.google.com.ar/maps/place/Humberto+Primo+55,+B1878+Quilmes,+Provincia+de+Buenos+Aires/@-34.7257767,-58.2608565,17z/data=!3m1!4b1!4m5!3m4!1s0x95a32e6a0684ac3b:0xc1da196e377dc10!8m2!3d-34.7257811!4d-58.2582816?entry=ttu&g_ep=EgoyMDI0MTAyMy4wIKXMDSoASAFQAw%3D%3D"
									}
								>
									(HUMBERTO PRIMO 55 ESQ. SAN MARTÌN, 1er Piso).
								</Link>
							)}
							Lunes a Viernes de 08:00-14:00hs`;
	const [isPdfVisible, setIsPdfVisible] = useState<boolean>(false);
	const closePdfModal = () => {
		setIsPdfVisible(false);
	};
	const router = useRouter();
	return (
		<>
			<Box sx={style.containerPage}>
				<BackgroundPage backgroundImage={image} />
				<Box sx={style.boxInicio}>
					<IconButton
						onClick={() => {
							router.push("/");
						}}
					>
						<HomeIcon />
					</IconButton>
					<Box>
						<Image src={imageLogo} alt="Imagen" priority={true} height={50} />
					</Box>
				</Box>
				<Box
					width={"fit-content"}
					height={"fit-content"}
					overflow={"hidden"}
					maxHeight={"80vh"}
					marginTop={"2vh"}
					sx={{
						borderRadius: "40px",
					}}
				>
					<Container sx={style.container}>
						<Typography sx={style.text}>
							Para poder acceder al sistema contable-administrativo de ECOSOL La
							Cooperativa deberá estar en el Registro Municipal de Asociativismo
							y de Economía Social (REMAES).<br></br> Para mas información
							contactarse al siguiente CEL:{" "}
							<Link href={"tel:+54 9 11 2686-5593"}>+54 9 11 2686-5593</Link>,
							<br></br>
							vía e-mail
							<Link
								href={"mailto:dir.gen.economiasocial@gmail.com"}
								style={{ margin: "0 1%" }}
							>
								dir.gen.economiasocial@gmail.com
							</Link>
							o presencialmente hacia Punto Pyme / Oficina de Economía Social y
							Acciòn Cooperativa{" "}
							<Link
								href={
									"https://www.google.com.ar/maps/place/Humberto+Primo+55,+B1878+Quilmes,+Provincia+de+Buenos+Aires/@-34.7257767,-58.2608565,17z/data=!3m1!4b1!4m5!3m4!1s0x95a32e6a0684ac3b:0xc1da196e377dc10!8m2!3d-34.7257811!4d-58.2582816?entry=ttu&g_ep=EgoyMDI0MTAyMy4wIKXMDSoASAFQAw%3D%3D"
								}
							>
								(HUMBERTO PRIMO 55 ESQ. SAN MARTÌN, 1er Piso)
							</Link>
							. Lunes a Viernes de 08:00-14:00hs
						</Typography>
						<Box sx={style.box}>
							<ButtonClasic
								primary={true}
								onClick={() => {
									setIsPdfVisible(true);
								}}
							>
								Descargar instructivo
							</ButtonClasic>
							<Typography>Si ya estas registrado inicia sesión</Typography>
							<ButtonClasic
								primary={false}
								onClick={() => {
									router.push("/configuracion/inicio");
								}}
							>
								Iniciar sesión
							</ButtonClasic>
						</Box>
					</Container>
				</Box>
			</Box>
			<Modal
				open={isPdfVisible}
				onClose={closePdfModal}
				aria-labelledby="pdf-modal-title"
				aria-describedby="pdf-modal-description"
			>
				<Box
					style={{
						display: "flex",
						justifyContent: "center",
						height: "100%",
						alignItems: "center",
					}}
				>
					<Box
						sx={{
							borderRadius: "50% !important",
							position: "absolute",
							top: "5vh",
							right: "15%",
							".MuiButtonBase-root": {
								border: "2px solid white",
								"&:hover": {
									boxShadow: " 5px 5px #ffffff90",
								},
							},
						}}
					>
						<IconButton onClick={closePdfModal} sx={{ color: "white" }}>
							<CloseIcon />
						</IconButton>
					</Box>
					<PDFViewer width="50%" height="90%">
						<PDFInstructivo instrucciones={instrucciones} />
					</PDFViewer>
				</Box>
			</Modal>
		</>
	);
};

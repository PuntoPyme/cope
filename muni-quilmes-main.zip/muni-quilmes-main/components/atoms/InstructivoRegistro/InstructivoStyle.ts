import { CSSProperties } from "@mui/styles";
export const style: Record<string, CSSProperties> = {
	boxInicio: {
		position: "absolute",
		left: "2vw",
		top: "2vh",
		display: "flex",
		alignItems: "center",
		gap: "1vh",
		".MuiSvgIcon-root": {
			color: "white",
			width: "3vw !important",
			height: "unset",
			borderRadius: "5px !important",
		},
	},
	containerPage: {
		width: "100vw !important",
		margin: "0 !important",
		display: "flex",
		height: "100vh",
		alignItems: "center",
		justifyContent: "center",
		flexDirection: "column",
	},
	container: {
		height: "fit-content",
		maxHeight: "80vh",
		borderRadius: "40px",
		display: "flex",
		alignItems: "center",
		flexDirection: "column",
		padding: "2% !important",
		justifyContent: "center",
		background: "#ffffff90",

		gap: "2vh",
		overflowY: "auto",
		"&::-webkit-scrollbar": {
			width: "8px",
			backgroundColor: "transparent",
		},
		"&::-webkit-scrollbar-thumb": {
			backgroundColor: "#7A61A1",
			borderRadius: "4px",
		},
	},
	text: {
		height: "fit-content",
		width: "100%",
		fontSize: "1.5vw",
		textAlign: "center",
	},
	box: {
		width: "50%",
		display: "flex",
		alignItems: "center",
		flexDirection: "column",
		gap: "2vh",
		".MuiTypography-root": {
			color: "black",
			textAlign: "center",
		},
	},
};

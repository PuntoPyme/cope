export const style = {
	boxIcon: {
		with: "40px",
		height: "40px",
		background: "black",
		borderRadius: "50%",
	},
	card: {
		boxShadow: "0px 4px 20px rgba(0, 0, 0, 0.2)", // Agrega sombra
		transition: "transform 0.3s ease, box-shadow 0.3s ease", // Transición suave
		"&:hover": {
			transform: "translateY(-10px)", // Levanta el elemento 10px
			boxShadow: "0px 4px 20px rgba(0, 0, 0, 0.6)", // Agrega sombra
		},
		width: "60%",
		height: "100%",
		color: "#7A61A1",
		borderRadius: "20px",
		padding: "0% !important",
		".MuiGrid-item": {
			display: "flex",
			justifyContent: "center",
		},
		"@media (min-width: 1200px) and (max-width:2400px)": {
			width: "90%",
		},
	},

	h2: {
		color: "#7A61A1",
		textAlign: "center",
		fontFamily: "Poppins",
		fontSize: "16px",
		fontStyle: "normal",
		fontHeight: "500",
		lineHeight: "29.5px",
		mt: "5%",
	},
};

import React, { FC, useEffect, useState } from "react";
import { Grid, Typography, IconButton, Box, Alert } from "@mui/material";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import AddIcon from "@mui/icons-material/Add";
import { v4 as uuidv4 } from "uuid";
import TextInput from "@/components/atoms/Inputs/TextInput/TextInput";
import { ButtonClasic } from "@/components/atoms/Button/Button-clasic/ButtonClasic";
import { CSSProperties } from "@mui/styled-engine-sc";
import { fetchGetRequest, fetchPostRequest } from "@/utils/ApiRequest";
import { useSelector } from "react-redux";
import { RootState } from "@/Redux/store";
import { accountForJournal } from "@/types";
import { useDispatch } from "react-redux";
import { setAccountJournal } from "@/Redux/features/AccountForBook";
import { responseAccountJournal } from "@/utils/Functions/ValidationInputs";
import NumberInput from "@/components/atoms/Inputs/NumberInputCultivo/NumberInput";

interface CreateAccountProps {
	onClickCancelar?: () => void;
}
// Tipo para el estado de validación
interface ValidationState {
	[key: string]: boolean;
}

interface RowState extends accountForJournal {
	id: string | number;
}

export const CreateAccount: FC<CreateAccountProps> = ({ onClickCancelar }) => {
	const { codejwt } = useSelector((state: RootState) => state.storeJwt);
	const account = useSelector(
		(state: RootState) => state.accountJournal.account
	);
	const dispatch = useDispatch();

	const [alert, setAlert] = useState<boolean>(false);
	const [alertText, setAlertText] = useState<string>("");
	const [rows, setRows] = useState<RowState[]>([
		{
			id: uuidv4(),
			name: "",
			code: 0,
		},
	]);

	// Estado independiente para manejar la validación
	const [validationState, setValidationState] = useState<ValidationState>({});

	const handleDeleteRow = (id: string) => {
		if (rows.length > 1) {
			setRows(rows.filter((row) => row.id !== id));
			setValidationState((prevState) => {
				const newState = { ...prevState };
				delete newState[id];
				return newState;
			});
		}
	};

	const handleRowChange = (
		id: string,
		field: keyof accountForJournal,
		value: string | number
	) => {
		setRows((prevRows) =>
			prevRows.map((row) => (row.id === id ? { ...row, [field]: value } : row))
		);

		validateRow(id, field, value);
	};

	const handleAddRow = () => {
		const newId = uuidv4();
		setRows([...rows, { id: newId, name: "", code: 0 }]);
		setValidationState((prevState) => ({ ...prevState, [newId]: false }));
	};

	// Función que realiza la validación de una fila en particular
	const validateRow = (
		id: string,
		field: keyof accountForJournal,
		value: string | number
	) => {
		const row = rows.find((row) => row.id === id);

		if (row) {
			const nameToValidate = field === "name" ? value.toString() : row.name;
			const codeToValidate = field === "code" ? value : row.code;
			
			// Validar si ambos tienen al menos 2 caracteres
			if (
				nameToValidate.trim().length >= 2 &&
				codeToValidate.toString().length >= 2
			) {
				const isDuplicate = account.some(
					(acc) => acc.name === nameToValidate || acc.code === codeToValidate
				);
				
				// Actualizar estado de validación
				setValidationState((prevState) => ({
					...prevState,
					[id]: isDuplicate, // Es válido si no hay duplicado
				}));
			} else {
				setValidationState((prevState) => ({
					...prevState,
					[id]: false, // No es válido si no cumple el mínimo de caracteres
				}));
			}
		}
	};

	const handleSave = () => {
		const dataToSend: accountForJournal[] = rows
			.filter((row) => !validationState[row.id.toString()])
			.map(({ name, code }) => ({
				name: name.trim(),
				code: code,
				id: 0,
			}));
		if (dataToSend.length < 1) {
			setAlert(true);
			setAlertText("Complete mínimo una cuenta válida para cargar");
		} else {
			fetchPostRequest("/accountant/accounts/create", dataToSend, codejwt).then(
				(data) => {
					if (data.status !== 200) {
						setAlertText(
							"No se pudo cargar la cuenta, revise tener valores válidos o intentelo más tarde"
						);
						setAlert(true);
					} else {
						fetchGetRequest("/accountant/accounts/company", codejwt).then(
							(data) => {
								if (responseAccountJournal(data)) {
									dispatch(setAccountJournal(data.accounts));
									if (onClickCancelar) onClickCancelar();
								}
							}
						);
					}
				}
			);
		}
	};
	return (
		<Grid container width="50vw" minHeight="20vh" paddingY="2%">
			<Grid item xs={12} sx={style.alinear}>
				<Typography variant="h4">Cargar cuentas</Typography>
			</Grid>
			<Grid item xs={5.5} sx={style.alinear}>
				<Typography variant="h6">Nombre</Typography>
			</Grid>
			<Grid item xs={6.5} sx={style.alinear}>
				<Typography variant="h6">Código</Typography>
			</Grid>
			{rows.map((row) => (
				<Grid container key={row.id} marginY="2vh" sx={style.alinear}>
					<Grid item xs={6} sx={style.alinear}>
						<TextInput
							enabled
							onChange={(e) =>
								handleRowChange(row.id.toString(), "name", e.target.value)
							}
							value={row.name}
						/>
					</Grid>
					<Grid item xs={6} sx={style.alinear}>
						<NumberInput
							enabled
							onChange={(e) =>
								handleRowChange(row.id.toString(), "code", e.target.value)
							}
							value={row.code}
						/>
						<IconButton
							sx={{
								background: "red",
								color: "white",
								marginLeft: "4%",
								"&:hover": {
									background: "white",
									color: "red",
								},
							}}
							onClick={() => handleDeleteRow(row.id.toString())}
						>
							<DeleteOutlineIcon />
						</IconButton>
					</Grid>
					{validationState[row.id.toString()] && (
						<Typography color="red" variant="body2">
							El nombre o el código ya existen o son inválidos.
						</Typography>
					)}
				</Grid>
			))}
			<Grid item xs={12} display="flex" justifyContent="center">
				<Box sx={style.alinear} gap="2vh" width="80%" flexDirection={"column"}>
					<IconButton
						sx={{
							background: "green",
							color: "white",
							"&:hover": {
								background: "white",
								color: "green",
							},
						}}
						onClick={handleAddRow}
					>
						<AddIcon />
					</IconButton>
					<Box sx={style.alinear} width="100%" gap="2vw">
						<ButtonClasic
							primary={false}
							onClick={() => {
								if (onClickCancelar) onClickCancelar();
							}}
						>
							Cancelar
						</ButtonClasic>{" "}
						<ButtonClasic primary onClick={handleSave}>
							Guardar
						</ButtonClasic>
					</Box>
					{alert && (
						<Typography textAlign={"center"} color={"red"}>
							{alertText}
						</Typography>
					)}
				</Box>
			</Grid>
		</Grid>
	);
};

const style: Record<string, CSSProperties> = {
	alinear: {
		display: "flex",
		justifyContent: "center",
		alignItems: "center",
	},
};

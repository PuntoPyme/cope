import { Box, Grid } from "@mui/material";
import React, { useEffect, useState } from "react";
import Header from "@/components/atoms/Header/Header";
import HeaderDate from "@/components/atoms/Header/HeaderDate";
import { ButtonClasic } from "@/components/atoms/Button/Button-clasic/ButtonClasic";
import BuscadorAtom from "@/components/atoms/Buscador/Buscador";
import { ModalComponent } from "@/components/atoms/Modal/ModalAtom";
import { CreateAccount } from "../CrearCuenta/CrearCuenta";
import { ButtonActions } from "@/components/atoms/ButtonActions/ButtonActions";
import LibroDiario from "@/components/atoms/TABLAS/Libros/LibroDiario";
import { JournalEntryResponse } from "@/types";
import { RootState } from "@/Redux/store";
import { useSelector } from "react-redux";
import { fetchGetRequest } from "@/utils/ApiRequest";
import { responseJournalEntryArray } from "@/utils/Functions/ValidationInputs";

const LibroDiarioTemplate = () => {
	const [openModal, setOpenModal] = useState<boolean>(false);
	const [resultadoAccion, setResultadoAccion] = useState<string>("");

	const [periodo, setPeriodo] = useState<{
		desde: Date | null;
		hasta: Date | null;
	}>({
		desde: null,
		hasta: null,
	});

	const [journalData, setJournalData] = useState<
		JournalEntryResponse[] | undefined
	>();
	const { codejwt } = useSelector((state: RootState) => state.storeJwt);

	function fetchJournalEntries() {
		fetchGetRequest("/accountant/journal-entries/get", codejwt).then((data) => {
			if (responseJournalEntryArray(data)) {
				setJournalData(data); // Solo guarda datos si son válidos
			}
		});
	}

	useEffect(() => {
		fetchJournalEntries();
	}, []);

	const [resultadoBusqueda, setResultadoBusqueda] = useState<string>("");

	const handlePeriodoChange = (newPeriodo: {
		desde: Date | null;
		hasta: Date | null;
	}) => {
		setPeriodo(newPeriodo);
	};

	const handleBusqueda = (valor: string): string => {
		setResultadoBusqueda(valor);
		return valor;
	};

	function handleClickVerTodo() {
		setPeriodo({ desde: null, hasta: null });
		setResultadoBusqueda("");
	}
	useEffect(() => {
		const changeResult = () => {
			if (resultadoAccion === "Imprimir" || resultadoAccion === "Eliminar") {
				setResultadoAccion("");
			}
		};
		changeResult();
	}, [resultadoAccion]);
	return (
		<>
			<Header
				background={false}
				children={<HeaderDate onPeriodoChange={handlePeriodoChange} />}
				children2={
					<BuscadorAtom result={handleBusqueda} value={resultadoBusqueda} />
				}
			/>
			<Header
				background={true}
				children2={
					<Box width={"30%"}>
						<ButtonClasic
							primary
							children="Limpiar filtros"
							onClick={() => {
								handleClickVerTodo();
							}}
						/>
					</Box>
				}
				children={
					<Box width={"30%"}>
						<ButtonActions
							acciones={["Imprimir", "Eliminar"]}
							onActionSelect={(event) => {
								setResultadoAccion(event);
							}}
						>
							Acciones
						</ButtonActions>
					</Box>
				}
			/>
			<Box
				sx={{
					display: "flex",
					alignItems: "center",
					justifyContent: "center",
					my: "2vw",
					width: "80%",
				}}
			>
				<ButtonClasic
					primary={false}
					onClick={() => {
						setOpenModal(true);
					}}
				>
					Crear cuentas
				</ButtonClasic>
			</Box>
			<Grid
				container
				display={"flex"}
				justifyContent={"center"}
				sx={{ pb: "5%" }}
			>
				<Grid item xs={11.5}>
					<LibroDiario
						periodo={periodo}
						journalEntries={journalData}
						resultadoBusqueda={resultadoBusqueda}
						resultadoAccion={resultadoAccion}
					/>
				</Grid>
			</Grid>

			<ModalComponent openProp={openModal}>
				<CreateAccount
					onClickCancelar={() => {
						setOpenModal(false);
					}}
				/>
			</ModalComponent>
		</>
	);
};

export default LibroDiarioTemplate;

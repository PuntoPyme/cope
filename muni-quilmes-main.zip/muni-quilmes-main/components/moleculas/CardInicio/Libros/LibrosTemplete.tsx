import {
	Box,
	Button,
	Grid,
	IconButton,
	Modal,
	TextField,
	Typography,
} from "@mui/material";
import React, { useEffect, useRef, useState, FC, ReactNode } from "react";
import Header from "@/components/atoms/Header/Header";
import { style } from "./Style";
import HeaderDate from "@/components/atoms/Header/HeaderDate";
import { ButtonClasic } from "@/components/atoms/Button/Button-clasic/ButtonClasic";
import LocalPrintshopIcon from "@mui/icons-material/LocalPrintshop";
import BuscadorAtom from "@/components/atoms/Buscador/Buscador";
import { PDFViewer } from "@react-pdf/renderer";
import PDFSalesReport from "@/components/templates/SalesInvoice";
import CloseIcon from "@/assets/Icons/CloseIcon";
import { colors } from "@/utils";
import PDFPurchaseInvoiceIVA from "@/components/templates/SalesInvoiceCompra";

interface librosTemplate {
	libro: ReactNode;
	totalComponente?: ReactNode;
	dataForPrint: { totals: any; salesInvoice: any };
	title: string;
}
const LibrosTemplate: FC<librosTemplate> = ({
	libro,
	totalComponente,
	dataForPrint,
	title,
}) => {
	const [isPdfVisible, setIsPdfVisible] = useState<boolean>(false);
	const [resultadoAccion, setResultadoAccion] = useState<string>("");
	const [periodo, setPeriodo] = useState<{
		desde: Date | null;
		hasta: Date | null;
	}>({
		desde: null,
		hasta: null,
	});
	const [resultadoBusqueda, setResultadoBusqueda] = useState<string>("");

	const handlePeriodoChange = (newPeriodo: {
		desde: Date | null;
		hasta: Date | null;
	}) => {
		setPeriodo(newPeriodo);
	};

	const handleBusqueda = (valor: string): string => {
		setResultadoBusqueda(valor); // Guarda el valor en el estado
		return valor;
	};
	useEffect(() => {
		const changeResult = () => {
			if (resultadoAccion === "Imprimir" || resultadoAccion === "Eliminar") {
				setResultadoAccion("");
			}
		};
		changeResult();
	}, [resultadoAccion]);
	function handleClickVerTodo() {
		setPeriodo({ desde: null, hasta: null });
		setResultadoBusqueda("");
	}
	const closePdfModal = () => {
		setIsPdfVisible(false);
	};
	return (
		<>
			<Header
				background={false}
				children={<HeaderDate onPeriodoChange={handlePeriodoChange} />}
				children2={
					<BuscadorAtom result={handleBusqueda} value={resultadoBusqueda} />
				}
			/>
			<Header
				background={true}
				children2={
					<Box width={"30%"}>
						<ButtonClasic
							primary
							children="Limpiar filtros"
							onClick={() => {
								handleClickVerTodo();
							}}
						/>
					</Box>
				}
				children={
					<>
						<Box width={"30%"} display={"flex"}>
							<ButtonClasic
								primary={true}
								onClick={() => {
									setIsPdfVisible(true);
								}}
							>
								<LocalPrintshopIcon sx={{ marginRight: "10%" }} />
								Imprimir
							</ButtonClasic>
						</Box>
					</>
				}
			/>
			<Modal
				open={isPdfVisible}
				onClose={closePdfModal}
				aria-labelledby="pdf-modal-title"
				aria-describedby="pdf-modal-description"
			>
				<Box
					style={{
						display: "flex",
						justifyContent: "center",
						height: "100%",
						alignItems: "center",
					}}
				>
					<Box
						sx={{
							borderRadius: "50% !important",
							position: "absolute",
							top: "5vh",
							right: "15%",
							".MuiButtonBase-root": {
								border: "2px solid white",
								"&:hover": {
									boxShadow: " 5px 5px #ffffff90",
								},
							},
						}}
					>
						<IconButton onClick={closePdfModal} sx={{ color: "white" }}>
							<CloseIcon />
						</IconButton>
					</Box>
					<PDFViewer width="50%" height="90%">
						{title === "ventas" ? (
							<PDFSalesReport
								type={title === "ventas" ? "sales" : "purchase"}
								
								totals={dataForPrint.totals}
							/>
						) : (
							<PDFPurchaseInvoiceIVA
								type={title === "ventas" ? "sales" : "purchase"}
								totals={dataForPrint.totals}
							/>
						)}
					</PDFViewer>
				</Box>
			</Modal>
			<Grid container display={"flex"} justifyContent={"center"} py={"2%"}>
				<Grid item xs={11}>
					<Typography
						width={"100%"}
						variant="h4"
						fontFamily={"Poppins"}
						textAlign={"center"}
						marginY={"2vh"}
						color={colors.violet.gradient2}
					>
						Libro de IVA {title}
					</Typography>
				</Grid>
				<Grid item xs={11.5}>
					{React.cloneElement(libro as React.ReactElement<any>, {
						resultadoBusqueda,
						periodo,
					})}
				</Grid>
				<Grid item xs={11.5}>
					{totalComponente}
				</Grid>
			</Grid>
		</>
	);
};

export default LibrosTemplate;

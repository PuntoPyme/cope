import { CSSProperties } from "@mui/styles";
export const style: Record<string, CSSProperties> = {
	boxChildren: {
		background: "white",
		height: "fit-content",
		width: "100%",
		display: "flex",
		alignItems: "flex-start ",
		paddingTop: "2vw",
		paddingBottom: "2vw",
	},
};

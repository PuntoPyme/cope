import { ButtonClasic } from "@/components/atoms/Button/Button-clasic/ButtonClasic";
import { Box, Grid } from "@mui/material";

interface ButtonGroups {
	clickGuardar: () => void;
	clickCancelar: () => void;
	disabled?: boolean;
}
const GroupButtons: React.FC<ButtonGroups> = ({
	clickGuardar,
	clickCancelar,
	disabled
}) => {
	const style = {
		buttonsEnd: {
			".MuiGrid-item": {
				display: "flex",
				justifyContent: "flex-end",
			},
		},
	};
	return (
		<Grid
			sx={style.buttonsEnd}
			container
			justifyContent="flex-end"
			alignItems="center"
			gap={"1vw"}
		>
			<Grid item xs={2}>
				<ButtonClasic
					primary={false}
					onClick={() => {
						clickCancelar();
					}}
				>
					Cancelar
				</ButtonClasic>
			</Grid>
			<Grid item xs={2}>
				<ButtonClasic
					disabled={disabled}
					primary={true}
					onClick={() => {
						clickGuardar();
					}}
				>
					Guardar
				</ButtonClasic>
			</Grid>
		</Grid>
	);
};

export default GroupButtons;

import * as React from "react";
import { FC } from "react";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import { Box, Grid, IconButton, SvgIconProps } from "@mui/material";
import { style } from "./CardInicioStyle";
import router from "next/router";
import { ButtonClasic } from "@/components/atoms/Button/Button-clasic/ButtonClasic";

interface cardInicioProps {
	title: string;
	routerVer: string;
	routerNuevo?: string;
	icon: React.ComponentType<SvgIconProps>;
}
const CardInicio: FC<cardInicioProps> = ({
	title,
	routerNuevo,
	routerVer,
	icon: IconComponent,
}) => {
	
	return (
		<Card sx={style.card}>
			<CardContent>
				<Grid container direction="column" alignItems="center">
					<Box sx={style.boxIcon}>
						<IconButton>
							<IconComponent sx={{ color: "white" }} />
						</IconButton>
					</Box>
					<Typography sx={style.h2}>{title}</Typography>
				</Grid>
			</CardContent>
			<CardActions sx={{ marginBottom: "1vh" }}>
				<Grid container justifyContent="center" alignItems="center">
					<Grid item xs={routerNuevo ? 6 : 12}>
						<ButtonClasic
							primary={false}
							onClick={() => router.push(routerVer)}
						>
							{routerVer.split("/")[1] || "Ver"}
						</ButtonClasic>
					</Grid>
					{routerNuevo && (
						<Grid item xs={6}>
							<ButtonClasic
								primary={false}
								onClick={() => router.push(routerNuevo)}
							>
								{routerNuevo.split("/")[1]}
							</ButtonClasic>
						</Grid>
					)}
				</Grid>
			</CardActions>
		</Card>
	);
};
export default CardInicio;

import { Box, Modal } from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import TablaComprobante from "@/components/atoms/TABLAS/PersonaVerTabla/PersonaTabla";
import { ButtonIcon } from "@/components/atoms/Button/Button-icon/ButtonIcon";
import Header from "@/components/atoms/Header/Header";
import { ButtonActions } from "@/components/atoms/ButtonActions/ButtonActions";
import ClienteNuevo from "../clienteNuevo";
import BuscadorAtom from "@/components/atoms/Buscador/Buscador";
import { ModalComponent } from "@/components/atoms/Modal/ModalAtom";
import { fetchGetRequest } from "@/utils/ApiRequest";
import { useSelector } from "react-redux";
import { RootState } from "@/Redux/store";
import { isValidEntityArray } from "@/utils/Functions/ValidationInputs";
import { clienteProveedorVer } from "@/types";
import { setClientes } from "@/Redux/features/ClientesArrayStore";
import { useDispatch } from "react-redux";

const ClienteVer = () => {
	const [open, setOpen] = useState(false);
	const [resultadoAccion, setResultadoAccion] = useState<string>("");
	const { codejwt } = useSelector((state: RootState) => state.storeJwt);
	const [resultadoBusqueda, setResultadoBusqueda] = useState<string>("");
	const [dataForComponent, setDataForComponent] = useState<
		clienteProveedorVer[]
	>([]);
	const dispatch = useDispatch();
	const handleBusqueda = (valor: string): string => {
		setResultadoBusqueda(valor); // Guarda el valor en el estado
		return valor; // O cualquier operación que desees realizar
	};
	useEffect(() => {
		const changeResult = () => {
			if (resultadoAccion === "Imprimir" || resultadoAccion === "Eliminar") {
				setResultadoAccion("");
			}
		};
		changeResult();
	}, [resultadoAccion]);

	const handleOpenModal = () => {
		setOpen(true);
	};

	function getPersons() {
		fetchGetRequest("/api/customers/by-company-id", codejwt).then(
			(data: unknown) => {
				if (isValidEntityArray(data)) {
					if (data) {
						setDataForComponent(data);
						dispatch(setClientes(data));
					}
				} else {
					setDataForComponent([]);
				}
			}
		);
	}
	useEffect(() => {
		getPersons();
	}, [codejwt]);
	return (
		<>
			<Header
				background={false}
				children={
					<>
						<Box width={"30%"}>
							<ButtonIcon onClick={handleOpenModal}>Nueva Ventana</ButtonIcon>
						</Box>
						<Box width={"30%"}>
							<ButtonActions
								acciones={["Imprimir", "Eliminar"]}
								onActionSelect={(event) => {
									setResultadoAccion(event);
								}}
							>
								Acciones
							</ButtonActions>
						</Box>
					</>
				}
				children2={
					<BuscadorAtom result={handleBusqueda} value={resultadoBusqueda} />
				}
			/>
			<Box
				sx={{
					height: "100%",
					pt: "5%",
					width: "90%",
					display: "flex",
					justifyContent: "center",
				}}
			>
				<TablaComprobante
					urlDelete="/accountant/customer/update-status"
					resultadoAccion={resultadoAccion}
					resultadoBusqueda={resultadoBusqueda}
					persona="Clientes"
					data={dataForComponent}
					onDeleteComplete={() => getPersons()}
				/>
			</Box>
			<ModalComponent openProp={open}>
				<ClienteNuevo
					onClickCancelar={() => {
						setOpen(false);
						getPersons();
					}}
				/>
			</ModalComponent>
		</>
	);
};

export default ClienteVer;

import React from "react";
import { Box, Grid } from "@mui/material";
import CardInicio from "../../moleculas/CardInicio/CardInicio";
import { routerPaths } from "@/utils/routerPaths";

const CardGrid = () => {
	return (
		<>
			<Box sx={{ width: "90vw" }}>
				<Grid
					container
					rowSpacing={10}
					sx={{
						display: "flex",
						alignItems: "center",
						justifyContent: "center",
					}}
				>
					{routerPaths.map(
						(paths, index) =>
							paths.router !== "/Inicio" &&
							paths.router !== "Asientos" && (
								<Grid
									item
									xs={12}
									md={5}
									lg={3}
									key={paths.id}
									sx={{
										display: "flex",
										alignItems: "center",
										justifyContent: "center",
									}}
								>
									<CardInicio
										title={paths.title}
										routerNuevo={
											paths.subPaths
												? `${paths.router}${paths.subPaths[1].router}`
												: undefined
										}
										routerVer={
											paths.subPaths && paths.subPaths[1]
												? `${paths.router}${paths.subPaths[0].router}`
												: paths.router
										}
										icon={paths.icon}
									/>
								</Grid>
							)
					)}
				</Grid>
			</Box>
		</>
	);
};

export default CardGrid;

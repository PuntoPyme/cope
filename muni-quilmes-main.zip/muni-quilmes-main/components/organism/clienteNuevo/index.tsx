import { Alert, Box, Grid, Typography } from "@mui/material";
import { style } from "./clienteNuevoStyle";
import React, { useEffect, useState } from "react";
import TextInput from "@/components/atoms/Inputs/TextInput/TextInput";
import { clienteNuevo } from "@/types";
import NumberInput from "@/components/atoms/Inputs/NumberInputCultivo/NumberInput";
import GroupButtons from "@/components/moleculas/CardInicio/GroupButtons/GroupButtons";
import SelectInput from "@/components/atoms/Inputs/SelectInput/SelectInput";
import { useSelector } from "react-redux";
import { RootState } from "@/Redux/store";
import { useDispatch } from "react-redux";
import {
	resetClienteNuevoState,
	setClienteNuevoState,
} from "@/Redux/features/ClienteNuevoReducer";
import {
	formatCUIT,
	isValidCUIT,
	isValidEmail,
} from "@/utils/Functions/ValidationInputs";
import { fetchPostRequest } from "@/utils/ApiRequest";
import SelectInputProvincia from "@/components/atoms/Inputs/SelectProvincias/selectProvincias";
import { useRouter } from "next/router";
import {
	arrayOptionesIVA,
	arrayTipoIdentificacion,
} from "@/utils/Functions/MockData";

const urlPOST = "/accountant/customer/register";
//suplier es proveedor customer es cliente
interface ClienteProps {
	onClickCancelar?: () => void;
}
const formStateInitialValue: clienteNuevo = {
	name: "",
	cuit: "",
	vat: arrayOptionesIVA[0],
	street: "",
	number: "",
	building: "",
	floor: 0,
	apartament: "",
	province: "",
	city: "",
	postalCode: 0,
	email: "",
	phone: "",
	country: "Argentina",
};
const ClienteNuevo: React.FC<ClienteProps> = ({ onClickCancelar }) => {
	const { clienteNuevo } = useSelector(
		(state: RootState) => state.clienteNuevo
	);
	const dispatch = useDispatch();
	const { codejwt } = useSelector((state: RootState) => state.storeJwt);
	const [alert, setAlert] = useState<boolean>(false);

	const [formErrors, setFormErrors] = useState({
		email: false,
		cuit: false,
	});
	const [formState, setFormState] = useState<clienteNuevo>(
		formStateInitialValue
	);

	const handleChange = (
		event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
	) => {
		const { name, value } = event.target;
		let updatedValue: string | number = value;

		if (name === "cuit") {
			updatedValue = formatCUIT(value);
		}
		if (name === "floor" || name === "postalCode") {
			updatedValue = value === "" ? 0 : Number(value);
		}
		const updatedFormState = {
			...formState,
			[name]: updatedValue,
		};
		if (name === "email") {
			setFormErrors((prev) => ({
				...prev,
				email: !isValidEmail(updatedValue as string),
			}));
		}
		if (name === "cuit") {
			setFormErrors((prev) => ({
				...prev,
				cuit: !isValidCUIT(updatedValue as string),
			}));
		}
		setFormState(updatedFormState);
		dispatch(setClienteNuevoState(updatedFormState));
	};
	const handleSelectedChange = (name: string) => (value: string) => {
		const newState = {
			...formState,
			[name]: value,
		};
		setFormState(newState);
		dispatch(setClienteNuevoState(newState));
	};

	const handleClickGuardar = (
		url: string,
		input: clienteNuevo,
		codejwt: string
	) => {
		fetchPostRequest(url, input, codejwt).then((data) => {
			if (data.status === 200) {
				dispatch(resetClienteNuevoState());
				if (onClickCancelar) onClickCancelar();
			} else {
				setAlert(true);
			}
		});
	};

	useEffect(() => {
		setFormState(clienteNuevo);
	}, []);

	const renderField = (
		label: string,
		name: keyof clienteNuevo,
		component: React.ReactNode
	) => (
		<>
			<Grid item xs={6}>
				<Typography>{label}</Typography>
			</Grid>
			<Grid item xs={6}>
				{component}
			</Grid>
		</>
	);
	const handleLocationChange = (location: {
		province: string;
		municipio: string;
	}) => {
		setFormState((prevState) => ({
			...prevState,
			province: location.province,
			city: location.municipio,
		}));
	};
	function handleClickCancelar() {
		dispatch(resetClienteNuevoState());
		setFormState(formStateInitialValue);
		if (onClickCancelar) {
			onClickCancelar();
		}
	}
	useEffect(() => {
		setTimeout(() => {
			setAlert(false);
		}, 4000);
	}, [alert]);
	return (
		<Box
			display="flex"
			flexDirection="column"
			marginTop="2%"
			position="relative"
		>
			<Box sx={style.boxPadre}>
				<Grid container spacing={2}>
					<Grid item xs={6} container spacing={2}>
						{renderField(
							"Nombre",
							"name",
							<TextInput
								name="name"
								enabled={true}
								value={formState.name}
								onChange={handleChange}
							/>
						)}
						{renderField(
							"Tipo de Identificación",
							"vat",
							<SelectInput
								value={arrayTipoIdentificacion[0]}
								arrayOptions={arrayTipoIdentificacion}
								onValueChange={handleSelectedChange("vat")}
								disabled={true}
							/>
						)}
						{renderField(
							"CUIT",
							"cuit",
							<TextInput
								name="cuit"
								enabled={true}
								value={formState.cuit}
								onChange={handleChange}
								error={formErrors.cuit}
							/>
						)}
						{renderField(
							"Condición IVA",
							"vat",
							<SelectInput
								value={formState.vat || ""}
								arrayOptions={arrayOptionesIVA}
								onValueChange={handleSelectedChange("vat")}
							/>
						)}
						{renderField(
							"Email",
							"email",
							<TextInput
								name="email"
								enabled={true}
								value={formState.email}
								onChange={handleChange}
								error={formErrors.email}
								helperText={formErrors.email ? "Email inválido" : ""}
							/>
						)}
						{renderField(
							"Teléfono",
							"phone",
							<TextInput
								name="phone"
								enabled={true}
								value={formState.phone}
								onChange={handleChange}
							/>
						)}

						{renderField(
							"País",
							"country",
							<TextInput
								name="country"
								enabled={false}
								value={formState.country}
								onChange={handleChange}
							/>
						)}
					</Grid>
					<Grid item xs={6} container spacing={2}>
						{renderField(
							"Código Postal",
							"postalCode",
							<NumberInput
								name="postalCode"
								enabled={true}
								value={formState.postalCode}
								onChange={handleChange}
							/>
						)}

						{renderField(
							"Provincia",
							"province",
							<SelectInputProvincia onValueChange={handleLocationChange} />
						)}

						{renderField(
							"Calle",
							"street",
							<TextInput
								name="street"
								enabled={true}
								value={formState.street}
								onChange={handleChange}
							/>
						)}
						{renderField(
							"Número",
							"number",
							<TextInput
								name="number"
								enabled={true}
								value={formState.number}
								onChange={handleChange}
							/>
						)}
						{renderField(
							"Edificio",
							"building",
							<TextInput
								name="building"
								enabled={true}
								value={formState.building}
								onChange={handleChange}
							/>
						)}
						{renderField(
							"Piso",
							"floor",
							<NumberInput
								name="floor"
								enabled={true}
								value={formState.floor}
								onChange={handleChange}
							/>
						)}
						{renderField(
							"Departamento",
							"apartament",
							<TextInput
								name="apartament"
								enabled={true}
								value={formState.apartament}
								onChange={handleChange}
							/>
						)}
					</Grid>
				</Grid>
			</Box>
			{alert ? (
				<Box
					sx={{
						width: "40%",
						right: "30%",
						position: "absolute",
						top: "40%",
					}}
				>
					<Alert variant="filled" severity="error" sx={{ textAlign: "center" }}>
						No se pudo crear el cliente, revise la información y vuelva
						intentarlo.
					</Alert>
				</Box>
			) : null}
			<Box sx={{ width: "100%", mb: "2%" }}>
				<GroupButtons
					clickCancelar={() => {
						handleClickCancelar();
					}}
					clickGuardar={() => handleClickGuardar(urlPOST, formState, codejwt)}
				/>
			</Box>
		</Box>
	);
};

export default ClienteNuevo;

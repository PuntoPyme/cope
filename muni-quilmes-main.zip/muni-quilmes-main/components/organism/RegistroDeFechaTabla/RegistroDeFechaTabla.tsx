import { Grid, Paper } from "@mui/material";
import { style } from "./style";
import { useState } from "react";
const RegistroDeFechaTabla = () => {
	let fechaInicial = new Date();
	// Extract the year, month, and day components
	const year = fechaInicial.getFullYear();
	const month = (fechaInicial.getMonth() + 1).toString().padStart(2, "0"); // Months are 0-based, so add 1 and format as two digits
	const day = fechaInicial.getDate().toString().padStart(2, "0");

	// Format the date in "yyyy-MM-dd" format
	const formattedDate = `${year}-${month}-${day}`;
	const [fechaRegistro, setFechaRegistro] = useState<Date | string>(
		formattedDate
	);

	const handleFechaRegistroChange = (selectedDate: Date | string) => {
		setFechaRegistro(selectedDate); // Update the state with the selected date
	};

	return (
		<>
			<Grid container alignItems="center" sx={style.BoxPadre}>
				<Paper
					sx={{
						background: "transparent",
						width: "fit-content",
						overflow: "hidden",
						position: "relative",
					}}
				>
					<Grid sx={{ width: "100%", pl: "0vw" }}></Grid>
					<Grid
						mt={"2%"}
						item
						sx={{
							display: "flex",
							alignItems: "center",
							justifyContent: "center",
						}}
					></Grid>
				</Paper>
			</Grid>
		</>
	);
};

export default RegistroDeFechaTabla;

import { CSSProperties } from "@mui/styles";
import { gradients } from "@/utils/styles/gradients";
import { colors } from "@/utils/styles/colors";
export const style: Record<string, CSSProperties> = {
	BoxPadre: {
		margin:'0 !important',
		padding:'0',
		alignItems: "center",
		justifyContent:'center',
		width: "fit-content !important",
		height: "fit-content",
		position: "relative",
		borderRadius: "40px",
		gap: "3vw",
	},
};

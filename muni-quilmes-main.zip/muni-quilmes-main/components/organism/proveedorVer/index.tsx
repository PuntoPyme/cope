import { Box, Modal } from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import TablaProveedor from "@/components/atoms/TABLAS/PersonaVerTabla/PersonaTabla";
import { ButtonClasic } from "@/components/atoms/Button/Button-clasic/ButtonClasic";
import { ButtonIcon } from "@/components/atoms/Button/Button-icon/ButtonIcon";
import Header from "@/components/atoms/Header/Header";
import { ButtonActions } from "@/components/atoms/ButtonActions/ButtonActions";
import { useReactToPrint } from "react-to-print";
import ProveedorNuevo from "../proveedorNuevo";
import BuscadorAtom from "@/components/atoms/Buscador/Buscador";
import { ModalComponent } from "@/components/atoms/Modal/ModalAtom";
import { fetchGetRequest } from "@/utils/ApiRequest";
import { isValidEntityArray } from "@/utils/Functions/ValidationInputs";
import { useSelector } from "react-redux";
import { RootState } from "@/Redux/store";
import { useDispatch } from "react-redux";
import { clienteProveedorVer } from "@/types";
import { setProveedores } from "@/Redux/features/ProveedoresArrayStore";

const ProveedorVer = () => {
	const dispatch = useDispatch();
	const { codejwt } = useSelector((state: RootState) => state.storeJwt);
	const [open, setOpen] = useState(false);
	const [resultadoBusqueda, setResultadoBusqueda] = useState<string>("");
	const [dataForComponent, setDataForComponent] = useState<
		clienteProveedorVer[]
	>([]);
	const handleBusqueda = (valor: string): string => {
		setResultadoBusqueda(valor); // Guarda el valor en el estado
		return valor; // O cualquier operación que desees realizar
	};

	const [resultadoAccion, setResultadoAccion] = useState<string>("");
	useEffect(() => {
		const changeResult = () => {
			if (resultadoAccion === "Imprimir" || resultadoAccion === "Eliminar") {
				setResultadoAccion("");
			}
		};
		changeResult();
	}, [resultadoAccion]);
	const handleOpenModal = () => {
		setOpen(true);
	};

	function getPersons() {
		fetchGetRequest("/accountant/suppliers/by-company-id", codejwt).then(
			(data: unknown) => {
				if (isValidEntityArray(data)) {
					if (data) {
						setDataForComponent(data);
						dispatch(setProveedores(data));
					}
				} else {
					setDataForComponent([]);
				}
			}
		);
	}
	useEffect(() => {
		getPersons();
	}, [codejwt]);
	return (
		<>
			<Header
				background={false}
				children={
					<>
						<Box width={"30%"}>
							<ButtonIcon
								onClick={() => {
									handleOpenModal();
								}}
							>
								Nueva Ventana
							</ButtonIcon>
						</Box>
						<Box width={"30%"}>
							<ButtonActions
								onActionSelect={(event) => {
									setResultadoAccion(event);
								}}
								acciones={["Imprimir", "Eliminar"]}
							>
								Acciones
							</ButtonActions>
						</Box>
					</>
				}
				children2={
					<BuscadorAtom result={handleBusqueda} value={resultadoBusqueda} />
				}
			/>
			<Box
				sx={{
					height: "100%",
					pt: "5%",
					width: "90%",
					display: "flex",
					justifyContent: "center",
				}}
			>
				<TablaProveedor
					urlDelete="/accountant/supplier/status"
					persona="Proveedores"
					resultadoAccion={resultadoAccion}
					resultadoBusqueda={resultadoBusqueda}
					data={dataForComponent}
					onDeleteComplete={() => {
						getPersons(); // Esto podría ser una llamada para refrescar la lista
					}}
				/>
			</Box>
			<ModalComponent openProp={open}>
				<ProveedorNuevo
					onClickCancelar={() => {
						setOpen(false);
						getPersons();
					}}
				/>
			</ModalComponent>
		</>
	);
};

export default ProveedorVer;

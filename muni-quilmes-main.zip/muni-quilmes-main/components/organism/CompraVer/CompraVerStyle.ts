import { CSSProperties } from "@mui/styles";
// import "url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap')";
export const style: Record<string, CSSProperties> = {
	boxModal: {
		display: "flex",
		flexDirection: "column",
		alignItems: "center",
		justifyContent: "spaceBetween",
		height: "fit-content",
		textAlign: "justify",
		width: "100%",
		overflow: "hidden",
		margin: "auto",
		padding: "2%",
		"& .MuiTypography-root": {
			whiteSpace: "pre",
			lineHeight: "29.5px",
			fontWeight: 400,
			textTransform: "capitalize",
		},
		"& .MuiFormControl-root": {
			["& .MuiOutlinedInput-root"]: {
				// el input en si,
				backgroundColor: "#D9D9D9",
				width: "230px",
				height: "28px",
				borderRadius: "0px !important",
				["& .MuiOutlinedInput-notchedOutline"]: {
					// para eliminar los bordes por defecto que genera materialui
					borderRadius: "10px !important",
					border: "none !important",
				},
			},
		},
	},
	button: {
		whiteSpace: "pre",
		fontFamily: "poppins",
		fontWeight: 300,
		minWidth: "fit-content",
		width: "110px",
		height: "30px",
		borderRadius: "10px",
		background: "white",
		color: "#7A61A1",
		textTransform: "capitalize",
		borderColor: "#7A61A1",
		margin: "1% 0.3% 1% 1%",
	},
	button2: {
		whiteSpace: "pre",
		fontFamily: "poppins",
		fontWeight: 300,
		minWidth: "fit-content",
		width: "110px",
		height: "30px",
		borderRadius: "10px",
		background: "#7A61A1",
		color: "white",
		textTransform: "capitalize",
		borderColor: "white",
		margin: "1% 0.3% 1% 1%",
	},
	button3: {
		whiteSpace: "pre",
		fontFamily: "poppins",
		fontWeight: 300,
		minWidth: "fit-content",
		width: "110px",
		height: "30px",
		borderRadius: "10px",
		background: "white",
		color: "#7A61A1",
		textTransform: "capitalize",
		borderColor: "#7A61A1",
		ml: "3%"
		
	},
};

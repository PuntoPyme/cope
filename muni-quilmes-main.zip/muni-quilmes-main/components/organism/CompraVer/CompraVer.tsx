import { Box } from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import TablaComprobante from "@/components/atoms/TABLAS/TablaCompras/ComprasVER";
import { ButtonClasic } from "@/components/atoms/Button/Button-clasic/ButtonClasic";
import Header from "@/components/atoms/Header/Header";
import { ButtonIcon } from "@/components/atoms/Button/Button-icon/ButtonIcon";
import { ButtonActions } from "@/components/atoms/ButtonActions/ButtonActions";
import HeaderDate from "@/components/atoms/Header/HeaderDate";
import BuscadorAtom from "@/components/atoms/Buscador/Buscador";
import { ModalComponent } from "@/components/atoms/Modal/ModalAtom";
import NewInvoiceComponent from "../Invoice/InvoiceComponent";
import { RootState } from "@/Redux/store";
import { useSelector } from "react-redux";
import { fetchGetRequest } from "@/utils/ApiRequest";
import { isPurchaseInvoices } from "@/utils/Functions/ValidationInputs";
import { compraVer } from "@/types";

const CompraVer = () => {
	const { proveedoresVer } = useSelector(
		(state: RootState) => state.proveedoresArray
	);
	const [rowsState, setRowsState] = useState<compraVer[]>([]);
	const { codejwt } = useSelector((state: RootState) => state.storeJwt);
	const [open, setOpen] = useState(false);
	const [resultadoAccion, setResultadoAccion] = useState<string>("");
	const [periodo, setPeriodo] = useState<{
		desde: Date | null;
		hasta: Date | null;
	}>({
		desde: null,
		hasta: null,
	});
	const [resultadoBusqueda, setResultadoBusqueda] = useState<string>("");

	const handleBusqueda = (valor: string): string => {
		setResultadoBusqueda(valor); // Guarda el valor en el estado
		return valor; // O cualquier operación que desees realizar
	};
	const handlePeriodoChange = (newPeriodo: {
		desde: Date | null;
		hasta: Date | null;
	}) => {
		setPeriodo(newPeriodo);
	};
	useEffect(() => {
		const changeResult = () => {
			if (resultadoAccion === "Imprimir" || resultadoAccion === "Eliminar") {
				setResultadoAccion("");
			}
		};
		changeResult();
	}, [resultadoAccion]);
	const handleOpenModal = () => {
		setOpen(true);
	};

	function handleClickVerTodo() {
		setPeriodo({ desde: null, hasta: null });
		setResultadoBusqueda("");
	}
	function getInvoice() {
		fetchGetRequest("/accountant/purchase-invoice/byCompany", codejwt).then(
			(data) => {
				if (isPurchaseInvoices(data)) {
					setRowsState(data);
				}
			}
		);
	}

	useEffect(() => {
		getInvoice();
	}, []);

	return (
		<>
			<Header
				background={false}
				children={<HeaderDate onPeriodoChange={handlePeriodoChange} />}
				children2={
					<BuscadorAtom result={handleBusqueda} value={resultadoBusqueda} />
				}
			/>
			<Header
				background={true}
				children2={
					<Box width={"30%"}>
						<ButtonClasic
							primary
							children="Limpiar filtros"
							onClick={() => {
								handleClickVerTodo();
							}}
						/>
					</Box>
				}
				children={
					<>
						<Box width={"30%"} display={"flex"}>
							<ButtonIcon
								onClick={() => {
									handleOpenModal();
								}}
							>
								Nueva Ventana
							</ButtonIcon>
						</Box>
						<Box width={"30%"} display={"flex"}>
							<ButtonActions
								onActionSelect={(event) => {
									setResultadoAccion(event);
								}}
								acciones={["Imprimir", "Eliminar"]}
							>
								Acciones
							</ButtonActions>
						</Box>
					</>
				}
			/>
			<Box
				sx={{
					height: "100%",
					pt: "5%",
					width: "90%",
					display: "flex",
					justifyContent: "center",
				}}
			>
				<TablaComprobante
					checkoutPage
					resultadoAccion={resultadoAccion}
					periodo={periodo}
					resultadoBusqueda={resultadoBusqueda}
					itemsForRows={rowsState}
				/>
			</Box>
			<ModalComponent openProp={open}>
				<NewInvoiceComponent
					page="purchase"
					urlPOST="/accountant/purchase-invoice/create"
					onClickCancelar={() => {
						setOpen(false);
						getInvoice();
					}}
					arrayPersons={proveedoresVer}
				/>
			</ModalComponent>
		</>
	);
};

export default CompraVer;

import { Box, IconButton } from "@mui/material";
import React, { FC, useEffect, useState } from "react";
import TablaVentasVer from "@/components/atoms/TABLAS/VentasVerTabla/VentaVerTabla";
import { ButtonIcon } from "@/components/atoms/Button/Button-icon/ButtonIcon";
import Header from "@/components/atoms/Header/Header";
import { ButtonActions } from "@/components/atoms/ButtonActions/ButtonActions";
import HeaderDate from "@/components/atoms/Header/HeaderDate";
import BuscadorAtom from "@/components/atoms/Buscador/Buscador";
import { ModalComponent } from "@/components/atoms/Modal/ModalAtom";
import NewInvoiceComponent from "../Invoice/InvoiceComponent";
import { ButtonClasic } from "@/components/atoms/Button/Button-clasic/ButtonClasic";
import { isSalesInvoices } from "@/utils/Functions/ValidationInputs";
import { fetchGetRequest } from "@/utils/ApiRequest";
import { useSelector } from "react-redux";
import { RootState } from "@/Redux/store";
import { ventaVer } from "@/types";

const VentaVer = () => {
	const { clienteNuevo } = useSelector(
		(state: RootState) => state.clienteArray
	);
	const [open, setOpen] = useState(false);
	const [resultadoAccion, setResultadoAccion] = useState<string>("");
	const [resultadoBusqueda, setResultadoBusqueda] = useState<string>("");
	const [rowsState, setRowsState] = useState<ventaVer[]>([]);
	const [periodo, setPeriodo] = useState<{
		desde: Date | null;
		hasta: Date | null;
	}>({
		desde: null,
		hasta: null,
	});
	const { codejwt } = useSelector((state: RootState) => state.storeJwt);
	const handleBusqueda = (valor: string): string => {
		setResultadoBusqueda(valor); // Guarda el valor en el estado
		return valor; // O cualquier operación que desees realizar
	};
	useEffect(() => {
		const changeResult = () => {
			if (resultadoAccion === "Imprimir" || resultadoAccion === "Eliminar") {
				setResultadoAccion("");
			}
		};
		changeResult();
	}, [resultadoAccion]);

	const handlePeriodoChange = (newPeriodo: {
		desde: Date | null;
		hasta: Date | null;
	}) => {
		setPeriodo(newPeriodo);
	};
	const handleOpenModal = () => {
		setOpen(true);
	};
	function handleClickVerTodo() {
		setPeriodo({ desde: null, hasta: null });
		setResultadoBusqueda("");
	}
	function getInvoice() {
		fetchGetRequest("/accountant/sales-invoice/byCompany", codejwt)
			.then((data: unknown) => {
				if (isSalesInvoices(data)) {
					setRowsState(data);
				} else {
					console.error("Received data is not of type Invoice[]");
				}
			})
			.catch((error) => {
				console.error("Error fetching invoices:", error);
			});
	}
	useEffect(() => {
		getInvoice();
	}, [codejwt]);

	return (
		<>
			<Header
				background={false}
				children={<HeaderDate onPeriodoChange={handlePeriodoChange} />}
				children2={
					<BuscadorAtom result={handleBusqueda} value={resultadoBusqueda} />
				}
			/>
			<Header
				background={true}
				children2={
					<Box width={"30%"}>
						<ButtonClasic
							primary
							children="Limpiar filtros"
							onClick={() => {
								handleClickVerTodo();
							}}
						/>
					</Box>
				}
				children={
					<>
						<Box width={"30%"}>
							<ButtonIcon onClick={handleOpenModal}>Nueva Ventana</ButtonIcon>
						</Box>
						<Box width={"30%"}>
							<ButtonActions
								acciones={["Imprimir", "Eliminar"]}
								onActionSelect={(event) => {
									setResultadoAccion(event);
								}}
							>
								Acciones
							</ButtonActions>
						</Box>
					</>
				}
			/>
			<Box
				sx={{
					height: "100%",
					py: "5%",
					width: "90%",
					display: "flex",
					justifyContent: "center",
				}}
			>
				<TablaVentasVer
					checkoutPage={true}
					itemsForRows={rowsState}
					resultadoAccion={resultadoAccion}
					periodo={periodo}
					resultadoBusqueda={resultadoBusqueda}
				/>
			</Box>
			<ModalComponent openProp={open}>
				<NewInvoiceComponent
					urlPOST="/accountant/sales-invoice/create"
					page="sales"
					onClickCancelar={() => {
						setOpen(false);
						getInvoice();
					}}
					arrayPersons={clienteNuevo}
				/>
			</ModalComponent>
		</>
	);
};

export default VentaVer;

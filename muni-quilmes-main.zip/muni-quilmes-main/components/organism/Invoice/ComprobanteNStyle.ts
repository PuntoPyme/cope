import { CSSProperties } from "@mui/styles";
// import "url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap')";
export const style: Record<string, CSSProperties> = {
	boxPadre: {
		width: "80vw",
		height: "auto",
		background: "white",
		p: "2vw",
		overflow: "hidden",
	},
	boxModal2: {
		display: "flex",
		flexDirection: "column",
		alignItems: "center",
		justifyContent: "spece-between",
		height: "fit-content",
		textAlign: "justify",
		width: "100%",
		overflow: "hidden",
		mt: "-2%",
	},
	accordion: {
		display: "flex",
		alignItems: "flex-start",
		flexDirection: "column",
		boxShadow: "none",
		background: "transparent",
		marginTop: "2%",
	},
	buttonsEnd: {
		width: "100%",
		my: "2%",

	},
};

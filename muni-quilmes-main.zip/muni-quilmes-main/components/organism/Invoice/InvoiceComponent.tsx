import { Alert, Box, Grid, Typography } from "@mui/material";
import { style } from "./ComprobanteNStyle";
import React, { useEffect, useRef, useState } from "react";
import {
	ubicacionAPIgobierno,
	InvoiceClient,
	InvoiceProduct,
	Invoice,
	clienteProveedorVer,
} from "@/types";
import { useSelector } from "react-redux";
import { RootState } from "@/Redux/store";
import GroupButtons from "@/components/moleculas/CardInicio/GroupButtons/GroupButtons";
import { useDispatch } from "react-redux";
import {
	resetInvoiceReduxx,
	setInvoiceRedux,
} from "@/Redux/features/InvoiceReducer";
import TextInput from "@/components/atoms/Inputs/TextInput/TextInput";
import SelectInput from "@/components/atoms/Inputs/SelectInput/SelectInput";
import {
	convertValueString,
	invoiceTypes,
	paymentMethod,
} from "@/utils/Functions/ValidationInputs";
import DateInput from "@/components/atoms/Inputs/InputDate/DateInput";
import { formatISO } from "date-fns";
import { fetchPostRequest } from "@/utils/ApiRequest";
import { resetProductRedux } from "@/Redux/features/productReducer";
import TableProduct from "@/components/atoms/TABLAS/TableProduct/TableProduct";
import TablaTotal from "@/components/atoms/TABLAS/TablaTotal/TablaTotal";
import { useRouter } from "next/router";

const formStateInitialValue: InvoiceClient = {
	customerName: "",
	province: "",
	invoiceType: "",
	date: "",
	expirationDate: "",
	number: "",
	paymentMethod: "",
	enabled: true,
};

// import PuntoDeVenta from '../PuntoDeVenta/'
interface NewInvoice {
	onClickCancelar?: () => void;
	urlPOST: string;
	page: string;
	arrayPersons: clienteProveedorVer[];
}
const NewInvoiceComponent: React.FC<NewInvoice> = ({
	onClickCancelar,
	urlPOST,
	page,
	arrayPersons,
}) => {
	const router = useRouter();
	// -------------------- REDUX -----------------------
	const dispatch = useDispatch();
	const { invoiceState } = useSelector((state: RootState) => state.newInvoice);
	const { provincias } = useSelector((state: RootState) => state.provincias);
	const { items } = useSelector((state: RootState) => state.productReducer);
	const { codejwt } = useSelector((state: RootState) => state.storeJwt);

	// -------------------- ESTADOS -----------------------
	const [totals, setTotals] = useState({
		totalBruto: 0,
		totalImpuesto: 0,
		total: 0,
	});
	const [isClient, setIsClient] = useState(false);
	const [enabledBottom, setEnabledBottom] = useState<boolean>(false);
	const [formState, setFormState] = useState<InvoiceClient>(
		formStateInitialValue
	);
	const [alert, setAlert] = useState<boolean>(false);
	const [formStateProduct, setFormStateProduct] =
		useState<InvoiceProduct[]>(items);
	const [personSelect, setPersonSelect] = useState<clienteProveedorVer>();
	const [provinciasState, setProvinciasState] = useState<
		ubicacionAPIgobierno[]
	>([]);
	// -------------------- EFFECTS -----------------------

	useEffect(() => {
		setProvinciasState(provincias);
	}, [provincias]);

	useEffect(() => {
		setFormStateProduct(items);
	}, [items]);

	useEffect(() => {
		if (invoiceState !== undefined) {
			setFormState(invoiceState);
		}
	}, []);
	const handleRowsChange = (updatedRows: InvoiceProduct[]) => {
		setFormStateProduct(updatedRows);
	};
	useEffect(() => {
		calculateTotals();
	}, [formStateProduct]);

	useEffect(() => {
		const isValid = Object.values(formState).every((value) => {
			return value !== "" && value !== undefined;
		});
		if (isValid && formStateProduct[0].grossAmount > 0) {
			setEnabledBottom(false);
		} else {
			setEnabledBottom(true);
		}
	}, [formState, formState, formStateProduct]);

	useEffect(() => {
		setTimeout(() => {
			setAlert(false);
		}, 3000);
	}, [alert]);
	useEffect(() => {
		setIsClient(true);
	}, []);
	// -------------------- FUNCIONES HANDLE -----------------------

	const handleChange = (
		event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
	) => {
		const { name, value } = event.target;
		const newState = {
			...formState,
			[name]: value,
		};
		setFormState(newState);
		dispatch(setInvoiceRedux(newState));
	};

	const handleDateChange = (name: string, value: Date | null) => {
		if (value !== null) {
			const updated = {
				...formState,
				[name]: formatISO(value),
			};
			setFormState(updated);
			dispatch(setInvoiceRedux(updated));
		}
	};

	const handleSelectedChange = (name: string) => (value: string) => {
		const selectedPerson = arrayPersons.find((person) => person.name === value);

		const newState = {
			...formState,
			[name]: value !== undefined ? value.toString() : "", // Asegúrate de que no haya `undefined`
		};

		setFormState(newState);
		if (selectedPerson) {
			setPersonSelect(selectedPerson);
		}

		dispatch(setInvoiceRedux(newState));
	};

	const renderField = (
		label: string,
		name: keyof InvoiceClient,
		component: React.ReactNode
	) => (
		<>
			<Grid item xs={6}>
				<Typography>{label}</Typography>
			</Grid>
			<Grid item xs={6}>
				{component}
			</Grid>
		</>
	);

	const tablaRef = useRef<null | { clearRows: () => void }>(null);

	const handleClickGuardar = (
		url: string,
		formState: InvoiceClient,
		formStateProduct: InvoiceProduct[],
		page: string,
		jwt: string
	) => {
		const nameField = page === "sales" ? "customerName" : "supplierName";
		let bodyRequest: Invoice = {
			[nameField]: formState.customerName,
			province: formState.province,
			invoiceType: formState.invoiceType,
			date: formatISO(new Date(formState.date)),
			expirationDate: formatISO(new Date(formState.expirationDate)),
			number: formState.number,
			paymentMethod: formState.paymentMethod,
			enabled: true,
			items: formStateProduct.map((item) => {
				const amount = item.quantity * item.amount; // cantidad * precio
				const vatRate = item.vat / 100; // Divides vat percentage to calculate the value
				const vat = amount * vatRate; // Cálculo de IVA
				const grossAmount = amount + vat; // amount + IVA

				return {
					description: item.description,
					additionalInfo: item.additionalInfo,
					quantity: item.quantity,
					amount: amount, // Calculado
					vat: item.vat,
					grossAmount: grossAmount, // Calculado
					invoiceId: formState.number,
					discount: item.discount,
				};
			}),
		};

		if (page === "sales") {
			bodyRequest = {
				...bodyRequest,
				customer_id: personSelect?.id,
				vat: personSelect?.vat && convertValueString(personSelect?.vat),
			};
		}
		console.log(bodyRequest);
		// fetchPostRequest(url, bodyRequest, jwt).then((data) => {
		// 	if (data.status === 200) {
		// 		dispatch(resetProductRedux());
		// 		setFormState(formStateInitialValue);
		// 		dispatch(resetInvoiceReduxx());
		// 		if (onClickCancelar) onClickCancelar();
		// 		if (tablaRef.current) {
		// 			tablaRef.current.clearRows();
		// 		}
		// 	} else {
		// 		setAlert(true);
		// 	}
		// });
	};

	const handleClickCancelar = () => {
		dispatch(resetProductRedux());
		dispatch(setInvoiceRedux(formStateInitialValue));
		setFormState(formStateInitialValue);
		if (onClickCancelar) onClickCancelar();
		if (tablaRef.current) {
			tablaRef.current.clearRows();
		}
		router.push(page == "sales" ? "/Venta/Ver" : "/Compra/Ver");
	};

	const calculateTotals = () => {
		let totalBruto = 0;
		let totalImpuesto = 0;
		let total = 0;
		formStateProduct.forEach((item) => {
			const lineTotal = item.quantity * item.amount;
			const discountAmount = lineTotal * (item.discount / 100);
			const lineGrossAmount = lineTotal - discountAmount;
			const lineTaxAmount = lineGrossAmount * (item.vat / 100);

			totalBruto += lineGrossAmount;
			totalImpuesto += lineTaxAmount;
			total += lineGrossAmount + lineTaxAmount;
		});
		setTotals({
			totalBruto: parseFloat(totalBruto.toFixed(2)),
			totalImpuesto: parseFloat(totalImpuesto.toFixed(2)),
			total: parseFloat(total.toFixed(2)),
		});
	};

	if (!isClient) {
		return null; // or a loading indicator
	}
	return (
		<>
			<Box
				display="flex"
				flexDirection={"column"}
				marginTop={"2%"}
				position={"relative"}
			>
				<Box sx={style.boxPadre}>
					<Grid container spacing={2}>
						<Grid item xs={6} container spacing={2}>
							{arrayPersons &&
								renderField(
									"Nombre",
									"customerName",
									<SelectInput
										value={personSelect ? personSelect.name : ""}
										onValueChange={handleSelectedChange("customerName")}
										arrayOptions={arrayPersons.map((data) => data.name)}
										// componenteModal={<ProveedorNuevo />}
									/>
								)}
							{renderField(
								"Provincia",
								"province",
								<SelectInput
									value={formState.province ? formState.province : ""}
									onValueChange={handleSelectedChange("province")}
									arrayOptions={provinciasState.map((data) => data.nombre)}
								/>
							)}
							{renderField(
								"Tipo de facturación",
								"invoiceType",
								<SelectInput
									value={formState.invoiceType}
									onValueChange={handleSelectedChange("invoiceType")}
									arrayOptions={invoiceTypes}
								/>
							)}
							{renderField(
								"Fecha",
								"date",
								<DateInput
									isRounded={false}
									name="date"
									value={new Date(formState.date)}
									onChange={(value) => handleDateChange("date", value)}
								/>
							)}
						</Grid>
						<Grid item xs={6} container spacing={2}>
							{renderField(
								"Vencimiento",
								"expirationDate",
								<DateInput
									isRounded={false}
									name="expirationDate"
									value={new Date(formState.expirationDate)}
									onChange={(value) =>
										handleDateChange("expirationDate", value)
									}
								/>
							)}
							{renderField(
								"Nro de factura",
								"number",
								<TextInput
									enabled={true}
									value={formState.number}
									name="number"
									onChange={handleChange}
								/>
							)}
							{renderField(
								"Método de pago",
								"paymentMethod",
								<SelectInput
									value={formState.paymentMethod}
									onValueChange={handleSelectedChange("paymentMethod")}
									arrayOptions={paymentMethod}
								/>
							)}
						</Grid>
					</Grid>
					<Box mt="2vh">
						<TableProduct onRowsChange={handleRowsChange} />
					</Box>
					<Box
						sx={{
							width: "100%",
							display: "flex",
							justifyContent: "flex-end",
						}}
					>
						<TablaTotal totals={totals} />
					</Box>
				</Box>
				<Box sx={style.buttonsEnd}>
					<GroupButtons
						disabled={enabledBottom}
						clickCancelar={() => {
							handleClickCancelar();
						}}
						clickGuardar={() => {
							handleClickGuardar(
								urlPOST,
								formState,
								formStateProduct,
								page,
								codejwt
							);
						}}
					/>
				</Box>
				{alert && (
					<Box
						sx={{
							width: "40%",
							right: "30%",
							position: "absolute",
							top: "40%",
						}}
					>
						<Alert variant="filled" severity="error">
							No se pudo cargar la factura
						</Alert>
					</Box>
				)}
			</Box>
		</>
	);
};

export default NewInvoiceComponent;

import  clienteArray  from "./../features/ClientesArrayStore";
import  proveedoresArray  from "./../features/ProveedoresArrayStore";
import { combineReducers } from "@reduxjs/toolkit";
import provinciasReducer from "../features/provinciasReducer";
import clienteNuevo from "../features/ClienteNuevoReducer";
import proveedorNuevo from "../features/ProveedorNuevoReducer";
import newInvoice from "../features/InvoiceReducer";
import productReducer from "../features/productReducer";
import codejwt from "../features/Codejwt";
import accountJournalState from "../features/AccountForBook";

const rootReducer = combineReducers({
	provincias: provinciasReducer,
	clienteNuevo: clienteNuevo,
	proveedorNuevo: proveedorNuevo,
	newInvoice: newInvoice,
	productReducer: productReducer,
	storeJwt: codejwt,
	accountJournal: accountJournalState,
	clienteArray: clienteArray,
	proveedoresArray: proveedoresArray
});

export default rootReducer;

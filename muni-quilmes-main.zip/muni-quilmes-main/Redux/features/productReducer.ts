import { InvoiceProduct } from "./../../types/index";
import { productoServicio } from "@/types";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface producto {
	items: InvoiceProduct[];
}

const initialState = {
	items: [
		{
			description: "",
			additionalInfo: "",
			quantity: 0,
			amount: 0,
			discount: 0,
			vat: 0,
			grossAmount: 0,
			invoiceId: "	",
		},
	],
};
const productoVentaSlice = createSlice({
	name: "productoVentaRedux",
	initialState,
	reducers: {
		setProductRedux: (state, action: PayloadAction<InvoiceProduct[]>) => {
			state.items = action.payload.map((item) => ({
				...item,
				invoiceId: String(item.invoiceId), // Convertir a string si es necesario
			}));
		},
		resetProductRedux: (state) => {
			state.items = initialState.items;
		},
	},
});

export const { setProductRedux, resetProductRedux } =
	productoVentaSlice.actions;
export default productoVentaSlice.reducer;

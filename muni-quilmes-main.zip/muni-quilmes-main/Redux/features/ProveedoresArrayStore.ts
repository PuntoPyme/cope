import { clienteProveedorVer } from "@/types";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export interface proveedoresArray {
	proveedoresVer: clienteProveedorVer[]; // Ahora es un array de 'clienteProveedorVer'
}

const initialState: proveedoresArray = {
	proveedoresVer: [],
};

const clienteArraySlice = createSlice({
	name: "proveedoresVer",
	initialState,
	reducers: {
		// Guardar un array completo de clientes
		setProveedores: (state, action: PayloadAction<clienteProveedorVer[]>) => {
			state.proveedoresVer = action.payload;
		},
		// Actualizar un cliente específico por índice
		updateProveedores: (
			state,
			action: PayloadAction<{ index: number; cliente: clienteProveedorVer }>
		) => {
			state.proveedoresVer[action.payload.index] = action.payload.cliente;
		},
		// Eliminar un cliente del array por índice
		removeProveedor: (state, action: PayloadAction<number>) => {
			state.proveedoresVer.splice(action.payload, 1);
		},
		// Reiniciar el estado a su valor inicial (vacío)
		resetProveedores: (state) => {
			state.proveedoresVer = initialState.proveedoresVer;
		},
	},
});

export const {
	setProveedores,
	updateProveedores,
	removeProveedor,
	resetProveedores,
} = clienteArraySlice.actions;
export default clienteArraySlice.reducer;

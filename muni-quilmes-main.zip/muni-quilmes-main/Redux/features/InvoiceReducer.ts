import { Invoice, InvoiceClient } from "@/types";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
export interface ventaNuevoState {
	invoiceState: InvoiceClient;
}

// Estado inicial con SalesInvoiceClient
const initialState: ventaNuevoState = {
	invoiceState: {
		customerName: "",
		province: "",
		invoiceType: "",
		date: "",
		expirationDate: "",
		number: "",
		paymentMethod: "",
		enabled: true,
	},
};
const ventaNuevoState = createSlice({
	name: "invoiceState",
	initialState,
	reducers: {
		setInvoiceRedux: (state, action: PayloadAction<Partial<InvoiceClient>>) => {
			state.invoiceState = {
				...state.invoiceState,
				...action.payload, // Actualizamos solo los campos recibidos
			};
		},
		resetInvoiceReduxx: (state) => {
			state.invoiceState = initialState.invoiceState;
		},
	},
});

export const { setInvoiceRedux, resetInvoiceReduxx } = ventaNuevoState.actions;
export default ventaNuevoState.reducer;

import { jwtDecode } from "jwt-decode";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
export interface CodeJwtState {
	codejwt: string;
	expirationTime: number | null; // Tiempo de expiración en milisegundos
	creationTime: number | null; // Tiempo de creación del token
}

const initialState: CodeJwtState = {
	codejwt: "",
	expirationTime: null,
	creationTime: null,
};

const codeJwtSlice = createSlice({
	name: "codeJwt",
	initialState,
	reducers: {
		setCodeJwtState: (state, action: PayloadAction<string>) => {
			state.codejwt = action.payload;
			state.creationTime = Date.now(); // Guarda el tiempo actual como momento de creación

			try {
				const payload = jwtDecode<{ exp: number }>(action.payload);
				const expirationTime = payload.exp * 1000; // Convertimos a milisegundos
				state.expirationTime = expirationTime;
			} catch (error) {
				console.error("Error al decodificar el token JWT:", error);
				state.expirationTime = null; // Reinicia en caso de error
				state.creationTime = null; // Reinicia en caso de error
			}
		},
		resetCodeJwtState: (state) => {
			state.codejwt = "";
			state.expirationTime = null;
			state.creationTime = null;
		},
	},
});

export const { setCodeJwtState, resetCodeJwtState } = codeJwtSlice.actions;
export default codeJwtSlice.reducer;

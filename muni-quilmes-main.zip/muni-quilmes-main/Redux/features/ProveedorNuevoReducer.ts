import { proveedorNuevo } from "@/types";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export interface proveedorNuevoState {
	proveedorNuevo: proveedorNuevo;
}

const initialState: proveedorNuevoState = {
	proveedorNuevo: {
		name: "",
		cuit: "",
		vat: "",
		street: "",
		number: "",
		building: "",
		floor: 0,
		apartament: "",
		province: "",
		city: "",
		postalCode: 0,
		email: "",
		phone: "",
		active: true,
		country: "Argentina",
	},
};

const proveedorNuevoSlice = createSlice({
	name: "proveedorNuevo",
	initialState,
	reducers: {
		setProveedorNuevoState: (state, action: PayloadAction<proveedorNuevo>) => {
			state.proveedorNuevo = action.payload;
		},
		resetProveedorNuevoState: (state) => {
			state.proveedorNuevo = initialState.proveedorNuevo;
		},
	},
});

export const { setProveedorNuevoState, resetProveedorNuevoState } =
	proveedorNuevoSlice.actions;
export default proveedorNuevoSlice.reducer;

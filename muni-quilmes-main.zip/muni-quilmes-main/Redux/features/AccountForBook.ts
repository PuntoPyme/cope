import { accountForJournal } from "@/types";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export interface AccountJournal {
	account: accountForJournal[];
}

const initialState: AccountJournal = {
	account: [{ name: "", code: 0, id: 0 }],
};

const AccountJournalSlice = createSlice({
	name: "accountJournalState",
	initialState,
	reducers: {
		setAccountJournal: (state, action: PayloadAction<accountForJournal[]>) => {
			state.account = action.payload;
		},
	},
});

export const { setAccountJournal } = AccountJournalSlice.actions;
export default AccountJournalSlice.reducer;

import { ubicacionAPIgobierno } from "@/types";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export interface ProvinciaState {
	provincias: ubicacionAPIgobierno[];
}

const initialState: ProvinciaState = {
	provincias: [{ id: "", nombre: "" }],
};

const provinciasSlice = createSlice({
	name: "provincias",
	initialState,
	reducers: {
		setProvincias: (state, action: PayloadAction<ubicacionAPIgobierno[]>) => {
			state.provincias = action.payload;
		},
	},
});

export const { setProvincias } = provinciasSlice.actions;
export default provinciasSlice.reducer;

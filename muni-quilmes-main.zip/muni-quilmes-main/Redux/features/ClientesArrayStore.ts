import { clienteProveedorVer } from "@/types";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export interface clienteArray {
	clienteNuevo: clienteProveedorVer[]; // Ahora es un array de 'clienteProveedorVer'
}

const initialState: clienteArray = {
	clienteNuevo: [],
};

const clienteArraySlice = createSlice({
	name: "clienteNuevo",
	initialState,
	reducers: {
		// Guardar un array completo de clientes
		setClientes: (state, action: PayloadAction<clienteProveedorVer[]>) => {
			state.clienteNuevo = action.payload;
		},
		// Actualizar un cliente específico por índice
		updateCliente: (
			state,
			action: PayloadAction<{ index: number; cliente: clienteProveedorVer }>
		) => {
			state.clienteNuevo[action.payload.index] = action.payload.cliente;
		},
		// Eliminar un cliente del array por índice
		removeCliente: (state, action: PayloadAction<number>) => {
			state.clienteNuevo.splice(action.payload, 1);
		},
		// Reiniciar el estado a su valor inicial (vacío)
		resetClienteState: (state) => {
			state.clienteNuevo = initialState.clienteNuevo;
		},
	},
});

export const { setClientes, updateCliente, removeCliente, resetClienteState } =
	clienteArraySlice.actions;
export default clienteArraySlice.reducer;

import { clienteNuevo } from "@/types";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export interface clienteNuevoState {
	clienteNuevo: clienteNuevo;
}

const initialState: clienteNuevoState = {
	clienteNuevo: {
		name: "",
		cuit: "",
		street: "",
		number: "",
		building: "",
		floor: 0,
		apartament: "",
		province: "",
		city: "",
		postalCode: 0,
		vat: "",
		email: "",
		phone: "",
		country: "Argentina",
	},
};

const clienteNuevoSlice = createSlice({
	name: "clienteNuevo",
	initialState,
	reducers: {
		setClienteNuevoState: (state, action: PayloadAction<clienteNuevo>) => {
			state.clienteNuevo = action.payload;
		},
		resetClienteNuevoState: (state) => {
			state.clienteNuevo = initialState.clienteNuevo;
		},
	},
});

export const { setClienteNuevoState, resetClienteNuevoState } =
	clienteNuevoSlice.actions;
export default clienteNuevoSlice.reducer;

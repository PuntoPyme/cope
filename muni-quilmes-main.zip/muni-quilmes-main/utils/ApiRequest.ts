import { MunicipioState, ProvinciaState, ubicacionAPIgobierno } from "@/types";

// CUANDO CREO EL USUARIO PONER INPUT DONDE INGRESAR EL CUIT DE LA COOPERATIVA Y LO ENLAZA
// Dónde definimos el rol?
// En que momento registramos a la cooperativa?
// El usuario se registra con su propio email o con el email de la cooperativa?

// cooperative-user-controller=>ADMIN/USER/REGISTER(POST) => CREAR USUARIO ACCOUNTAT
// LUEGO DE REGISTRAR EL USUARIO EJECUTO EL POST =>ADMIN/USER/RELATEUSERCOMPANY LO ASOCIO A UNA COOPERATIVA
// (AMBOS POST ANTERIORES DEBEN TENER EL MISMO EMAIL???)
// LOGIN RETURN JWT
// register-new-company-controller => CREA LA COOPERATIVA

// JWT DEL LOGIN =>
// VER (GET):
// find-all-sales-invoice-by-company-controller => Trae las facturas de venta por compania (GET)(accountant)
// find-all-purchase-invoices-by-company-controller => FACTURAS COMRPA
// get-all-customers-controller => CLIENTES (TODOS LOS CLIENTES DE LA APP)
// find-customer-by-company-controller => CLIENTES POR COMPANIA(GET)
// find-supplier-by-company-controller => PROVEEDORES POR COMPANIA(GET)

// POST
//NUEVA VENTA:
//  CreateNewSalesInvoiceRequestDto(TIPOS)(create-new-sales-invoice-controller)
// ENABLED => "BORRA" LA VENTA (LO TENGO EN EL CHECKBOX DE LA LISTA) => change-sales-invoice-status-controller
// create-new-sales-item-controller => CADA PRODUCTO
// PERCEPCIÓN DE IMPUESTOS NO EXISTE EN EL BACK
// MAS OPCIONES NO EXISTE EN EL BACK
// delete-sales-item-controller TODAVÍA NO SABEMOS SI IMPLEMENTARLO

//NUEVA COMPRA
// create-new-purchase-invoice-controller
// REPITE LO MISMO QUE EN VENTA
// create-new-purchase-item-controller => CADA PRODUCTO
// PERCEPCIÓN DE IMPUESTOS NO EXISTE EN EL BACK
// MAS OPCIONES NO EXISTE EN EL BACK

//NUEVO CLIENTE
// update-customer-controller (ACTUALIZAR)
// change-customer-status => ENABLED ('BORRA')
// register-new-customer-controller => CREAR CLIENTE

//NUEVO PROVEEDOR
// update-supplier-controller => ACTUALIZAR
// change-supplier-status-controller => ENABLED
// register-new-supplier-controller => CREAR
export async function fetchDataProvincias() {
	const response = await fetch(
		"https://apis.datos.gob.ar/georef/api/provincias?campos=id,nombre"
	);
	if (response.ok) {
		const dataApiProvincias: ProvinciaState = await response.json();

		return dataApiProvincias.provincias;
	}
}
export async function fetchMunicipios(idProvince: string) {
	const response = await fetch(
		`https://apis.datos.gob.ar/georef/api/municipios?provincia=${idProvince}&campos=id,nombre&max=100`,
		{
			method: "GET",
		}
	);
	if (response.ok) {
		const dataApimunicipios: MunicipioState = await response.json();
		return dataApimunicipios;
	}
}

// ---------------------API----------------------
export const BASE_URL = "http://200.61.183.85:8080";

export const PostLogin = async (email: string, password: string) => {
	const response = await fetch(`${BASE_URL}/auth/login`, {
		method: "POST",
		headers: {
			Accept: "application/json",
			"Content-Type": "application/json",
		},
		body: JSON.stringify({ email, password }),
	});
	if (response.ok) {
		const data = await response.json();
		return data.token; // Devolvemos el token directamente
	} else {
		return response.json();
	}
};

export async function fetchGetRequest<T>(
	url: string,
	jwt: string
): Promise<T | null> {
	const headers: HeadersInit = {
		Accept: "application/json",
		"Content-Type": "application/json",
		Authorization: `Bearer ${jwt}`,
	};
	try {
		const response = await fetch(`${BASE_URL}${url}`, {
			method: "GET",
			headers,
		});
		if (!response.ok) {
			throw new Error(`Error: ${response.status} - ${response.statusText}`);
		}
		const data = await response.json();
		return data;
	} catch (error) {
		console.error("GET request error:", error);
		return null;
	}
}
export async function fetchPostRequest<T>(
	url: string,
	body: any,
	jwt: string
): Promise<{ data: T | null; status: number; error?: string }> {
	const headers: HeadersInit = {
		Accept: "application/json",
		"Content-Type": "application/json",
		Authorization: `Bearer ${jwt}`,
	};

	try {
		const response = await fetch(`${BASE_URL}${url}`, {
			method: "POST",
			headers,
			body: JSON.stringify(body),
		});
		const data = await response.json();

		if (data.result === "ERROR" || data.result === "BAD_REQUEST") {
			return { data: null, status: 400, error: data.errorDescription };
		} else {
			return { data, status: 200 };
		}
	} catch (error) {
		return { data: null, status: 500, error: "Internal Server Error" };
	}
}

export async function fetchPostRegister<T>(
	url: string,
	body: any
): Promise<{ data: T | null; status: number; error?: string }> {
	const headers: HeadersInit = {
		Accept: "application/json",
		"Content-Type": "application/json",
	};
	try {
		const response = await fetch(`${BASE_URL}${url}`, {
			method: "POST",
			headers,
			body: JSON.stringify(body),
		});
		const data = await response.json();

		if (data.result === "ERROR" || data.result === "BAD_REQUEST") {
			return { data: null, status: 400, error: data.errorDescription };
		} else {
			return { data, status: 200 };
		}
	} catch (error) {
		return { data: null, status: 500, error: "Internal Server Error" };
	}
}

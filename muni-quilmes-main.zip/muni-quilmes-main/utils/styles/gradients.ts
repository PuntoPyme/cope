export const gradients = {
	gradientGrey: "linear-gradient(90deg, #D9D9D9 100%, #DEDEDE 45%)",
	gradientBackground1:
		" linear-gradient(180deg, rgba(0, 0, 0, 0.2) 0%, rgba(255, 255, 255, 0.30) 0%);",
	gradientFilter: "linear-gradient(90deg, #D9D9D9 100%, #FFFFFF 50%)",
	gradientHeader: "linear-gradient(180deg, #E4E4E4 100%, #E4E4E4 1%)",
	gradientDiv: "linear-gradient(180deg, #9B9B9B 100%, #FFFFFF 100%)",
	gradientSidebar: "linear-gradient(90deg, #000000 100%, #A0D29F 100%)",
	gradientNavbar: "linear-gradient(180deg, #000000 100%, #A0D29F 100%)",
	gradientSelector: "linear-gradient(180deg, #134E5E 100%, #71B280 100%)",
	gradientButton: "linear-gradient(180deg, #9400D3 100%, #4B0082 100%)",
	gradientGreen: "linear-gradient(90deg, #3C316C 22.14%, #7A61A1 99.97%)",
	gradientDarkGreen: "linear-gradient(90deg, #134E5E 0%, #71B280 100%);",
	gradientBorderInputs:
		"linear-gradient(to right, #C650D6 15.2%, #95ADE5 67.6%)",
	gradientHeader1:
		"linear-gradient(90.03deg, #D9D9D9 18.57%, #ffffff69 42.18%, #ffffff00	100%)",
};





export const colors = {
	black: "#000000",
	grey: {
		dark: "#D9D9D9",
		mercury: "#E4E4E4",
		light: "#FFFEFE",
		title: "#464646",
		background: "#F8F5F5",
		input: "#F8F5F5",
		properties: "#EEEEEE",
		cards: "#E6E6E6",
		divider: "#D9D9D9",
		indicators: "#A5A5A5",
		/*   gradient1: "",
    gradient2: "", */
	},
	violet: {
		dark: "#6750A4",
		light: "#EADDFF",
		gradient1: "#9400D3",
		gradient2: "#4B0082",
	},
	green: {
		light: "#A0D29F",
		eden: "#134E5E",
		aqua: "#D7F0DA",
	},
	red: {
		light: "#F87575",
	},
	white: "#FFFFFF",
};
// https://chir.ag/projects/name-that-color/

export { default as productPlaceholder } from "../assets/placeholders/.svg";

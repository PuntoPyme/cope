import ReceiptLongIcon from "@mui/icons-material/ReceiptLong";
import { SvgIconProps } from "@mui/material";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import StoreIcon from "@mui/icons-material/Store";
import LocalShippingIcon from "@mui/icons-material/LocalShipping";
import AccountBalanceIcon from "@mui/icons-material/AccountBalance";
import CalculateIcon from "@mui/icons-material/Calculate";
import AssessmentIcon from "@mui/icons-material/Assessment";
export interface objetoPath {
	title: string;
	router: string;
	id: number;
	icon: React.ComponentType<SvgIconProps>;
	subPaths?: { title: string; router: string }[];
}

export const routerPaths: objetoPath[] = [
	{
		title: "Inicio",
		id: 0,
		icon: ReceiptLongIcon,
		router: "/Inicio",
		subPaths: [
			{ title: "Ver", router: "Ver" },
			{ title: "Nuevo", router: "Nuevo" },
		],
	},
	{
		title: "Venta",
		router: "Venta/",
		id: 1,
		icon: ReceiptLongIcon,
		subPaths: [
			{ title: "Ver", router: "Ver" },
			{ title: "Nuevo", router: "Nuevo" },
		],
	},
	{
		title: "Compra",
		router: "Compra/",
		id: 2,
		icon: ShoppingCartIcon,
		subPaths: [
			{ title: "Ver", router: "Ver" },
			{ title: "Nuevo", router: "Nuevo" },
		],
	},
	{
		title: "Clientes",
		router: "Clientes/",
		id: 3,
		icon: StoreIcon,
		subPaths: [
			{ title: "Ver", router: "Ver" },
			{ title: "Nuevo", router: "Nuevo" },
		],
	},
	{
		title: "Proveedores",
		router: "Proveedores/",
		id: 4,
		icon: LocalShippingIcon,
		subPaths: [
			{ title: "Ver", router: "Ver" },
			{ title: "Nuevo", router: "Nuevo" },
		],
	},
	{
		title: "Impuestos",
		router: "Impuestos/",
		id: 5,
		icon: AccountBalanceIcon,
		subPaths: [
			{ title: "Libro IVA compra", router: "IVACompra" },
			{ title: "Libro IVA venta", router: "IVAVenta" },
		],
	},
	{
		title: "Libro diario",
		router: "LibroDiario",
		id: 6,
		icon: CalculateIcon,
	},
	{
		title: "Asientos",
		router: "Asientos",
		id: 7,
		icon: AssessmentIcon,
	},
];

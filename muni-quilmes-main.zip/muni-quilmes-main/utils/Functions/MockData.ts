import { accountForJournal } from "@/types";
export const arrayOptionesIVA = [
	"Consumidor Final",
	"Exento",
	"Responsable Inscripto",
	"Monotributista",
];

export const arrayTipoIdentificacion = [
	"CUIT",
	"Acta nacimiento",
	"CDI",
	"Certificado de Migración",
	"CI Bs. As. RNP",
	"CUIL",
	"DNI",
	"En trámite",
	"LC",
	"Pasaporte",
	"Sin identificar/venta global diaria",
	"Usado por Anses para Padrón",
];

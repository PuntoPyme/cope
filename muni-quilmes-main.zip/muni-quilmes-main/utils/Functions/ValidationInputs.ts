import {
	accountForJournal,
	AddressMyType,
	clienteProveedorVer,
	compraVer,
	ContactMyType,
	ivaLibro,
	JournalEntry,
	JournalEntryResponse,
	ventaVer,
} from "@/types";
import { type } from "os";

export const isValidEmail = (email: string): boolean => {
	const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
	return emailRegex.test(email);
};

export const isValidCUIT = (cuit: string): boolean => {
	const cuitRegex = /^\d{2}-\d{8}-\d{1}$/;
	return cuitRegex.test(cuit);
};

export const formatCUIT = (value: string): string => {
	const digits = value.replace(/\D/g, "");
	if (digits.length <= 2) return digits;
	if (digits.length <= 10) return `${digits.slice(0, 2)}-${digits.slice(2)}`;
	return `${digits.slice(0, 2)}-${digits.slice(2, 10)}-${digits.slice(10, 11)}`;
};

export const invoiceTypes = ["Factura", "Nota de Debito"];
export const paymentMethod = ["Cuenta corriente", "Efectivo", "Banco"];
export const vatValue = [10.5, 21, 0];

export function convertValueString(input: string): string {
	const mapping: { [key: string]: string } = {
		DEBIT_NOTE: "Nota de débito",
		CASH: " Efectivo",
		MONOTAX: "Monotributo",
		FINAL_CONSUMER: "Consumidor final",
		TAX_PERCEPTION: "Responsable inscripto",
		EXEMPT_UNREACHED: "Exento",
	};
	const formattedInput = input.replace(/_/g, " ");
	return mapping[input] || formattedInput;
}
// Asegúrate de que este tipo esté definido en tu código
interface Account {
	name: string;
	code: number;
	id: number;
}

export const responseAccountJournal = (
	data: unknown
): data is { result: string; accounts: Account[]; message: null | string } => {
	return (
		typeof data === "object" &&
		data !== null &&
		"result" in data &&
		typeof (data as { result: unknown }).result === "string" &&
		"accounts" in data &&
		Array.isArray((data as { accounts: unknown[] }).accounts) && // Cambié 'unknown' a 'unknown[]'
		(data as { accounts: unknown[] }).accounts.every(isAccountForJournal) // Asegúrate de que sea un array
	);
};

// Aquí se asume que esta función valida cada cuenta individual
const isAccountForJournal = (account: unknown): account is Account => {
	return (
		typeof account === "object" &&
		account !== null &&
		"name" in account &&
		typeof (account as { name: unknown }).name === "string" &&
		"code" in account &&
		typeof (account as { code: unknown }).code === "string" &&
		"id" in account &&
		typeof (account as { id: unknown }).id === "number"
	);
};
export const isAccountForJournalArray = (
	accounts: unknown
): accounts is accountForJournal[] => {
	return (
		Array.isArray(accounts) &&
		accounts.every((account) => {
			return (
				typeof account.name === "string" &&
				typeof account.code === "number" &&
				typeof account.id === "number"
			);
		})
	);
};
export function isPurchaseInvoiceFields(item: any): boolean {
	return (
		typeof item.id === "number" &&
		typeof item.supplierName === "string" &&
		typeof item.province === "string" &&
		typeof item.invoiceType === "string" &&
		typeof item.date === "string" &&
		typeof item.expiration_date === "string" &&
		typeof item.number === "string" &&
		typeof item.paymentMethod === "string" &&
		typeof item.amount === "number" &&
		typeof item.vat === "number" &&
		typeof item.vat21 === "number" &&
		typeof item.vat105 === "number" &&
		typeof item.grossAmount === "number" &&
		typeof item.enabled === "boolean"
	);
}

export function isSalesInvoiceFields(item: any): boolean {
	return (
		typeof item.id === "number" &&
		typeof item.customerName === "string" &&
		typeof item.province === "string" &&
		typeof item.invoiceType === "string" &&
		typeof item.date === "string" &&
		typeof item.expiration_date === "string" &&
		typeof item.number === "string" &&
		typeof item.paymentMethod === "string" &&
		typeof item.amount === "number" &&
		typeof item.vat === "number" &&
		typeof item.vat21 === "number" &&
		typeof item.vat105 === "number" &&
		typeof item.grossAmount === "number" &&
		typeof item.enabled === "boolean" &&
		typeof item.amountNet21 === "number" &&
		typeof item.amountNet105 === "number" &&
		typeof item.amountNet0 === "number" &&
		typeof item.retVat === "number" &&
		typeof item.iibb === "number" &&
		typeof item.internalTaxes === "number" &&
		typeof item.vatCondition === "string" &&
		(typeof item.customerVatCondition === "string" ||
			item.customerVatCondition === null)
	);
}

export function isSalesInvoices(invoices: any): invoices is ventaVer[] {
	return Array.isArray(invoices) && invoices.every(isSalesInvoiceFields);
}

export function isPurchaseInvoices(invoices: any): invoices is compraVer[] {
	return Array.isArray(invoices) && invoices.every(isPurchaseInvoiceFields);
}

export function isIvaLibroCompra(data: any): data is ivaLibro {
	return (
		(data.salesInvoices === undefined || isSalesInvoices(data.salesInvoices)) &&
		(data.purchaseInvoices === undefined ||
			isPurchaseInvoices(data.purchaseInvoices)) &&
		typeof data.totalAmount === "number" &&
		typeof data.totalVat === "number" &&
		typeof data.totalVat21 === "number" &&
		typeof data.totalVat105 === "number" &&
		typeof data.totalGrossAmount === "number"
	);
}
export function isIvaLibro(data: any): data is ivaLibro {
	return (
		(data.salesInvoices === undefined || isSalesInvoices(data.salesInvoices)) &&
		typeof data.totalAmount === "number" &&
		typeof data.totalVat === "number" &&
		typeof data.totalVat21 === "number" &&
		typeof data.totalVat105 === "number" &&
		typeof data.totalGrossAmount === "number" &&
		typeof data.totalRetVat === "number" &&
		typeof data.totalIibb === "number" &&
		typeof data.totalInternalTaxes === "number" &&
		typeof data.totalAmountNet21 === "number" &&
		typeof data.totalAmountNet105 === "number" &&
		typeof data.totalAmountNet0 === "number" &&
		(typeof data.customerVatConditions === "string" ||
			data.customerVatConditions === null)
	);
}

function isValidAddress(address: any): address is AddressMyType {
	return (
		typeof address === "object" &&
		typeof address.apartament === "string" &&
		typeof address.building === "string" &&
		typeof address.city === "string" &&
		(address.floor === null || typeof address.floor === "number") && // Permitir null
		typeof address.number === "string" &&
		typeof address.postalCode === "number" &&
		typeof address.province === "string" &&
		typeof address.street === "string"
	);
}

// Función para validar el campo Contact
function isValidContact(contact: any): contact is ContactMyType {
	return (
		typeof contact === "object" &&
		typeof contact.email === "string" &&
		(contact.phone === null || typeof contact.phone === "string")
	);
} // Función para validar un solo cliente
export function isValidCustomer(
	customer: any
): customer is clienteProveedorVer {
	return (
		typeof customer === "object" &&
		customer !== null &&
		typeof customer.id === "number" &&
		typeof customer.name === "string" &&
		typeof customer.cuit === "string" &&
		typeof customer.vat === "string" &&
		isValidAddress(customer.address) && // Validar el objeto `address`
		isValidContact(customer.contact) && // Validar el objeto `contact`
		(typeof customer.country === "string" || customer.country === undefined) &&
		(typeof customer.enabled === "boolean" || customer.enabled === undefined)
	);
}
export function isValidEntityArray(data: any): data is clienteProveedorVer[] {
	// Verificamos que `data` sea un array y que todos los elementos en el array sean válidos
	if (!Array.isArray(data)) {
		return false;
	}

	// Validamos que todos los elementos en el array sean objetos válidos de tipo `clienteProveedorVer`
	return data.every(isValidCustomer);
}
export const isJournalEntry = (entry: unknown): entry is JournalEntry => {
	return (
		typeof entry === "object" &&
		entry !== null &&
		"id" in entry &&
		"date" in entry &&
		"description" in entry &&
		Array.isArray((entry as JournalEntryResponse).journalEntryLines) &&
		(entry as JournalEntryResponse).journalEntryLines.every(
			(line) =>
				typeof line.id === "number" &&
				typeof line.debitAccountName === "string" &&
				typeof line.creditAccountName === "string" &&
				typeof line.debitAccountId === "number" &&
				typeof line.creditAccountId === "number" &&
				typeof line.amount === "number"
		)
	);
};

export const responseJournalEntryArray = (
	data: unknown
): data is JournalEntryResponse[] => {
	return Array.isArray(data) && data.every(isJournalEntry);
};

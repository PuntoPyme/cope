import { convertValueString } from "./ValidationInputs";
import { useState, useEffect } from "react";
import { format, isWithinInterval } from "date-fns";

export function filtrarBusqueda<T extends object>(
	datos: T[],
	searchString: string
): T[] {
	const search = searchString.toLowerCase();
	return datos.filter((obj) => {
		const keys = Object.keys(obj).filter(
			(key) => key !== "date" && key !== "expiration_date"
		);
		return keys.some((key) => {
			const value = obj[key as keyof T];
			// Aplica la conversión solo si el valor es de tipo string
			const valueToSearch =
				typeof value === "string" ? convertValueString(value) : value;

			return (
				valueToSearch !== null &&
				valueToSearch !== undefined &&
				valueToSearch.toString().toLowerCase().includes(search)
			);
		});
	});
}

export const filterRowsByDateRange = (
	startDate: Date,
	endDate: Date,
	rowsProp: any[]
) => {
	const start = new Date(startDate);
	const end = new Date(endDate);
	const filteredRows = rowsProp.filter((row) => {
		const rowDate = new Date(row.date);
		return isWithinInterval(rowDate, { start, end });
	});
	return filteredRows;
};

export const formatDate = (date: Date): string => {
	return format(date, "dd/MM/yyyy");
};

export function useActionHandler(
	resultadoAccion: string,
	rowsChecked: any,
	options: {
		onPrint?: () => void;
		onDelete?: (idsToDelete: number[]) => Promise<void>;
	}
) {
	const { alert, alertText, alertType, showAlert } = useAlert();

	useEffect(() => {
		if (resultadoAccion === "Imprimir") {
			if (Object.keys(rowsChecked).length > 0) {
				options.onPrint?.();
			} else {
				showAlert("No se encontraron elementos para imprimir", "warning");
			}
		} else if (resultadoAccion === "Eliminar") {
			const idsToDelete = Object.values(rowsChecked).map((row: any) => row.id);
			if (idsToDelete.length > 0) {
				options
					.onDelete?.(idsToDelete)
					.then(() => showAlert("Eliminado(s) correctamente", "success"))
					.catch(() => showAlert("Error al eliminar los elementos", "error"));
			} else {
				showAlert("No se encontraron elementos para eliminar", "warning");
			}
		}
	}, [resultadoAccion]);

	return { alert, alertText, alertType };
}

export function useAlert() {
	const [alert, setAlert] = useState(false);
	const [alertType, setAlertType] = useState<
		"error" | "info" | "success" | "warning"
	>("info");
	const [alertText, setAlertText] = useState("");

	const showAlert = (
		text: string,
		type: "error" | "info" | "success" | "warning"
	) => {
		setAlertText(text);
		setAlertType(type);
		setAlert(true);
	};

	useEffect(() => {
		if (alert) {
			const timer = setTimeout(() => setAlert(false), 3000);
			return () => clearTimeout(timer); // Limpia el temporizador al desmontar
		}
	}, [alert]);

	return { alert, alertText, alertType, showAlert };
}

export default useAlert;
